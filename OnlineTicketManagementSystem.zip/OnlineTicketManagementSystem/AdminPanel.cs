﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OnlineTicketManagementSystem
{
    public partial class AdminForm : Form
    {
        public AdminForm()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AddTicket update = new AddTicket();
            this.Hide();
            update.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AdminUpdate update = new AdminUpdate();
            this.Hide();
            update.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AdminDelete update = new AdminDelete();
            this.Hide();
            update.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            AdminRemove update = new AdminRemove();
            this.Hide();
            update.ShowDialog();
        }

        private void backbutton1_Click(object sender, EventArgs e)
        {
            LogIn login = new LogIn();
            this.Hide();
            login.ShowDialog();
        }

        private void logoutbutton1_Click(object sender, EventArgs e)
        {
            LogIn login = new LogIn();
            this.Hide();
            login.ShowDialog();
        }

        private void exitbutton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void menubutton_Click(object sender, EventArgs e)
        {
            if (menupanel.Visible == false)
            {
                menupanel.Visible = true;
            }
            else if (menupanel.Visible == true)
            {
                menupanel.Visible = false;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            AllAccountInfo update = new AllAccountInfo();
            this.Hide();
            update.ShowDialog();
        }

        private void Editbutton_Click(object sender, EventArgs e)
        {
            Notification update = new Notification();
            this.Hide();
            update.ShowDialog();
        }

        private void Editbutton_MouseHover(object sender, EventArgs e)
        {
            System.Windows.Forms.ToolTip ToolTip1 = new System.Windows.Forms.ToolTip();
            ToolTip1.SetToolTip(this.Editbutton, this.Editbutton.Text);
        }
    }
}

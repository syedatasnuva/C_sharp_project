﻿namespace OnlineTicketManagementSystem
{
    partial class CreateAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CreateAccount));
            this.header = new System.Windows.Forms.Label();
            this.namelabel = new System.Windows.Forms.Label();
            this.Confirmlabel = new System.Windows.Forms.Label();
            this.Passwordlabel = new System.Windows.Forms.Label();
            this.GmailLabel = new System.Windows.Forms.Label();
            this.addresslabel = new System.Windows.Forms.Label();
            this.nameTextbox = new System.Windows.Forms.TextBox();
            this.passtextBox = new System.Windows.Forms.TextBox();
            this.addresstextBox = new System.Windows.Forms.TextBox();
            this.confirmtextBox = new System.Windows.Forms.TextBox();
            this.gmailTextBox = new System.Windows.Forms.TextBox();
            this.signupbutton = new System.Windows.Forms.Button();
            this.backbutton = new System.Windows.Forms.Button();
            this.exitbutton = new System.Windows.Forms.Button();
            this.createaccounttoolTip = new System.Windows.Forms.ToolTip(this.components);
            this.bdaydate = new System.Windows.Forms.DateTimePicker();
            this.genderbox = new System.Windows.Forms.ComboBox();
            this.accounttextBox = new System.Windows.Forms.TextBox();
            this.balancetextBox = new System.Windows.Forms.TextBox();
            this.namesequritylabel = new System.Windows.Forms.Label();
            this.addresssequritylabel = new System.Windows.Forms.Label();
            this.confirmsequritylabel2 = new System.Windows.Forms.Label();
            this.confirmsequritylabel1 = new System.Windows.Forms.Label();
            this.passsequritylabel = new System.Windows.Forms.Label();
            this.Birthdaylabel = new System.Windows.Forms.Label();
            this.Genderlabel = new System.Windows.Forms.Label();
            this.bdaysequritylabel = new System.Windows.Forms.Label();
            this.gendersequritylabel = new System.Windows.Forms.Label();
            this.accountsequritylabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.balancesequritylabel = new System.Windows.Forms.Label();
            this.balancelabel = new System.Windows.Forms.Label();
            this.balancesequritylabel2 = new System.Windows.Forms.Label();
            this.passsequritylabel2 = new System.Windows.Forms.Label();
            this.emailseqlabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // header
            // 
            this.header.AutoSize = true;
            this.header.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.header.Location = new System.Drawing.Point(77, 13);
            this.header.Name = "header";
            this.header.Size = new System.Drawing.Size(466, 31);
            this.header.TabIndex = 0;
            this.header.Text = "Online Ticket Management System";
            // 
            // namelabel
            // 
            this.namelabel.AutoSize = true;
            this.namelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.namelabel.Location = new System.Drawing.Point(51, 57);
            this.namelabel.Name = "namelabel";
            this.namelabel.Size = new System.Drawing.Size(68, 25);
            this.namelabel.TabIndex = 1;
            this.namelabel.Text = "Name";
            // 
            // Confirmlabel
            // 
            this.Confirmlabel.AutoSize = true;
            this.Confirmlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Confirmlabel.Location = new System.Drawing.Point(51, 166);
            this.Confirmlabel.Name = "Confirmlabel";
            this.Confirmlabel.Size = new System.Drawing.Size(186, 25);
            this.Confirmlabel.TabIndex = 2;
            this.Confirmlabel.Text = "Confirm Password";
            // 
            // Passwordlabel
            // 
            this.Passwordlabel.AutoSize = true;
            this.Passwordlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Passwordlabel.Location = new System.Drawing.Point(51, 128);
            this.Passwordlabel.Name = "Passwordlabel";
            this.Passwordlabel.Size = new System.Drawing.Size(106, 25);
            this.Passwordlabel.TabIndex = 3;
            this.Passwordlabel.Text = "Password";
            // 
            // GmailLabel
            // 
            this.GmailLabel.AutoSize = true;
            this.GmailLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GmailLabel.Location = new System.Drawing.Point(51, 94);
            this.GmailLabel.Name = "GmailLabel";
            this.GmailLabel.Size = new System.Drawing.Size(67, 25);
            this.GmailLabel.TabIndex = 4;
            this.GmailLabel.Text = "Gmail";
            // 
            // addresslabel
            // 
            this.addresslabel.AutoSize = true;
            this.addresslabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addresslabel.Location = new System.Drawing.Point(51, 200);
            this.addresslabel.Name = "addresslabel";
            this.addresslabel.Size = new System.Drawing.Size(91, 25);
            this.addresslabel.TabIndex = 6;
            this.addresslabel.Text = "Address";
            // 
            // nameTextbox
            // 
            this.nameTextbox.Location = new System.Drawing.Point(243, 60);
            this.nameTextbox.Name = "nameTextbox";
            this.nameTextbox.Size = new System.Drawing.Size(100, 20);
            this.nameTextbox.TabIndex = 8;
            this.createaccounttoolTip.SetToolTip(this.nameTextbox, "Enter a valid name");
            this.nameTextbox.Leave += new System.EventHandler(this.nameTextbox_Leave);
            this.nameTextbox.MouseLeave += new System.EventHandler(this.nameTextbox_MouseLeave);
            // 
            // passtextBox
            // 
            this.passtextBox.Location = new System.Drawing.Point(243, 137);
            this.passtextBox.Name = "passtextBox";
            this.passtextBox.PasswordChar = '*';
            this.passtextBox.Size = new System.Drawing.Size(100, 20);
            this.passtextBox.TabIndex = 9;
            this.createaccounttoolTip.SetToolTip(this.passtextBox, "Enter a valid password");
            this.passtextBox.Leave += new System.EventHandler(this.passtextBox_Leave);
            this.passtextBox.MouseLeave += new System.EventHandler(this.passtextBox_MouseLeave);
            // 
            // addresstextBox
            // 
            this.addresstextBox.Location = new System.Drawing.Point(243, 205);
            this.addresstextBox.Name = "addresstextBox";
            this.addresstextBox.Size = new System.Drawing.Size(100, 20);
            this.addresstextBox.TabIndex = 12;
            this.createaccounttoolTip.SetToolTip(this.addresstextBox, "Enter a valid address");
            this.addresstextBox.Leave += new System.EventHandler(this.addresstextBox_Leave);
            this.addresstextBox.MouseLeave += new System.EventHandler(this.addresstextBox_MouseLeave);
            // 
            // confirmtextBox
            // 
            this.confirmtextBox.Location = new System.Drawing.Point(243, 171);
            this.confirmtextBox.Name = "confirmtextBox";
            this.confirmtextBox.PasswordChar = '*';
            this.confirmtextBox.Size = new System.Drawing.Size(100, 20);
            this.confirmtextBox.TabIndex = 13;
            this.createaccounttoolTip.SetToolTip(this.confirmtextBox, "Confirm your password. This password must be same to your entered password.");
            this.confirmtextBox.Leave += new System.EventHandler(this.confirmtextBox_Leave);
            this.confirmtextBox.MouseLeave += new System.EventHandler(this.confirmtextBox_MouseLeave);
            // 
            // gmailTextBox
            // 
            this.gmailTextBox.Location = new System.Drawing.Point(243, 97);
            this.gmailTextBox.Name = "gmailTextBox";
            this.gmailTextBox.Size = new System.Drawing.Size(100, 20);
            this.gmailTextBox.TabIndex = 14;
            this.createaccounttoolTip.SetToolTip(this.gmailTextBox, "Enter a valid gmail");
            this.gmailTextBox.TextChanged += new System.EventHandler(this.gmailTextBox_TextChanged);
            // 
            // signupbutton
            // 
            this.signupbutton.Image = ((System.Drawing.Image)(resources.GetObject("signupbutton.Image")));
            this.signupbutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.signupbutton.Location = new System.Drawing.Point(511, 270);
            this.signupbutton.Name = "signupbutton";
            this.signupbutton.Size = new System.Drawing.Size(100, 34);
            this.signupbutton.TabIndex = 17;
            this.signupbutton.Text = "SignUp";
            this.signupbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.createaccounttoolTip.SetToolTip(this.signupbutton, "Click here to signup");
            this.signupbutton.UseVisualStyleBackColor = true;
            this.signupbutton.Click += new System.EventHandler(this.signupbutton_Click);
            // 
            // backbutton
            // 
            this.backbutton.Image = ((System.Drawing.Image)(resources.GetObject("backbutton.Image")));
            this.backbutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.backbutton.Location = new System.Drawing.Point(597, 12);
            this.backbutton.Name = "backbutton";
            this.backbutton.Size = new System.Drawing.Size(36, 32);
            this.backbutton.TabIndex = 18;
            this.backbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.createaccounttoolTip.SetToolTip(this.backbutton, "Back to login page");
            this.backbutton.UseVisualStyleBackColor = true;
            this.backbutton.Click += new System.EventHandler(this.backbutton_Click);
            // 
            // exitbutton
            // 
            this.exitbutton.Image = ((System.Drawing.Image)(resources.GetObject("exitbutton.Image")));
            this.exitbutton.Location = new System.Drawing.Point(597, 50);
            this.exitbutton.Name = "exitbutton";
            this.exitbutton.Size = new System.Drawing.Size(33, 32);
            this.exitbutton.TabIndex = 39;
            this.createaccounttoolTip.SetToolTip(this.exitbutton, "Click here to exit");
            this.exitbutton.UseVisualStyleBackColor = true;
            this.exitbutton.Click += new System.EventHandler(this.exitbutton_Click);
            // 
            // bdaydate
            // 
            this.bdaydate.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bdaydate.Location = new System.Drawing.Point(243, 239);
            this.bdaydate.Name = "bdaydate";
            this.bdaydate.Size = new System.Drawing.Size(100, 20);
            this.bdaydate.TabIndex = 15;
            this.createaccounttoolTip.SetToolTip(this.bdaydate, "Select your birthday");
            this.bdaydate.Leave += new System.EventHandler(this.bdaydate_Leave);
            this.bdaydate.MouseLeave += new System.EventHandler(this.bdaydate_MouseLeave);
            // 
            // genderbox
            // 
            this.genderbox.FormattingEnabled = true;
            this.genderbox.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.genderbox.Location = new System.Drawing.Point(243, 273);
            this.genderbox.Name = "genderbox";
            this.genderbox.Size = new System.Drawing.Size(100, 21);
            this.genderbox.TabIndex = 16;
            this.createaccounttoolTip.SetToolTip(this.genderbox, "select your gender");
            this.genderbox.SelectedIndexChanged += new System.EventHandler(this.genderbox_SelectedIndexChanged);
            this.genderbox.Leave += new System.EventHandler(this.genderbox_Leave);
            // 
            // accounttextBox
            // 
            this.accounttextBox.Location = new System.Drawing.Point(511, 96);
            this.accounttextBox.Name = "accounttextBox";
            this.accounttextBox.Size = new System.Drawing.Size(100, 20);
            this.accounttextBox.TabIndex = 56;
            this.createaccounttoolTip.SetToolTip(this.accounttextBox, "Enter a valid account no");
            this.accounttextBox.MouseLeave += new System.EventHandler(this.accounttextBox_MouseLeave);
            // 
            // balancetextBox
            // 
            this.balancetextBox.Location = new System.Drawing.Point(511, 135);
            this.balancetextBox.Name = "balancetextBox";
            this.balancetextBox.Size = new System.Drawing.Size(100, 20);
            this.balancetextBox.TabIndex = 59;
            this.createaccounttoolTip.SetToolTip(this.balancetextBox, "Enter a valid balance of your account");
            this.balancetextBox.MouseLeave += new System.EventHandler(this.balancetextBox_MouseLeave);
            // 
            // namesequritylabel
            // 
            this.namesequritylabel.AutoSize = true;
            this.namesequritylabel.ForeColor = System.Drawing.Color.Red;
            this.namesequritylabel.Location = new System.Drawing.Point(240, 81);
            this.namesequritylabel.Name = "namesequritylabel";
            this.namesequritylabel.Size = new System.Drawing.Size(155, 13);
            this.namesequritylabel.TabIndex = 40;
            this.namesequritylabel.Text = "->Name field must not be empty";
            this.namesequritylabel.Visible = false;
            // 
            // addresssequritylabel
            // 
            this.addresssequritylabel.AutoSize = true;
            this.addresssequritylabel.ForeColor = System.Drawing.Color.Red;
            this.addresssequritylabel.Location = new System.Drawing.Point(240, 223);
            this.addresssequritylabel.Name = "addresssequritylabel";
            this.addresssequritylabel.Size = new System.Drawing.Size(115, 13);
            this.addresssequritylabel.TabIndex = 41;
            this.addresssequritylabel.Text = "->Enter a valid address";
            this.addresssequritylabel.Visible = false;
            // 
            // confirmsequritylabel2
            // 
            this.confirmsequritylabel2.AutoSize = true;
            this.confirmsequritylabel2.ForeColor = System.Drawing.Color.Red;
            this.confirmsequritylabel2.Location = new System.Drawing.Point(240, 194);
            this.confirmsequritylabel2.Name = "confirmsequritylabel2";
            this.confirmsequritylabel2.Size = new System.Drawing.Size(134, 13);
            this.confirmsequritylabel2.TabIndex = 44;
            this.confirmsequritylabel2.Text = "->Password doesn\'t match.";
            this.confirmsequritylabel2.Visible = false;
            // 
            // confirmsequritylabel1
            // 
            this.confirmsequritylabel1.AutoSize = true;
            this.confirmsequritylabel1.ForeColor = System.Drawing.Color.Red;
            this.confirmsequritylabel1.Location = new System.Drawing.Point(240, 194);
            this.confirmsequritylabel1.Name = "confirmsequritylabel1";
            this.confirmsequritylabel1.Size = new System.Drawing.Size(147, 13);
            this.confirmsequritylabel1.TabIndex = 45;
            this.confirmsequritylabel1.Text = "->This field must not be empty";
            this.confirmsequritylabel1.Visible = false;
            // 
            // passsequritylabel
            // 
            this.passsequritylabel.AutoSize = true;
            this.passsequritylabel.ForeColor = System.Drawing.Color.Red;
            this.passsequritylabel.Location = new System.Drawing.Point(240, 155);
            this.passsequritylabel.Name = "passsequritylabel";
            this.passsequritylabel.Size = new System.Drawing.Size(173, 13);
            this.passsequritylabel.TabIndex = 46;
            this.passsequritylabel.Text = "->Password field must not be empty";
            this.passsequritylabel.Visible = false;
            // 
            // Birthdaylabel
            // 
            this.Birthdaylabel.AutoSize = true;
            this.Birthdaylabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Birthdaylabel.Location = new System.Drawing.Point(51, 235);
            this.Birthdaylabel.Name = "Birthdaylabel";
            this.Birthdaylabel.Size = new System.Drawing.Size(91, 25);
            this.Birthdaylabel.TabIndex = 5;
            this.Birthdaylabel.Text = "Birthday";
            // 
            // Genderlabel
            // 
            this.Genderlabel.AutoSize = true;
            this.Genderlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel.Location = new System.Drawing.Point(51, 270);
            this.Genderlabel.Name = "Genderlabel";
            this.Genderlabel.Size = new System.Drawing.Size(83, 25);
            this.Genderlabel.TabIndex = 7;
            this.Genderlabel.Text = "Gender";
            // 
            // bdaysequritylabel
            // 
            this.bdaysequritylabel.AutoSize = true;
            this.bdaysequritylabel.ForeColor = System.Drawing.Color.Red;
            this.bdaysequritylabel.Location = new System.Drawing.Point(240, 256);
            this.bdaysequritylabel.Name = "bdaysequritylabel";
            this.bdaysequritylabel.Size = new System.Drawing.Size(109, 13);
            this.bdaysequritylabel.TabIndex = 42;
            this.bdaysequritylabel.Text = "->You are not eligible.";
            this.bdaysequritylabel.Visible = false;
            // 
            // gendersequritylabel
            // 
            this.gendersequritylabel.AutoSize = true;
            this.gendersequritylabel.ForeColor = System.Drawing.Color.Red;
            this.gendersequritylabel.Location = new System.Drawing.Point(240, 297);
            this.gendersequritylabel.Name = "gendersequritylabel";
            this.gendersequritylabel.Size = new System.Drawing.Size(82, 13);
            this.gendersequritylabel.TabIndex = 43;
            this.gendersequritylabel.Text = "->Select gender";
            this.gendersequritylabel.Visible = false;
            // 
            // accountsequritylabel
            // 
            this.accountsequritylabel.AutoSize = true;
            this.accountsequritylabel.ForeColor = System.Drawing.Color.Red;
            this.accountsequritylabel.Location = new System.Drawing.Point(508, 119);
            this.accountsequritylabel.Name = "accountsequritylabel";
            this.accountsequritylabel.Size = new System.Drawing.Size(113, 13);
            this.accountsequritylabel.TabIndex = 55;
            this.accountsequritylabel.Text = "->Field can\'t be empty.";
            this.accountsequritylabel.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(362, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 25);
            this.label4.TabIndex = 54;
            this.label4.Text = "Account no";
            // 
            // balancesequritylabel
            // 
            this.balancesequritylabel.AutoSize = true;
            this.balancesequritylabel.ForeColor = System.Drawing.Color.Red;
            this.balancesequritylabel.Location = new System.Drawing.Point(508, 158);
            this.balancesequritylabel.Name = "balancesequritylabel";
            this.balancesequritylabel.Size = new System.Drawing.Size(113, 13);
            this.balancesequritylabel.TabIndex = 58;
            this.balancesequritylabel.Text = "->Field can\'t be empty.";
            this.balancesequritylabel.Visible = false;
            // 
            // balancelabel
            // 
            this.balancelabel.AutoSize = true;
            this.balancelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.balancelabel.Location = new System.Drawing.Point(362, 135);
            this.balancelabel.Name = "balancelabel";
            this.balancelabel.Size = new System.Drawing.Size(90, 25);
            this.balancelabel.TabIndex = 57;
            this.balancelabel.Text = "Balance";
            // 
            // balancesequritylabel2
            // 
            this.balancesequritylabel2.ForeColor = System.Drawing.Color.Red;
            this.balancesequritylabel2.Location = new System.Drawing.Point(508, 158);
            this.balancesequritylabel2.Name = "balancesequritylabel2";
            this.balancesequritylabel2.Size = new System.Drawing.Size(113, 33);
            this.balancesequritylabel2.TabIndex = 60;
            this.balancesequritylabel2.Text = "-> Balance can\'t be    negetive.";
            this.balancesequritylabel2.Visible = false;
            // 
            // passsequritylabel2
            // 
            this.passsequritylabel2.AutoSize = true;
            this.passsequritylabel2.ForeColor = System.Drawing.Color.Red;
            this.passsequritylabel2.Location = new System.Drawing.Point(240, 155);
            this.passsequritylabel2.Name = "passsequritylabel2";
            this.passsequritylabel2.Size = new System.Drawing.Size(119, 13);
            this.passsequritylabel2.TabIndex = 61;
            this.passsequritylabel2.Text = "->Password is too small.";
            this.passsequritylabel2.Visible = false;
            // 
            // emailseqlabel
            // 
            this.emailseqlabel.AutoSize = true;
            this.emailseqlabel.ForeColor = System.Drawing.Color.Red;
            this.emailseqlabel.Location = new System.Drawing.Point(240, 122);
            this.emailseqlabel.Name = "emailseqlabel";
            this.emailseqlabel.Size = new System.Drawing.Size(274, 13);
            this.emailseqlabel.TabIndex = 62;
            this.emailseqlabel.Text = "->Email field contains inappropriate character or is empty.";
            this.emailseqlabel.Visible = false;
            // 
            // CreateAccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(658, 332);
            this.Controls.Add(this.emailseqlabel);
            this.Controls.Add(this.passsequritylabel2);
            this.Controls.Add(this.balancesequritylabel2);
            this.Controls.Add(this.balancetextBox);
            this.Controls.Add(this.balancesequritylabel);
            this.Controls.Add(this.balancelabel);
            this.Controls.Add(this.accounttextBox);
            this.Controls.Add(this.accountsequritylabel);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.passsequritylabel);
            this.Controls.Add(this.confirmsequritylabel1);
            this.Controls.Add(this.confirmsequritylabel2);
            this.Controls.Add(this.gendersequritylabel);
            this.Controls.Add(this.bdaysequritylabel);
            this.Controls.Add(this.addresssequritylabel);
            this.Controls.Add(this.namesequritylabel);
            this.Controls.Add(this.exitbutton);
            this.Controls.Add(this.backbutton);
            this.Controls.Add(this.signupbutton);
            this.Controls.Add(this.genderbox);
            this.Controls.Add(this.bdaydate);
            this.Controls.Add(this.gmailTextBox);
            this.Controls.Add(this.confirmtextBox);
            this.Controls.Add(this.addresstextBox);
            this.Controls.Add(this.passtextBox);
            this.Controls.Add(this.nameTextbox);
            this.Controls.Add(this.Genderlabel);
            this.Controls.Add(this.addresslabel);
            this.Controls.Add(this.Birthdaylabel);
            this.Controls.Add(this.GmailLabel);
            this.Controls.Add(this.Passwordlabel);
            this.Controls.Add(this.Confirmlabel);
            this.Controls.Add(this.namelabel);
            this.Controls.Add(this.header);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "CreateAccount";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Create Account";
            this.Load += new System.EventHandler(this.CreateAccount_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label header;
        private System.Windows.Forms.Label namelabel;
        private System.Windows.Forms.Label Confirmlabel;
        private System.Windows.Forms.Label Passwordlabel;
        private System.Windows.Forms.Label GmailLabel;
        private System.Windows.Forms.Label addresslabel;
        private System.Windows.Forms.TextBox nameTextbox;
        private System.Windows.Forms.TextBox passtextBox;
        private System.Windows.Forms.TextBox addresstextBox;
        private System.Windows.Forms.TextBox confirmtextBox;
        private System.Windows.Forms.TextBox gmailTextBox;
        private System.Windows.Forms.Button signupbutton;
        private System.Windows.Forms.Button backbutton;
        private System.Windows.Forms.Button exitbutton;
        private System.Windows.Forms.ToolTip createaccounttoolTip;
        private System.Windows.Forms.Label namesequritylabel;
        private System.Windows.Forms.Label addresssequritylabel;
        private System.Windows.Forms.Label confirmsequritylabel2;
        private System.Windows.Forms.Label confirmsequritylabel1;
        private System.Windows.Forms.Label passsequritylabel;
        private System.Windows.Forms.Label Birthdaylabel;
        private System.Windows.Forms.Label Genderlabel;
        private System.Windows.Forms.DateTimePicker bdaydate;
        private System.Windows.Forms.ComboBox genderbox;
        private System.Windows.Forms.Label bdaysequritylabel;
        private System.Windows.Forms.Label gendersequritylabel;
        private System.Windows.Forms.TextBox accounttextBox;
        private System.Windows.Forms.Label accountsequritylabel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox balancetextBox;
        private System.Windows.Forms.Label balancesequritylabel;
        private System.Windows.Forms.Label balancelabel;
        private System.Windows.Forms.Label balancesequritylabel2;
        private System.Windows.Forms.Label passsequritylabel2;
        private System.Windows.Forms.Label emailseqlabel;
    }
}
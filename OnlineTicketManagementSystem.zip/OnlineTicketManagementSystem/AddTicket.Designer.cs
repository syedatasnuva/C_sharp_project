﻿namespace OnlineTicketManagementSystem
{
    partial class AddTicket
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddTicket));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pricetextBox = new System.Windows.Forms.TextBox();
            this.pricelabel = new System.Windows.Forms.Label();
            this.procceedbutton = new System.Windows.Forms.Button();
            this.warnlabel = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pm8 = new System.Windows.Forms.CheckBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.pm6 = new System.Windows.Forms.CheckBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.pm4 = new System.Windows.Forms.CheckBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pm12 = new System.Windows.Forms.CheckBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.am10 = new System.Windows.Forms.CheckBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.am8 = new System.Windows.Forms.CheckBox();
            this.ticketLocationtextBox = new System.Windows.Forms.TextBox();
            this.ticketNametextBox = new System.Windows.Forms.TextBox();
            this.ticketTypecomboBox = new System.Windows.Forms.ComboBox();
            this.ticketTypeLabel = new System.Windows.Forms.Label();
            this.chooselabel = new System.Windows.Forms.Label();
            this.timelabel = new System.Windows.Forms.Label();
            this.locationlabel = new System.Windows.Forms.Label();
            this.quantitycomboBox = new System.Windows.Forms.ComboBox();
            this.quantitylabel = new System.Windows.Forms.Label();
            this.submitbutton = new System.Windows.Forms.Button();
            this.menupanel = new System.Windows.Forms.Panel();
            this.exitbutton = new System.Windows.Forms.Button();
            this.logoutbutton1 = new System.Windows.Forms.Button();
            this.menubutton = new System.Windows.Forms.Button();
            this.header = new System.Windows.Forms.Label();
            this.backbutton1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.menupanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pricetextBox);
            this.panel1.Controls.Add(this.pricelabel);
            this.panel1.Controls.Add(this.procceedbutton);
            this.panel1.Controls.Add(this.warnlabel);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.ticketTypecomboBox);
            this.panel1.Controls.Add(this.ticketTypeLabel);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.ticketLocationtextBox);
            this.panel1.Controls.Add(this.ticketNametextBox);
            this.panel1.Controls.Add(this.chooselabel);
            this.panel1.Controls.Add(this.timelabel);
            this.panel1.Controls.Add(this.locationlabel);
            this.panel1.Controls.Add(this.quantitycomboBox);
            this.panel1.Controls.Add(this.quantitylabel);
            this.panel1.Controls.Add(this.submitbutton);
            this.panel1.Location = new System.Drawing.Point(101, 74);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(577, 322);
            this.panel1.TabIndex = 58;
            // 
            // pricetextBox
            // 
            this.pricetextBox.Location = new System.Drawing.Point(388, 279);
            this.pricetextBox.Margin = new System.Windows.Forms.Padding(4);
            this.pricetextBox.Name = "pricetextBox";
            this.pricetextBox.Size = new System.Drawing.Size(62, 22);
            this.pricetextBox.TabIndex = 72;
            // 
            // pricelabel
            // 
            this.pricelabel.AutoSize = true;
            this.pricelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pricelabel.Image = ((System.Drawing.Image)(resources.GetObject("pricelabel.Image")));
            this.pricelabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.pricelabel.Location = new System.Drawing.Point(269, 270);
            this.pricelabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pricelabel.Name = "pricelabel";
            this.pricelabel.Size = new System.Drawing.Size(111, 31);
            this.pricelabel.TabIndex = 71;
            this.pricelabel.Text = "    Price ";
            this.pricelabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // procceedbutton
            // 
            this.procceedbutton.Image = ((System.Drawing.Image)(resources.GetObject("procceedbutton.Image")));
            this.procceedbutton.Location = new System.Drawing.Point(436, 27);
            this.procceedbutton.Margin = new System.Windows.Forms.Padding(4);
            this.procceedbutton.Name = "procceedbutton";
            this.procceedbutton.Size = new System.Drawing.Size(42, 33);
            this.procceedbutton.TabIndex = 53;
            this.procceedbutton.UseVisualStyleBackColor = true;
            this.procceedbutton.Click += new System.EventHandler(this.procceedbutton_Click);
            // 
            // warnlabel
            // 
            this.warnlabel.AutoSize = true;
            this.warnlabel.ForeColor = System.Drawing.Color.Red;
            this.warnlabel.Location = new System.Drawing.Point(270, 60);
            this.warnlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.warnlabel.Name = "warnlabel";
            this.warnlabel.Size = new System.Drawing.Size(158, 17);
            this.warnlabel.TabIndex = 70;
            this.warnlabel.Text = "Select a ticket type first.";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.pm8);
            this.panel6.Location = new System.Drawing.Point(441, 179);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(79, 36);
            this.panel6.TabIndex = 69;
            // 
            // pm8
            // 
            this.pm8.AutoSize = true;
            this.pm8.Location = new System.Drawing.Point(7, 7);
            this.pm8.Margin = new System.Windows.Forms.Padding(4);
            this.pm8.Name = "pm8";
            this.pm8.Size = new System.Drawing.Size(61, 21);
            this.pm8.TabIndex = 74;
            this.pm8.Text = "8 pm";
            this.pm8.UseVisualStyleBackColor = true;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.pm6);
            this.panel8.Location = new System.Drawing.Point(354, 179);
            this.panel8.Margin = new System.Windows.Forms.Padding(4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(79, 36);
            this.panel8.TabIndex = 69;
            // 
            // pm6
            // 
            this.pm6.AutoSize = true;
            this.pm6.Location = new System.Drawing.Point(7, 7);
            this.pm6.Margin = new System.Windows.Forms.Padding(4);
            this.pm6.Name = "pm6";
            this.pm6.Size = new System.Drawing.Size(61, 21);
            this.pm6.TabIndex = 74;
            this.pm6.Text = "6 pm";
            this.pm6.UseVisualStyleBackColor = true;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.pm4);
            this.panel7.Location = new System.Drawing.Point(268, 179);
            this.panel7.Margin = new System.Windows.Forms.Padding(4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(79, 36);
            this.panel7.TabIndex = 69;
            // 
            // pm4
            // 
            this.pm4.AutoSize = true;
            this.pm4.Location = new System.Drawing.Point(7, 7);
            this.pm4.Margin = new System.Windows.Forms.Padding(4);
            this.pm4.Name = "pm4";
            this.pm4.Size = new System.Drawing.Size(61, 21);
            this.pm4.TabIndex = 74;
            this.pm4.Text = "4 pm";
            this.pm4.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.pm12);
            this.panel5.Location = new System.Drawing.Point(442, 135);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(79, 36);
            this.panel5.TabIndex = 69;
            // 
            // pm12
            // 
            this.pm12.AccessibleDescription = "";
            this.pm12.AutoSize = true;
            this.pm12.Location = new System.Drawing.Point(7, 7);
            this.pm12.Margin = new System.Windows.Forms.Padding(4);
            this.pm12.Name = "pm12";
            this.pm12.Size = new System.Drawing.Size(69, 21);
            this.pm12.TabIndex = 74;
            this.pm12.Text = "12 pm";
            this.pm12.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.am10);
            this.panel4.Location = new System.Drawing.Point(355, 135);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(79, 36);
            this.panel4.TabIndex = 69;
            // 
            // am10
            // 
            this.am10.AutoSize = true;
            this.am10.Location = new System.Drawing.Point(7, 7);
            this.am10.Margin = new System.Windows.Forms.Padding(4);
            this.am10.Name = "am10";
            this.am10.Size = new System.Drawing.Size(69, 21);
            this.am10.TabIndex = 74;
            this.am10.Text = "10 am";
            this.am10.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.am8);
            this.panel3.Location = new System.Drawing.Point(268, 135);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(79, 36);
            this.panel3.TabIndex = 68;
            // 
            // am8
            // 
            this.am8.AutoSize = true;
            this.am8.Location = new System.Drawing.Point(4, 7);
            this.am8.Margin = new System.Windows.Forms.Padding(4);
            this.am8.Name = "am8";
            this.am8.Size = new System.Drawing.Size(61, 21);
            this.am8.TabIndex = 73;
            this.am8.Text = "8 am";
            this.am8.UseVisualStyleBackColor = true;
            // 
            // ticketLocationtextBox
            // 
            this.ticketLocationtextBox.Location = new System.Drawing.Point(268, 232);
            this.ticketLocationtextBox.Margin = new System.Windows.Forms.Padding(4);
            this.ticketLocationtextBox.Name = "ticketLocationtextBox";
            this.ticketLocationtextBox.Size = new System.Drawing.Size(160, 22);
            this.ticketLocationtextBox.TabIndex = 59;
            // 
            // ticketNametextBox
            // 
            this.ticketNametextBox.Location = new System.Drawing.Point(268, 92);
            this.ticketNametextBox.Margin = new System.Windows.Forms.Padding(4);
            this.ticketNametextBox.Name = "ticketNametextBox";
            this.ticketNametextBox.Size = new System.Drawing.Size(160, 22);
            this.ticketNametextBox.TabIndex = 58;
            // 
            // ticketTypecomboBox
            // 
            this.ticketTypecomboBox.FormattingEnabled = true;
            this.ticketTypecomboBox.Items.AddRange(new object[] {
            "Movie Ticket",
            "Bus Ticket",
            "Concert Ticket",
            "Cricket Ticket"});
            this.ticketTypecomboBox.Location = new System.Drawing.Point(268, 32);
            this.ticketTypecomboBox.Margin = new System.Windows.Forms.Padding(4);
            this.ticketTypecomboBox.Name = "ticketTypecomboBox";
            this.ticketTypecomboBox.Size = new System.Drawing.Size(160, 24);
            this.ticketTypecomboBox.TabIndex = 57;
            this.ticketTypecomboBox.SelectedIndexChanged += new System.EventHandler(this.ticketTypecomboBox_SelectedIndexChanged);
            // 
            // ticketTypeLabel
            // 
            this.ticketTypeLabel.AutoSize = true;
            this.ticketTypeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ticketTypeLabel.Image = ((System.Drawing.Image)(resources.GetObject("ticketTypeLabel.Image")));
            this.ticketTypeLabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ticketTypeLabel.Location = new System.Drawing.Point(12, 32);
            this.ticketTypeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ticketTypeLabel.Name = "ticketTypeLabel";
            this.ticketTypeLabel.Size = new System.Drawing.Size(182, 31);
            this.ticketTypeLabel.TabIndex = 56;
            this.ticketTypeLabel.Text = "     Ticket type";
            this.ticketTypeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // chooselabel
            // 
            this.chooselabel.AutoSize = true;
            this.chooselabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chooselabel.Image = ((System.Drawing.Image)(resources.GetObject("chooselabel.Image")));
            this.chooselabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.chooselabel.Location = new System.Drawing.Point(12, 92);
            this.chooselabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.chooselabel.Name = "chooselabel";
            this.chooselabel.Size = new System.Drawing.Size(202, 31);
            this.chooselabel.TabIndex = 50;
            this.chooselabel.Text = "     Ticket Name";
            this.chooselabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // timelabel
            // 
            this.timelabel.AutoSize = true;
            this.timelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timelabel.Image = ((System.Drawing.Image)(resources.GetObject("timelabel.Image")));
            this.timelabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.timelabel.Location = new System.Drawing.Point(12, 140);
            this.timelabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.timelabel.Name = "timelabel";
            this.timelabel.Size = new System.Drawing.Size(181, 31);
            this.timelabel.TabIndex = 48;
            this.timelabel.Text = "     Ticket time";
            this.timelabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // locationlabel
            // 
            this.locationlabel.AutoSize = true;
            this.locationlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.locationlabel.Image = ((System.Drawing.Image)(resources.GetObject("locationlabel.Image")));
            this.locationlabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.locationlabel.Location = new System.Drawing.Point(12, 223);
            this.locationlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.locationlabel.Name = "locationlabel";
            this.locationlabel.Size = new System.Drawing.Size(224, 31);
            this.locationlabel.TabIndex = 49;
            this.locationlabel.Text = "     Ticket location";
            this.locationlabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // quantitycomboBox
            // 
            this.quantitycomboBox.FormattingEnabled = true;
            this.quantitycomboBox.Items.AddRange(new object[] {
            "40",
            "50",
            "60",
            "100",
            "120",
            "150",
            "200"});
            this.quantitycomboBox.Location = new System.Drawing.Point(173, 275);
            this.quantitycomboBox.Margin = new System.Windows.Forms.Padding(4);
            this.quantitycomboBox.Name = "quantitycomboBox";
            this.quantitycomboBox.Size = new System.Drawing.Size(63, 24);
            this.quantitycomboBox.TabIndex = 55;
            // 
            // quantitylabel
            // 
            this.quantitylabel.AutoSize = true;
            this.quantitylabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quantitylabel.Image = ((System.Drawing.Image)(resources.GetObject("quantitylabel.Image")));
            this.quantitylabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.quantitylabel.Location = new System.Drawing.Point(12, 268);
            this.quantitylabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.quantitylabel.Name = "quantitylabel";
            this.quantitylabel.Size = new System.Drawing.Size(151, 31);
            this.quantitylabel.TabIndex = 54;
            this.quantitylabel.Text = "     Quantity";
            this.quantitylabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.quantitylabel.Click += new System.EventHandler(this.quantitylabel_Click);
            // 
            // submitbutton
            // 
            this.submitbutton.Image = ((System.Drawing.Image)(resources.GetObject("submitbutton.Image")));
            this.submitbutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.submitbutton.Location = new System.Drawing.Point(473, 255);
            this.submitbutton.Margin = new System.Windows.Forms.Padding(4);
            this.submitbutton.Name = "submitbutton";
            this.submitbutton.Size = new System.Drawing.Size(100, 46);
            this.submitbutton.TabIndex = 47;
            this.submitbutton.Text = "Submit";
            this.submitbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.submitbutton.UseVisualStyleBackColor = true;
            this.submitbutton.Click += new System.EventHandler(this.submitbutton_Click);
            // 
            // menupanel
            // 
            this.menupanel.Controls.Add(this.exitbutton);
            this.menupanel.Controls.Add(this.logoutbutton1);
            this.menupanel.Location = new System.Drawing.Point(814, 89);
            this.menupanel.Margin = new System.Windows.Forms.Padding(4);
            this.menupanel.Name = "menupanel";
            this.menupanel.Size = new System.Drawing.Size(52, 284);
            this.menupanel.TabIndex = 57;
            this.menupanel.Visible = false;
            // 
            // exitbutton
            // 
            this.exitbutton.Image = ((System.Drawing.Image)(resources.GetObject("exitbutton.Image")));
            this.exitbutton.Location = new System.Drawing.Point(0, 69);
            this.exitbutton.Margin = new System.Windows.Forms.Padding(4);
            this.exitbutton.Name = "exitbutton";
            this.exitbutton.Size = new System.Drawing.Size(44, 39);
            this.exitbutton.TabIndex = 44;
            this.exitbutton.UseVisualStyleBackColor = true;
            this.exitbutton.Click += new System.EventHandler(this.exitbutton_Click);
            // 
            // logoutbutton1
            // 
            this.logoutbutton1.Image = ((System.Drawing.Image)(resources.GetObject("logoutbutton1.Image")));
            this.logoutbutton1.Location = new System.Drawing.Point(0, 22);
            this.logoutbutton1.Margin = new System.Windows.Forms.Padding(4);
            this.logoutbutton1.Name = "logoutbutton1";
            this.logoutbutton1.Size = new System.Drawing.Size(44, 39);
            this.logoutbutton1.TabIndex = 42;
            this.logoutbutton1.UseVisualStyleBackColor = true;
            this.logoutbutton1.Click += new System.EventHandler(this.logoutbutton1_Click);
            // 
            // menubutton
            // 
            this.menubutton.Image = ((System.Drawing.Image)(resources.GetObject("menubutton.Image")));
            this.menubutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menubutton.Location = new System.Drawing.Point(814, 20);
            this.menubutton.Margin = new System.Windows.Forms.Padding(4);
            this.menubutton.Name = "menubutton";
            this.menubutton.Size = new System.Drawing.Size(45, 39);
            this.menubutton.TabIndex = 56;
            this.menubutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.menubutton.UseVisualStyleBackColor = true;
            this.menubutton.Click += new System.EventHandler(this.menubutton_Click);
            // 
            // header
            // 
            this.header.AutoSize = true;
            this.header.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.header.Location = new System.Drawing.Point(94, 31);
            this.header.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.header.Name = "header";
            this.header.Size = new System.Drawing.Size(198, 39);
            this.header.TabIndex = 54;
            this.header.Text = "Add Ticket:";
            // 
            // backbutton1
            // 
            this.backbutton1.Image = ((System.Drawing.Image)(resources.GetObject("backbutton1.Image")));
            this.backbutton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.backbutton1.Location = new System.Drawing.Point(761, 20);
            this.backbutton1.Margin = new System.Windows.Forms.Padding(4);
            this.backbutton1.Name = "backbutton1";
            this.backbutton1.Size = new System.Drawing.Size(45, 39);
            this.backbutton1.TabIndex = 55;
            this.backbutton1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.backbutton1.UseVisualStyleBackColor = true;
            this.backbutton1.Click += new System.EventHandler(this.backbutton1_Click);
            // 
            // AddTicket
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(878, 409);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menupanel);
            this.Controls.Add(this.menubutton);
            this.Controls.Add(this.header);
            this.Controls.Add(this.backbutton1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "AddTicket";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add Ticket";
            this.Load += new System.EventHandler(this.AddTicket_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.menupanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox pricetextBox;
        private System.Windows.Forms.Label pricelabel;
        private System.Windows.Forms.Button procceedbutton;
        private System.Windows.Forms.Label warnlabel;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.CheckBox pm8;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.CheckBox pm6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.CheckBox pm4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.CheckBox pm12;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.CheckBox am10;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.CheckBox am8;
        private System.Windows.Forms.TextBox ticketLocationtextBox;
        private System.Windows.Forms.TextBox ticketNametextBox;
        private System.Windows.Forms.ComboBox ticketTypecomboBox;
        private System.Windows.Forms.Label ticketTypeLabel;
        private System.Windows.Forms.Label chooselabel;
        private System.Windows.Forms.Label timelabel;
        private System.Windows.Forms.Label locationlabel;
        private System.Windows.Forms.ComboBox quantitycomboBox;
        private System.Windows.Forms.Label quantitylabel;
        private System.Windows.Forms.Button submitbutton;
        private System.Windows.Forms.Panel menupanel;
        private System.Windows.Forms.Button exitbutton;
        private System.Windows.Forms.Button logoutbutton1;
        private System.Windows.Forms.Button menubutton;
        private System.Windows.Forms.Label header;
        private System.Windows.Forms.Button backbutton1;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace OnlineTicketManagementSystem
{
    public partial class TicketInfo : Form
    {
       int priority = 0;
        string gmail = "";
        DataTable dt = new DataTable();

        SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");
         

        public TicketInfo(string gmail,int priority)
        {
            this.gmail=gmail;
            this.priority=priority;
            InitializeComponent();
        }

        private void backbutton_Click(object sender, EventArgs e)
        {
            LogIn login = new LogIn();
            this.Hide();
            login.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LogIn login = new LogIn();
            this.Hide();
            login.ShowDialog();
        }

        private void accountbutton_Click(object sender, EventArgs e)
        {
            AccountInfo accountinfo = new AccountInfo(gmail, priority);
            this.Hide();
            accountinfo.ShowDialog();
        }

        private void donebutton_Click(object sender, EventArgs e)
        {
            string tickettype = ticketTypecomboBox.GetItemText(this.ticketTypecomboBox.SelectedItem);
            string ticketnames = ticketcomboBox.GetItemText(this.ticketcomboBox.SelectedItem);
            string ticketloc = locationcomboBox.GetItemText(this.locationcomboBox.SelectedItem);
            string tickettime = timecomboBox.GetItemText(this.timecomboBox.SelectedItem);
            string ticketquantity = quantitycomboBox.GetItemText(this.quantitycomboBox.SelectedItem);
            int ticketprice = 0;
            string capacity = "";

            SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");
            string query = "";

            if (tickettype.Equals("Movie Ticket"))
            {
                query = "select * from movie_ticket where movie_name='" + ticketnames + "' and movie_location='" + ticketloc + "' and movie_time='" + tickettime + "'";
            }
            else if (tickettype.Equals("Bus Ticket"))
            {
                query = "select * from bus_tickets where bus_name='" + ticketnames + "' and bus_location='" + ticketloc + "' and bus_time='" + tickettime + "'";
            }
            else if (tickettype.Equals("Concert Ticket"))
            {
                query = "select * from concert_ticket where concert_name='" + ticketnames + "' and concert_location='" + ticketloc + "' and concert_time='" + tickettime + "'";
            }
            else if (tickettype.Equals("Cricket Ticket"))
            {
                query = "select * from cricket_ticket where cricket_name='" + ticketnames + "' and cricket_location='" + ticketloc + "' and cricket_time='" + tickettime + "'";
            }
           SqlDataAdapter adapter=new SqlDataAdapter(query,sql);
           DataTable dt=new DataTable();
           try
           {
               adapter.Fill(dt);
           }
           catch (Exception ex)
           {
               MessageBox.Show(ticketnames+" is not available at "+tickettime+" for "+ticketloc);
           }
             if(dt.Rows.Count==1)
             {
                    foreach (DataRow row in dt.Rows)
                    {
                        ticketprice = row.Field<int>(3);
                        capacity = row.Field<string>(4);
                    }
             }
             else if (dt.Rows.Count == 0)
             {
                 MessageBox.Show(ticketnames + " is not available at " + tickettime + " for " + ticketloc);
             }
             try
             {
                 if (int.Parse(capacity) >= int.Parse(ticketquantity))
                 {
                     Payment payment = new Payment(gmail, priority, tickettype, ticketnames, ticketloc, tickettime, ticketquantity, ticketprice);
                     this.Hide();
                     payment.ShowDialog();
                 }
                 else
                 {
                     MessageBox.Show("Only " + capacity + " tickets are available.");
                 }
             }
             catch (Exception ex)
             {
                 //MessageBox.Show(ex.Message);
             }
        }

        private void exitbutton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void menubutton_Click(object sender, EventArgs e)
        {
            if (menupanel.Visible == false)
            {
                menupanel.Visible = true;
            }
            else if (menupanel.Visible == true)
            {
                menupanel.Visible = false;
            }
        }

        private void searchbutton_Click(object sender, EventArgs e)
        {
            if (searchpanel.Visible == false)
            {
                searchpanel.Visible = true;
            }
            else if (searchpanel.Visible == true)
            {
                searchpanel.Visible = false;
            }
        }

        private void TicketInfo_Load(object sender, EventArgs e)
        {
            searchpanel.Visible = false;
            menupanel.Visible = false;
        }

        private void TicketInfo_Click(object sender, EventArgs e)
        {
            searchpanel.Visible = false;
            menupanel.Visible = false;
        }

        private void proccedbutton_Click(object sender, EventArgs e)
        {
            SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");
            string query = "";
           

            if (ticketTypecomboBox.Text == "Movie Ticket")
            {
                    query = "select * from movie";
            }
            else if (ticketTypecomboBox.Text == "Bus Ticket")
            {
                query = "select * from bus";
            }
            else if (ticketTypecomboBox.Text == "Concert Ticket")
            {
                query = "select * from concert";
            }
            else if (ticketTypecomboBox.Text == "Cricket Ticket")
            {
                query = "select * from cricket";
            }
            else if (ticketTypecomboBox.Text == "")
            {
                MessageBox.Show("First select a ticket type.");
            }
            //.....
            ticketcomboBox.Items.Clear();
            SqlCommand cmd = new SqlCommand(query, sql);
            SqlDataReader dr;
            try
            {
                sql.Open();
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    string tname = dr.GetString(0);
                    ticketcomboBox.Items.Add(tname);
                }
                chooseTicketpanel.Visible = true;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }
        }

        private void requestbutton_Click(object sender, EventArgs e)
        {
            TicketRequest payment = new TicketRequest(gmail,priority);
            this.Hide();
            payment.ShowDialog();
        }

        private void chooseticketbutton_Click(object sender, EventArgs e)
        {
            if (ticketcomboBox.Text != "")
            {
                SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");
                string query = "";


                if (ticketTypecomboBox.Text == "Movie Ticket")
                {
                    query = "select * from movie_ticket where movie_name='" + ticketcomboBox.GetItemText(this.ticketcomboBox.SelectedItem)+"'";
                }
                else if (ticketTypecomboBox.Text == "Bus Ticket")
                {
                    query = "select * from bus_tickets where bus_name='" + ticketcomboBox.GetItemText(this.ticketcomboBox.SelectedItem) + "'";
                }
                else if (ticketTypecomboBox.Text == "Concert Ticket")
                {
                    query = "select * from concert_ticket where concert_name='" + ticketcomboBox.GetItemText(this.ticketcomboBox.SelectedItem) + "'";
                }
                else if (ticketTypecomboBox.Text == "Cricket Ticket")
                {
                    query = "select * from cricket_ticket where cricket_name='" + ticketcomboBox.GetItemText(this.ticketcomboBox.SelectedItem) + "'";
                }
                else if (ticketTypecomboBox.Text == "")
                {
                    MessageBox.Show("First select a ticket type.");
                }
                //.....

                locationcomboBox.Items.Clear();
                SqlCommand cmd = new SqlCommand(query, sql);
                SqlDataReader dr;
                try
                {
                    sql.Open();
                    dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        string tname = dr.GetString(2);
                        if (locationcomboBox.Items.Contains(tname))
                        {
                        }
                        else
                        {
                            locationcomboBox.Items.Add(tname);
                        }
                        }
                    Locationpanel.Visible = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
              
            }
            else if (ticketcomboBox.Text == "")
            {
                MessageBox.Show("First select a ticket name.");
            }
        }

        private void locationbutton_Click(object sender, EventArgs e)
        {
            if (locationcomboBox.Text != "")
            {
                SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");
                string query = "";


                if (ticketTypecomboBox.Text == "Movie Ticket")
                {
                    query = "select * from movie_ticket where movie_name='" + ticketcomboBox.GetItemText(this.ticketcomboBox.SelectedItem) + "' and movie_location='" + locationcomboBox.GetItemText(this.locationcomboBox.SelectedItem) + "'";
                }
                else if (ticketTypecomboBox.Text == "Bus Ticket")
                {
                    query = "select * from bus_tickets where bus_name='" + ticketcomboBox.GetItemText(this.ticketcomboBox.SelectedItem) + "' and bus_location='" + locationcomboBox.GetItemText(this.locationcomboBox.SelectedItem) + "'";
                }
                else if (ticketTypecomboBox.Text == "Concert Ticket")
                {
                    query = "select * from concert_ticket where concert_name='" + ticketcomboBox.GetItemText(this.ticketcomboBox.SelectedItem) + "' and concert_location='" + locationcomboBox.GetItemText(this.locationcomboBox.SelectedItem) + "'";
                }
                else if (ticketTypecomboBox.Text == "Cricket Ticket")
                {
                    query = "select * from cricket_ticket where cricket_name='" + ticketcomboBox.GetItemText(this.ticketcomboBox.SelectedItem) + "' and cricket_location='" + locationcomboBox.GetItemText(this.locationcomboBox.SelectedItem) + "'";
                }
                else if (ticketTypecomboBox.Text == "")
                {
                    MessageBox.Show("First select a ticket type.");
                }
                //.....

                timecomboBox.Items.Clear();
                SqlCommand cmd = new SqlCommand(query, sql);
                SqlDataReader dr;
                try
                {
                    sql.Open();
                    dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        string tname = dr.GetString(1);
                        if (timecomboBox.Items.Contains(tname))
                        {
                        }
                        else
                        {
                            timecomboBox.Items.Add(tname);
                        }
                    }
                    ticketpanel.Visible = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                
            }
            else if (locationcomboBox.Text == "")
            {
                MessageBox.Show("First select a location.");
            }
        }

        private void ticketTypecomboBox_MouseClick(object sender, MouseEventArgs e)
        {
            chooseTicketpanel.Visible = false;
            Locationpanel.Visible = false;
            ticketpanel.Visible = false;
            ticketcomboBox.Text = "";
            locationcomboBox.Text = "";
            quantitycomboBox.Text = "";
            timecomboBox.Text = "";
        }

        private void searchb_Click(object sender, EventArgs e)
        {
            string searchinput = searchtextBox.Text;
            search searchp = new search(gmail,priority,searchinput);
            this.Hide();
            searchp.ShowDialog();
        }

        private void searchtextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void locationcomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

       


    }
}

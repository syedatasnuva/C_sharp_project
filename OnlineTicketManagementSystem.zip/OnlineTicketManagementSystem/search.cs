﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace OnlineTicketManagementSystem
{
    public partial class search : Form
    {
        string gmail = "", searchinput = "";
        int priority = 0;
        SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");
            
        public search(string gmail, int priority, string searchinput)
        {
            this.gmail = gmail;
            this.priority = priority;
            this.searchinput = searchinput;
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void search_Load(object sender, EventArgs e)
        {
            searchlabel.Text = searchinput;
            loadDataGrid();
        }

        public void loadDataGrid()
        {
            string queery1 = "select * from movie_ticket where movie_name='" + searchinput + "' or movie_location='" + searchinput + "'";
            string queery2 = "select * from bus_tickets where bus_name='" + searchinput + "' or bus_location='" + searchinput + "'";
            string queery3 = "select * from concert_ticket where concert_name='" + searchinput + "' or concert_location='" + searchinput + "'";
            string queery4 = "select * from cricket_ticket where cricket_name='" + searchinput + "' or cricket_location='" + searchinput + "'";

            
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(queery1, sql);
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            
            if (dt.Rows.Count == 0 )
            {
                dataGridView1.DataSource = null;
                SqlDataAdapter adapter2 = new SqlDataAdapter(queery2, sql);
                DataTable dt2 = new DataTable();
                adapter2.Fill(dt2);
                dataGridView1.DataSource = dt2;

                if (dt2.Rows.Count == 0)
                {
                    dataGridView1.DataSource = null;
                    SqlDataAdapter adapter3 = new SqlDataAdapter(queery3, sql);
                    DataTable dt3 = new DataTable();
                    adapter3.Fill(dt3);
                    dataGridView1.DataSource = dt3;

                    if (dt3.Rows.Count == 0)
                    {
                        dataGridView1.DataSource = null;
                        SqlDataAdapter adapter4 = new SqlDataAdapter(queery4, sql);
                        DataTable dt4 = new DataTable();
                        adapter4.Fill(dt4);
                        dataGridView1.DataSource = dt4;
                    }
                }
            }
            
        }

        private void backbutton_Click(object sender, EventArgs e)
        {
            TicketInfo info = new TicketInfo(gmail,priority);
            this.Hide();
            info.ShowDialog();
        }

        private void menubutton_Click(object sender, EventArgs e)
        {
            if (menupanel.Visible == false)
            {
                menupanel.Visible = true;
            }
            else if (menupanel.Visible == true)
            {
                menupanel.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LogIn login = new LogIn();
            this.Hide();
            login.ShowDialog();
        }

        private void exitbutton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

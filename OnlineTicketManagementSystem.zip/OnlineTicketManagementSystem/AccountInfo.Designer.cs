﻿namespace OnlineTicketManagementSystem
{
    partial class AccountInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AccountInfo));
            this.header = new System.Windows.Forms.Label();
            this.namelabel = new System.Windows.Forms.Label();
            this.genderlabel = new System.Windows.Forms.Label();
            this.bdaylabel = new System.Windows.Forms.Label();
            this.Banklabel = new System.Windows.Forms.Label();
            this.passlabel = new System.Windows.Forms.Label();
            this.emaillabel = new System.Windows.Forms.Label();
            this.addresslabel = new System.Windows.Forms.Label();
            this.genderText = new System.Windows.Forms.Label();
            this.BdayText = new System.Windows.Forms.Label();
            this.AccountText = new System.Windows.Forms.Label();
            this.passtext = new System.Windows.Forms.Label();
            this.emailText = new System.Windows.Forms.Label();
            this.addresstext = new System.Windows.Forms.Label();
            this.nametext = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.balancelabel = new System.Windows.Forms.Label();
            this.balancetext = new System.Windows.Forms.Label();
            this.logoutbutton1 = new System.Windows.Forms.Button();
            this.backbutton1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.namesequritylabel = new System.Windows.Forms.Label();
            this.addresssequritylabel = new System.Windows.Forms.Label();
            this.bdaysequritylabel = new System.Windows.Forms.Label();
            this.passsequritylabel = new System.Windows.Forms.Label();
            this.bdaytime = new System.Windows.Forms.DateTimePicker();
            this.bdaysubmitbutton = new System.Windows.Forms.Button();
            this.passsubmitbutton = new System.Windows.Forms.Button();
            this.addresssubmitbutton = new System.Windows.Forms.Button();
            this.namesubmitbutton = new System.Windows.Forms.Button();
            this.editPasstextBox = new System.Windows.Forms.TextBox();
            this.editEmailtextBox = new System.Windows.Forms.TextBox();
            this.editAddresstextBox = new System.Windows.Forms.TextBox();
            this.editnametextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.exitbutton = new System.Windows.Forms.Button();
            this.menubutton = new System.Windows.Forms.Button();
            this.menupanel = new System.Windows.Forms.Panel();
            this.Editbutton = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.menupanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // header
            // 
            this.header.AutoSize = true;
            this.header.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.header.Location = new System.Drawing.Point(87, 36);
            this.header.Name = "header";
            this.header.Size = new System.Drawing.Size(466, 31);
            this.header.TabIndex = 21;
            this.header.Text = "Online Ticket Management System";
            // 
            // namelabel
            // 
            this.namelabel.AutoSize = true;
            this.namelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.namelabel.Location = new System.Drawing.Point(13, 15);
            this.namelabel.Name = "namelabel";
            this.namelabel.Size = new System.Drawing.Size(102, 18);
            this.namelabel.TabIndex = 25;
            this.namelabel.Text = "Name         :";
            // 
            // genderlabel
            // 
            this.genderlabel.AutoSize = true;
            this.genderlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.genderlabel.Location = new System.Drawing.Point(11, 179);
            this.genderlabel.Name = "genderlabel";
            this.genderlabel.Size = new System.Drawing.Size(103, 18);
            this.genderlabel.TabIndex = 27;
            this.genderlabel.Text = "Gender       :";
            // 
            // bdaylabel
            // 
            this.bdaylabel.AutoSize = true;
            this.bdaylabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bdaylabel.Location = new System.Drawing.Point(11, 149);
            this.bdaylabel.Name = "bdaylabel";
            this.bdaylabel.Size = new System.Drawing.Size(104, 18);
            this.bdaylabel.TabIndex = 28;
            this.bdaylabel.Text = "Birthday      :";
            // 
            // Banklabel
            // 
            this.Banklabel.AutoSize = true;
            this.Banklabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Banklabel.Location = new System.Drawing.Point(13, 121);
            this.Banklabel.Name = "Banklabel";
            this.Banklabel.Size = new System.Drawing.Size(103, 18);
            this.Banklabel.TabIndex = 29;
            this.Banklabel.Text = "Account no :";
            // 
            // passlabel
            // 
            this.passlabel.AutoSize = true;
            this.passlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passlabel.Location = new System.Drawing.Point(13, 94);
            this.passlabel.Name = "passlabel";
            this.passlabel.Size = new System.Drawing.Size(103, 18);
            this.passlabel.TabIndex = 30;
            this.passlabel.Text = "Password   :";
            // 
            // emaillabel
            // 
            this.emaillabel.AutoSize = true;
            this.emaillabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emaillabel.Location = new System.Drawing.Point(13, 69);
            this.emaillabel.Name = "emaillabel";
            this.emaillabel.Size = new System.Drawing.Size(105, 18);
            this.emaillabel.TabIndex = 31;
            this.emaillabel.Text = "Email          :";
            // 
            // addresslabel
            // 
            this.addresslabel.AutoSize = true;
            this.addresslabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addresslabel.Location = new System.Drawing.Point(13, 42);
            this.addresslabel.Name = "addresslabel";
            this.addresslabel.Size = new System.Drawing.Size(104, 18);
            this.addresslabel.TabIndex = 32;
            this.addresslabel.Text = "Address      :";
            // 
            // genderText
            // 
            this.genderText.AutoSize = true;
            this.genderText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.genderText.Location = new System.Drawing.Point(134, 179);
            this.genderText.Name = "genderText";
            this.genderText.Size = new System.Drawing.Size(12, 18);
            this.genderText.TabIndex = 34;
            this.genderText.Text = "l";
            // 
            // BdayText
            // 
            this.BdayText.AutoSize = true;
            this.BdayText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BdayText.Location = new System.Drawing.Point(134, 149);
            this.BdayText.Name = "BdayText";
            this.BdayText.Size = new System.Drawing.Size(12, 18);
            this.BdayText.TabIndex = 35;
            this.BdayText.Text = "l";
            // 
            // AccountText
            // 
            this.AccountText.AutoSize = true;
            this.AccountText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AccountText.Location = new System.Drawing.Point(134, 121);
            this.AccountText.Name = "AccountText";
            this.AccountText.Size = new System.Drawing.Size(12, 18);
            this.AccountText.TabIndex = 36;
            this.AccountText.Text = "l";
            // 
            // passtext
            // 
            this.passtext.AutoSize = true;
            this.passtext.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passtext.Location = new System.Drawing.Point(134, 94);
            this.passtext.Name = "passtext";
            this.passtext.Size = new System.Drawing.Size(12, 18);
            this.passtext.TabIndex = 37;
            this.passtext.Text = "l";
            // 
            // emailText
            // 
            this.emailText.AutoSize = true;
            this.emailText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailText.Location = new System.Drawing.Point(134, 69);
            this.emailText.Name = "emailText";
            this.emailText.Size = new System.Drawing.Size(12, 18);
            this.emailText.TabIndex = 38;
            this.emailText.Text = "l";
            // 
            // addresstext
            // 
            this.addresstext.AutoSize = true;
            this.addresstext.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addresstext.Location = new System.Drawing.Point(134, 42);
            this.addresstext.Name = "addresstext";
            this.addresstext.Size = new System.Drawing.Size(12, 18);
            this.addresstext.TabIndex = 39;
            this.addresstext.Text = "l";
            // 
            // nametext
            // 
            this.nametext.AutoSize = true;
            this.nametext.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nametext.Location = new System.Drawing.Point(134, 15);
            this.nametext.Name = "nametext";
            this.nametext.Size = new System.Drawing.Size(12, 18);
            this.nametext.TabIndex = 40;
            this.nametext.Text = "l";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.balancelabel);
            this.panel1.Controls.Add(this.balancetext);
            this.panel1.Controls.Add(this.namelabel);
            this.panel1.Controls.Add(this.nametext);
            this.panel1.Controls.Add(this.genderlabel);
            this.panel1.Controls.Add(this.addresstext);
            this.panel1.Controls.Add(this.bdaylabel);
            this.panel1.Controls.Add(this.emailText);
            this.panel1.Controls.Add(this.Banklabel);
            this.panel1.Controls.Add(this.passtext);
            this.panel1.Controls.Add(this.passlabel);
            this.panel1.Controls.Add(this.AccountText);
            this.panel1.Controls.Add(this.emaillabel);
            this.panel1.Controls.Add(this.BdayText);
            this.panel1.Controls.Add(this.addresslabel);
            this.panel1.Controls.Add(this.genderText);
            this.panel1.Location = new System.Drawing.Point(104, 68);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(460, 229);
            this.panel1.TabIndex = 41;
            // 
            // balancelabel
            // 
            this.balancelabel.AutoSize = true;
            this.balancelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.balancelabel.Location = new System.Drawing.Point(262, 121);
            this.balancelabel.Name = "balancelabel";
            this.balancelabel.Size = new System.Drawing.Size(108, 18);
            this.balancelabel.TabIndex = 42;
            this.balancelabel.Text = "Balance       :";
            // 
            // balancetext
            // 
            this.balancetext.AutoSize = true;
            this.balancetext.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.balancetext.Location = new System.Drawing.Point(385, 121);
            this.balancetext.Name = "balancetext";
            this.balancetext.Size = new System.Drawing.Size(12, 18);
            this.balancetext.TabIndex = 43;
            this.balancetext.Text = "l";
            // 
            // logoutbutton1
            // 
            this.logoutbutton1.Image = ((System.Drawing.Image)(resources.GetObject("logoutbutton1.Image")));
            this.logoutbutton1.Location = new System.Drawing.Point(7, 45);
            this.logoutbutton1.Name = "logoutbutton1";
            this.logoutbutton1.Size = new System.Drawing.Size(33, 32);
            this.logoutbutton1.TabIndex = 42;
            this.toolTip1.SetToolTip(this.logoutbutton1, "LogOut from your account");
            this.logoutbutton1.UseVisualStyleBackColor = true;
            this.logoutbutton1.Click += new System.EventHandler(this.logoutbutton1_Click);
            // 
            // backbutton1
            // 
            this.backbutton1.Image = ((System.Drawing.Image)(resources.GetObject("backbutton1.Image")));
            this.backbutton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.backbutton1.Location = new System.Drawing.Point(576, 12);
            this.backbutton1.Name = "backbutton1";
            this.backbutton1.Size = new System.Drawing.Size(34, 32);
            this.backbutton1.TabIndex = 41;
            this.backbutton1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.backbutton1, "Back to ticket information page.");
            this.backbutton1.UseVisualStyleBackColor = true;
            this.backbutton1.Click += new System.EventHandler(this.backbutton1_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.namesequritylabel);
            this.panel2.Controls.Add(this.addresssequritylabel);
            this.panel2.Controls.Add(this.bdaysequritylabel);
            this.panel2.Controls.Add(this.passsequritylabel);
            this.panel2.Controls.Add(this.bdaytime);
            this.panel2.Controls.Add(this.bdaysubmitbutton);
            this.panel2.Controls.Add(this.passsubmitbutton);
            this.panel2.Controls.Add(this.addresssubmitbutton);
            this.panel2.Controls.Add(this.namesubmitbutton);
            this.panel2.Controls.Add(this.editPasstextBox);
            this.panel2.Controls.Add(this.editEmailtextBox);
            this.panel2.Controls.Add(this.editAddresstextBox);
            this.panel2.Controls.Add(this.editnametextBox);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Location = new System.Drawing.Point(104, 68);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(460, 229);
            this.panel2.TabIndex = 42;
            // 
            // namesequritylabel
            // 
            this.namesequritylabel.AutoSize = true;
            this.namesequritylabel.ForeColor = System.Drawing.Color.Red;
            this.namesequritylabel.Location = new System.Drawing.Point(135, 31);
            this.namesequritylabel.Name = "namesequritylabel";
            this.namesequritylabel.Size = new System.Drawing.Size(144, 13);
            this.namesequritylabel.TabIndex = 56;
            this.namesequritylabel.Text = "-> Name field can\'t be empty.";
            this.namesequritylabel.Visible = false;
            // 
            // addresssequritylabel
            // 
            this.addresssequritylabel.AutoSize = true;
            this.addresssequritylabel.ForeColor = System.Drawing.Color.Red;
            this.addresssequritylabel.Location = new System.Drawing.Point(135, 68);
            this.addresssequritylabel.Name = "addresssequritylabel";
            this.addresssequritylabel.Size = new System.Drawing.Size(154, 13);
            this.addresssequritylabel.TabIndex = 55;
            this.addresssequritylabel.Text = "-> Address field can\'t be empty.";
            this.addresssequritylabel.Visible = false;
            // 
            // bdaysequritylabel
            // 
            this.bdaysequritylabel.AutoSize = true;
            this.bdaysequritylabel.ForeColor = System.Drawing.Color.Red;
            this.bdaysequritylabel.Location = new System.Drawing.Point(135, 179);
            this.bdaysequritylabel.Name = "bdaysequritylabel";
            this.bdaysequritylabel.Size = new System.Drawing.Size(148, 13);
            this.bdaysequritylabel.TabIndex = 54;
            this.bdaysequritylabel.Text = "-> Age need be more than 18.";
            this.bdaysequritylabel.Visible = false;
            // 
            // passsequritylabel
            // 
            this.passsequritylabel.AutoSize = true;
            this.passsequritylabel.ForeColor = System.Drawing.Color.Red;
            this.passsequritylabel.Location = new System.Drawing.Point(135, 136);
            this.passsequritylabel.Name = "passsequritylabel";
            this.passsequritylabel.Size = new System.Drawing.Size(221, 13);
            this.passsequritylabel.TabIndex = 53;
            this.passsequritylabel.Text = "-> Password needs to be at least 6 character.";
            this.passsequritylabel.Visible = false;
            // 
            // bdaytime
            // 
            this.bdaytime.Location = new System.Drawing.Point(137, 158);
            this.bdaytime.Name = "bdaytime";
            this.bdaytime.Size = new System.Drawing.Size(129, 20);
            this.bdaytime.TabIndex = 52;
            // 
            // bdaysubmitbutton
            // 
            this.bdaysubmitbutton.Image = ((System.Drawing.Image)(resources.GetObject("bdaysubmitbutton.Image")));
            this.bdaysubmitbutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bdaysubmitbutton.Location = new System.Drawing.Point(283, 155);
            this.bdaysubmitbutton.Name = "bdaysubmitbutton";
            this.bdaysubmitbutton.Size = new System.Drawing.Size(33, 26);
            this.bdaysubmitbutton.TabIndex = 51;
            this.bdaysubmitbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.bdaysubmitbutton, "Click here to submit the change.");
            this.bdaysubmitbutton.UseVisualStyleBackColor = true;
            this.bdaysubmitbutton.Click += new System.EventHandler(this.bdaysubmitbutton_Click);
            // 
            // passsubmitbutton
            // 
            this.passsubmitbutton.Image = ((System.Drawing.Image)(resources.GetObject("passsubmitbutton.Image")));
            this.passsubmitbutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.passsubmitbutton.Location = new System.Drawing.Point(283, 107);
            this.passsubmitbutton.Name = "passsubmitbutton";
            this.passsubmitbutton.Size = new System.Drawing.Size(33, 26);
            this.passsubmitbutton.TabIndex = 49;
            this.passsubmitbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.passsubmitbutton, "Click here to submit the change.");
            this.passsubmitbutton.UseVisualStyleBackColor = true;
            this.passsubmitbutton.Click += new System.EventHandler(this.passsubmitbutton_Click);
            // 
            // addresssubmitbutton
            // 
            this.addresssubmitbutton.Image = ((System.Drawing.Image)(resources.GetObject("addresssubmitbutton.Image")));
            this.addresssubmitbutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.addresssubmitbutton.Location = new System.Drawing.Point(283, 44);
            this.addresssubmitbutton.Name = "addresssubmitbutton";
            this.addresssubmitbutton.Size = new System.Drawing.Size(33, 26);
            this.addresssubmitbutton.TabIndex = 48;
            this.addresssubmitbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.addresssubmitbutton, "Click here to submit the change.");
            this.addresssubmitbutton.UseVisualStyleBackColor = true;
            this.addresssubmitbutton.Click += new System.EventHandler(this.addresssubmitbutton_Click);
            // 
            // namesubmitbutton
            // 
            this.namesubmitbutton.Image = ((System.Drawing.Image)(resources.GetObject("namesubmitbutton.Image")));
            this.namesubmitbutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.namesubmitbutton.Location = new System.Drawing.Point(283, 8);
            this.namesubmitbutton.Name = "namesubmitbutton";
            this.namesubmitbutton.Size = new System.Drawing.Size(33, 26);
            this.namesubmitbutton.TabIndex = 47;
            this.namesubmitbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.namesubmitbutton, "Click here to submit the change.");
            this.namesubmitbutton.UseVisualStyleBackColor = true;
            this.namesubmitbutton.Click += new System.EventHandler(this.submitbutton_Click);
            // 
            // editPasstextBox
            // 
            this.editPasstextBox.Location = new System.Drawing.Point(137, 116);
            this.editPasstextBox.Name = "editPasstextBox";
            this.editPasstextBox.Size = new System.Drawing.Size(129, 20);
            this.editPasstextBox.TabIndex = 43;
            this.editPasstextBox.UseSystemPasswordChar = true;
            // 
            // editEmailtextBox
            // 
            this.editEmailtextBox.Location = new System.Drawing.Point(137, 85);
            this.editEmailtextBox.Name = "editEmailtextBox";
            this.editEmailtextBox.ReadOnly = true;
            this.editEmailtextBox.Size = new System.Drawing.Size(129, 20);
            this.editEmailtextBox.TabIndex = 42;
            // 
            // editAddresstextBox
            // 
            this.editAddresstextBox.Location = new System.Drawing.Point(137, 48);
            this.editAddresstextBox.Name = "editAddresstextBox";
            this.editAddresstextBox.Size = new System.Drawing.Size(129, 20);
            this.editAddresstextBox.TabIndex = 41;
            // 
            // editnametextBox
            // 
            this.editnametextBox.Location = new System.Drawing.Point(137, 12);
            this.editnametextBox.Name = "editnametextBox";
            this.editnametextBox.Size = new System.Drawing.Size(129, 20);
            this.editnametextBox.TabIndex = 40;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(14, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 18);
            this.label1.TabIndex = 33;
            this.label1.Text = "Name         :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(13, 155);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 18);
            this.label3.TabIndex = 35;
            this.label3.Text = "Birthday       :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(15, 114);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 18);
            this.label5.TabIndex = 37;
            this.label5.Text = "Password    :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(15, 83);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 18);
            this.label6.TabIndex = 38;
            this.label6.Text = "Email          :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(13, 50);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(104, 18);
            this.label7.TabIndex = 39;
            this.label7.Text = "Address      :";
            // 
            // exitbutton
            // 
            this.exitbutton.Image = ((System.Drawing.Image)(resources.GetObject("exitbutton.Image")));
            this.exitbutton.Location = new System.Drawing.Point(7, 83);
            this.exitbutton.Name = "exitbutton";
            this.exitbutton.Size = new System.Drawing.Size(33, 32);
            this.exitbutton.TabIndex = 44;
            this.toolTip1.SetToolTip(this.exitbutton, "Click here to exit.");
            this.exitbutton.UseVisualStyleBackColor = true;
            this.exitbutton.Click += new System.EventHandler(this.exitbutton_Click);
            // 
            // menubutton
            // 
            this.menubutton.Image = ((System.Drawing.Image)(resources.GetObject("menubutton.Image")));
            this.menubutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menubutton.Location = new System.Drawing.Point(616, 12);
            this.menubutton.Name = "menubutton";
            this.menubutton.Size = new System.Drawing.Size(34, 32);
            this.menubutton.TabIndex = 45;
            this.menubutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.menubutton, "Select menu");
            this.menubutton.UseVisualStyleBackColor = true;
            this.menubutton.Click += new System.EventHandler(this.menubutton_Click);
            // 
            // menupanel
            // 
            this.menupanel.Controls.Add(this.Editbutton);
            this.menupanel.Controls.Add(this.exitbutton);
            this.menupanel.Controls.Add(this.logoutbutton1);
            this.menupanel.Location = new System.Drawing.Point(598, 68);
            this.menupanel.Name = "menupanel";
            this.menupanel.Size = new System.Drawing.Size(52, 231);
            this.menupanel.TabIndex = 46;
            this.menupanel.Visible = false;
            // 
            // Editbutton
            // 
            this.Editbutton.Image = ((System.Drawing.Image)(resources.GetObject("Editbutton.Image")));
            this.Editbutton.Location = new System.Drawing.Point(6, 6);
            this.Editbutton.Name = "Editbutton";
            this.Editbutton.Size = new System.Drawing.Size(34, 32);
            this.Editbutton.TabIndex = 43;
            this.Editbutton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.toolTip1.SetToolTip(this.Editbutton, "Edit/Change information");
            this.Editbutton.UseVisualStyleBackColor = true;
            this.Editbutton.Click += new System.EventHandler(this.Editbutton_Click_1);
            // 
            // AccountInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(658, 332);
            this.Controls.Add(this.menupanel);
            this.Controls.Add(this.menubutton);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.header);
            this.Controls.Add(this.backbutton1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "AccountInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AccountInfo";
            this.Load += new System.EventHandler(this.AccountInfo_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.menupanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label header;
        private System.Windows.Forms.Label namelabel;
        private System.Windows.Forms.Label genderlabel;
        private System.Windows.Forms.Label bdaylabel;
        private System.Windows.Forms.Label Banklabel;
        private System.Windows.Forms.Label passlabel;
        private System.Windows.Forms.Label emaillabel;
        private System.Windows.Forms.Label addresslabel;
        private System.Windows.Forms.Label genderText;
        private System.Windows.Forms.Label BdayText;
        private System.Windows.Forms.Label AccountText;
        private System.Windows.Forms.Label passtext;
        private System.Windows.Forms.Label emailText;
        private System.Windows.Forms.Label addresstext;
        private System.Windows.Forms.Label nametext;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button namesubmitbutton;
        private System.Windows.Forms.TextBox editPasstextBox;
        private System.Windows.Forms.TextBox editEmailtextBox;
        private System.Windows.Forms.TextBox editAddresstextBox;
        private System.Windows.Forms.TextBox editnametextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button logoutbutton1;
        private System.Windows.Forms.Button backbutton1;
        private System.Windows.Forms.Button exitbutton;
        private System.Windows.Forms.Button menubutton;
        private System.Windows.Forms.Panel menupanel;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.DateTimePicker bdaytime;
        private System.Windows.Forms.Button bdaysubmitbutton;
        private System.Windows.Forms.Button passsubmitbutton;
        private System.Windows.Forms.Button addresssubmitbutton;
        private System.Windows.Forms.Label balancelabel;
        private System.Windows.Forms.Label balancetext;
        private System.Windows.Forms.Label bdaysequritylabel;
        private System.Windows.Forms.Label passsequritylabel;
        private System.Windows.Forms.Label namesequritylabel;
        private System.Windows.Forms.Label addresssequritylabel;
        private System.Windows.Forms.Button Editbutton;
    }
}
﻿namespace OnlineTicketManagementSystem
{
    partial class TicketInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TicketInfo));
            this.header = new System.Windows.Forms.Label();
            this.ticketTypeLabel = new System.Windows.Forms.Label();
            this.locationlabel = new System.Windows.Forms.Label();
            this.chooselabel = new System.Windows.Forms.Label();
            this.ticketTypecomboBox = new System.Windows.Forms.ComboBox();
            this.ticketcomboBox = new System.Windows.Forms.ComboBox();
            this.locationcomboBox = new System.Windows.Forms.ComboBox();
            this.backbutton = new System.Windows.Forms.Button();
            this.accountbutton = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.exitbutton = new System.Windows.Forms.Button();
            this.requestbutton = new System.Windows.Forms.Button();
            this.menupanel = new System.Windows.Forms.Panel();
            this.searchbutton = new System.Windows.Forms.Button();
            this.menubutton = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.searchtextBox = new System.Windows.Forms.TextBox();
            this.proccedbutton = new System.Windows.Forms.Button();
            this.donebutton = new System.Windows.Forms.Button();
            this.quantitycomboBox = new System.Windows.Forms.ComboBox();
            this.timecomboBox = new System.Windows.Forms.ComboBox();
            this.chooseticketbutton = new System.Windows.Forms.Button();
            this.locationbutton = new System.Windows.Forms.Button();
            this.searchb = new System.Windows.Forms.Button();
            this.ticketpanel = new System.Windows.Forms.Panel();
            this.timelabel = new System.Windows.Forms.Label();
            this.quantitylabel = new System.Windows.Forms.Label();
            this.searchpanel = new System.Windows.Forms.Panel();
            this.chooseTicketpanel = new System.Windows.Forms.Panel();
            this.Locationpanel = new System.Windows.Forms.Panel();
            this.menupanel.SuspendLayout();
            this.ticketpanel.SuspendLayout();
            this.searchpanel.SuspendLayout();
            this.chooseTicketpanel.SuspendLayout();
            this.Locationpanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // header
            // 
            this.header.AutoSize = true;
            this.header.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.header.Location = new System.Drawing.Point(102, 41);
            this.header.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.header.Name = "header";
            this.header.Size = new System.Drawing.Size(576, 39);
            this.header.TabIndex = 0;
            this.header.Text = "Online Ticket Management System";
            // 
            // ticketTypeLabel
            // 
            this.ticketTypeLabel.AutoSize = true;
            this.ticketTypeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ticketTypeLabel.Image = ((System.Drawing.Image)(resources.GetObject("ticketTypeLabel.Image")));
            this.ticketTypeLabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ticketTypeLabel.Location = new System.Drawing.Point(13, 112);
            this.ticketTypeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ticketTypeLabel.Name = "ticketTypeLabel";
            this.ticketTypeLabel.Size = new System.Drawing.Size(182, 31);
            this.ticketTypeLabel.TabIndex = 1;
            this.ticketTypeLabel.Text = "     Ticket type";
            this.ticketTypeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // locationlabel
            // 
            this.locationlabel.AutoSize = true;
            this.locationlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.locationlabel.Image = ((System.Drawing.Image)(resources.GetObject("locationlabel.Image")));
            this.locationlabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.locationlabel.Location = new System.Drawing.Point(4, 15);
            this.locationlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.locationlabel.Name = "locationlabel";
            this.locationlabel.Size = new System.Drawing.Size(237, 31);
            this.locationlabel.TabIndex = 3;
            this.locationlabel.Text = "    Choose location";
            this.locationlabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // chooselabel
            // 
            this.chooselabel.AutoSize = true;
            this.chooselabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chooselabel.Image = ((System.Drawing.Image)(resources.GetObject("chooselabel.Image")));
            this.chooselabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.chooselabel.Location = new System.Drawing.Point(4, 37);
            this.chooselabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.chooselabel.Name = "chooselabel";
            this.chooselabel.Size = new System.Drawing.Size(215, 31);
            this.chooselabel.TabIndex = 4;
            this.chooselabel.Text = "     Choose ticket";
            this.chooselabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ticketTypecomboBox
            // 
            this.ticketTypecomboBox.FormattingEnabled = true;
            this.ticketTypecomboBox.Items.AddRange(new object[] {
            "Movie Ticket",
            "Bus Ticket",
            "Concert Ticket",
            "Cricket Ticket"});
            this.ticketTypecomboBox.Location = new System.Drawing.Point(282, 116);
            this.ticketTypecomboBox.Margin = new System.Windows.Forms.Padding(4);
            this.ticketTypecomboBox.Name = "ticketTypecomboBox";
            this.ticketTypecomboBox.Size = new System.Drawing.Size(143, 24);
            this.ticketTypecomboBox.TabIndex = 5;
            this.toolTip1.SetToolTip(this.ticketTypecomboBox, "Select your ticket type and double click on the field to show other information.");
            this.ticketTypecomboBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ticketTypecomboBox_MouseClick);
            // 
            // ticketcomboBox
            // 
            this.ticketcomboBox.FormattingEnabled = true;
            this.ticketcomboBox.Location = new System.Drawing.Point(266, 37);
            this.ticketcomboBox.Margin = new System.Windows.Forms.Padding(4);
            this.ticketcomboBox.Name = "ticketcomboBox";
            this.ticketcomboBox.Size = new System.Drawing.Size(143, 24);
            this.ticketcomboBox.TabIndex = 6;
            this.toolTip1.SetToolTip(this.ticketcomboBox, "Select ticket name");
            // 
            // locationcomboBox
            // 
            this.locationcomboBox.FormattingEnabled = true;
            this.locationcomboBox.Location = new System.Drawing.Point(266, 22);
            this.locationcomboBox.Margin = new System.Windows.Forms.Padding(4);
            this.locationcomboBox.Name = "locationcomboBox";
            this.locationcomboBox.Size = new System.Drawing.Size(143, 24);
            this.locationcomboBox.TabIndex = 7;
            this.toolTip1.SetToolTip(this.locationcomboBox, "Choose the location");
            this.locationcomboBox.SelectedIndexChanged += new System.EventHandler(this.locationcomboBox_SelectedIndexChanged);
            // 
            // backbutton
            // 
            this.backbutton.Image = ((System.Drawing.Image)(resources.GetObject("backbutton.Image")));
            this.backbutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.backbutton.Location = new System.Drawing.Point(763, 29);
            this.backbutton.Margin = new System.Windows.Forms.Padding(4);
            this.backbutton.Name = "backbutton";
            this.backbutton.Size = new System.Drawing.Size(49, 39);
            this.backbutton.TabIndex = 19;
            this.backbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.backbutton, "Go back to login page");
            this.backbutton.UseVisualStyleBackColor = true;
            this.backbutton.Click += new System.EventHandler(this.backbutton_Click);
            // 
            // accountbutton
            // 
            this.accountbutton.Image = ((System.Drawing.Image)(resources.GetObject("accountbutton.Image")));
            this.accountbutton.Location = new System.Drawing.Point(16, 109);
            this.accountbutton.Margin = new System.Windows.Forms.Padding(4);
            this.accountbutton.Name = "accountbutton";
            this.accountbutton.Size = new System.Drawing.Size(45, 39);
            this.accountbutton.TabIndex = 20;
            this.toolTip1.SetToolTip(this.accountbutton, "Check your account");
            this.accountbutton.UseVisualStyleBackColor = true;
            this.accountbutton.Click += new System.EventHandler(this.accountbutton_Click);
            // 
            // button1
            // 
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(17, 156);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(44, 39);
            this.button1.TabIndex = 21;
            this.toolTip1.SetToolTip(this.button1, "Log out fom your account");
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // exitbutton
            // 
            this.exitbutton.Image = ((System.Drawing.Image)(resources.GetObject("exitbutton.Image")));
            this.exitbutton.Location = new System.Drawing.Point(17, 203);
            this.exitbutton.Margin = new System.Windows.Forms.Padding(4);
            this.exitbutton.Name = "exitbutton";
            this.exitbutton.Size = new System.Drawing.Size(44, 39);
            this.exitbutton.TabIndex = 39;
            this.toolTip1.SetToolTip(this.exitbutton, "Click here to exit");
            this.exitbutton.UseVisualStyleBackColor = true;
            this.exitbutton.Click += new System.EventHandler(this.exitbutton_Click);
            // 
            // requestbutton
            // 
            this.requestbutton.Image = ((System.Drawing.Image)(resources.GetObject("requestbutton.Image")));
            this.requestbutton.Location = new System.Drawing.Point(14, 62);
            this.requestbutton.Margin = new System.Windows.Forms.Padding(4);
            this.requestbutton.Name = "requestbutton";
            this.requestbutton.Size = new System.Drawing.Size(45, 39);
            this.requestbutton.TabIndex = 40;
            this.toolTip1.SetToolTip(this.requestbutton, "Send a request for selling ticket");
            this.requestbutton.UseVisualStyleBackColor = true;
            this.requestbutton.Click += new System.EventHandler(this.requestbutton_Click);
            // 
            // menupanel
            // 
            this.menupanel.Controls.Add(this.searchbutton);
            this.menupanel.Controls.Add(this.exitbutton);
            this.menupanel.Controls.Add(this.requestbutton);
            this.menupanel.Controls.Add(this.button1);
            this.menupanel.Controls.Add(this.accountbutton);
            this.menupanel.Location = new System.Drawing.Point(806, 98);
            this.menupanel.Margin = new System.Windows.Forms.Padding(4);
            this.menupanel.Name = "menupanel";
            this.menupanel.Size = new System.Drawing.Size(77, 252);
            this.menupanel.TabIndex = 41;
            this.menupanel.Visible = false;
            // 
            // searchbutton
            // 
            this.searchbutton.Image = ((System.Drawing.Image)(resources.GetObject("searchbutton.Image")));
            this.searchbutton.Location = new System.Drawing.Point(15, 15);
            this.searchbutton.Margin = new System.Windows.Forms.Padding(4);
            this.searchbutton.Name = "searchbutton";
            this.searchbutton.Size = new System.Drawing.Size(45, 39);
            this.searchbutton.TabIndex = 43;
            this.toolTip1.SetToolTip(this.searchbutton, "Search your ticket");
            this.searchbutton.UseVisualStyleBackColor = true;
            this.searchbutton.Click += new System.EventHandler(this.searchbutton_Click);
            // 
            // menubutton
            // 
            this.menubutton.Image = ((System.Drawing.Image)(resources.GetObject("menubutton.Image")));
            this.menubutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menubutton.Location = new System.Drawing.Point(820, 29);
            this.menubutton.Margin = new System.Windows.Forms.Padding(4);
            this.menubutton.Name = "menubutton";
            this.menubutton.Size = new System.Drawing.Size(45, 39);
            this.menubutton.TabIndex = 42;
            this.menubutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.menubutton, "Select menu");
            this.menubutton.UseVisualStyleBackColor = true;
            this.menubutton.Click += new System.EventHandler(this.menubutton_Click);
            // 
            // searchtextBox
            // 
            this.searchtextBox.Location = new System.Drawing.Point(20, 19);
            this.searchtextBox.Margin = new System.Windows.Forms.Padding(4);
            this.searchtextBox.Multiline = true;
            this.searchtextBox.Name = "searchtextBox";
            this.searchtextBox.Size = new System.Drawing.Size(180, 41);
            this.searchtextBox.TabIndex = 1;
            this.toolTip1.SetToolTip(this.searchtextBox, "Enter your key word here");
            this.searchtextBox.TextChanged += new System.EventHandler(this.searchtextBox_TextChanged);
            // 
            // proccedbutton
            // 
            this.proccedbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.proccedbutton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.proccedbutton.Image = ((System.Drawing.Image)(resources.GetObject("proccedbutton.Image")));
            this.proccedbutton.Location = new System.Drawing.Point(433, 107);
            this.proccedbutton.Margin = new System.Windows.Forms.Padding(4);
            this.proccedbutton.Name = "proccedbutton";
            this.proccedbutton.Size = new System.Drawing.Size(43, 41);
            this.proccedbutton.TabIndex = 46;
            this.proccedbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.proccedbutton, "Select your ticket type and double click on the field to show other information");
            this.proccedbutton.UseVisualStyleBackColor = true;
            this.proccedbutton.Click += new System.EventHandler(this.proccedbutton_Click);
            // 
            // donebutton
            // 
            this.donebutton.Image = ((System.Drawing.Image)(resources.GetObject("donebutton.Image")));
            this.donebutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.donebutton.Location = new System.Drawing.Point(112, 155);
            this.donebutton.Margin = new System.Windows.Forms.Padding(4);
            this.donebutton.Name = "donebutton";
            this.donebutton.Size = new System.Drawing.Size(121, 47);
            this.donebutton.TabIndex = 16;
            this.donebutton.Text = "Done";
            this.donebutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.donebutton, "Click here to procced");
            this.donebutton.UseVisualStyleBackColor = true;
            this.donebutton.Click += new System.EventHandler(this.donebutton_Click);
            // 
            // quantitycomboBox
            // 
            this.quantitycomboBox.FormattingEnabled = true;
            this.quantitycomboBox.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.quantitycomboBox.Location = new System.Drawing.Point(234, 105);
            this.quantitycomboBox.Margin = new System.Windows.Forms.Padding(4);
            this.quantitycomboBox.Name = "quantitycomboBox";
            this.quantitycomboBox.Size = new System.Drawing.Size(65, 24);
            this.quantitycomboBox.TabIndex = 15;
            this.toolTip1.SetToolTip(this.quantitycomboBox, "Select ticket quantity");
            // 
            // timecomboBox
            // 
            this.timecomboBox.FormattingEnabled = true;
            this.timecomboBox.Location = new System.Drawing.Point(234, 37);
            this.timecomboBox.Margin = new System.Windows.Forms.Padding(4);
            this.timecomboBox.Name = "timecomboBox";
            this.timecomboBox.Size = new System.Drawing.Size(65, 24);
            this.timecomboBox.TabIndex = 13;
            this.toolTip1.SetToolTip(this.timecomboBox, "Select desired time");
            // 
            // chooseticketbutton
            // 
            this.chooseticketbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chooseticketbutton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.chooseticketbutton.Image = ((System.Drawing.Image)(resources.GetObject("chooseticketbutton.Image")));
            this.chooseticketbutton.Location = new System.Drawing.Point(417, 27);
            this.chooseticketbutton.Margin = new System.Windows.Forms.Padding(4);
            this.chooseticketbutton.Name = "chooseticketbutton";
            this.chooseticketbutton.Size = new System.Drawing.Size(43, 41);
            this.chooseticketbutton.TabIndex = 47;
            this.chooseticketbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.chooseticketbutton, "Select your ticket name and double click on the field to show other information");
            this.chooseticketbutton.UseVisualStyleBackColor = true;
            this.chooseticketbutton.Click += new System.EventHandler(this.chooseticketbutton_Click);
            // 
            // locationbutton
            // 
            this.locationbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.locationbutton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.locationbutton.Image = ((System.Drawing.Image)(resources.GetObject("locationbutton.Image")));
            this.locationbutton.Location = new System.Drawing.Point(417, 12);
            this.locationbutton.Margin = new System.Windows.Forms.Padding(4);
            this.locationbutton.Name = "locationbutton";
            this.locationbutton.Size = new System.Drawing.Size(43, 41);
            this.locationbutton.TabIndex = 47;
            this.locationbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.locationbutton, "Select your location and double click on the field to show other information");
            this.locationbutton.UseVisualStyleBackColor = true;
            this.locationbutton.Click += new System.EventHandler(this.locationbutton_Click);
            // 
            // searchb
            // 
            this.searchb.Image = ((System.Drawing.Image)(resources.GetObject("searchb.Image")));
            this.searchb.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.searchb.Location = new System.Drawing.Point(208, 18);
            this.searchb.Margin = new System.Windows.Forms.Padding(4);
            this.searchb.Name = "searchb";
            this.searchb.Size = new System.Drawing.Size(49, 42);
            this.searchb.TabIndex = 17;
            this.searchb.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.searchb, "Click here to procced");
            this.searchb.UseVisualStyleBackColor = true;
            this.searchb.Click += new System.EventHandler(this.searchb_Click);
            // 
            // ticketpanel
            // 
            this.ticketpanel.Controls.Add(this.timelabel);
            this.ticketpanel.Controls.Add(this.donebutton);
            this.ticketpanel.Controls.Add(this.quantitycomboBox);
            this.ticketpanel.Controls.Add(this.timecomboBox);
            this.ticketpanel.Controls.Add(this.quantitylabel);
            this.ticketpanel.Location = new System.Drawing.Point(484, 166);
            this.ticketpanel.Margin = new System.Windows.Forms.Padding(4);
            this.ticketpanel.Name = "ticketpanel";
            this.ticketpanel.Size = new System.Drawing.Size(320, 206);
            this.ticketpanel.TabIndex = 43;
            this.ticketpanel.Visible = false;
            // 
            // timelabel
            // 
            this.timelabel.AutoSize = true;
            this.timelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timelabel.Image = ((System.Drawing.Image)(resources.GetObject("timelabel.Image")));
            this.timelabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.timelabel.Location = new System.Drawing.Point(14, 30);
            this.timelabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.timelabel.Name = "timelabel";
            this.timelabel.Size = new System.Drawing.Size(201, 31);
            this.timelabel.TabIndex = 12;
            this.timelabel.Text = "     Choose time";
            this.timelabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // quantitylabel
            // 
            this.quantitylabel.AutoSize = true;
            this.quantitylabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quantitylabel.Image = ((System.Drawing.Image)(resources.GetObject("quantitylabel.Image")));
            this.quantitylabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.quantitylabel.Location = new System.Drawing.Point(14, 105);
            this.quantitylabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.quantitylabel.Name = "quantitylabel";
            this.quantitylabel.Size = new System.Drawing.Size(151, 31);
            this.quantitylabel.TabIndex = 14;
            this.quantitylabel.Text = "     Quantity";
            this.quantitylabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // searchpanel
            // 
            this.searchpanel.Controls.Add(this.searchb);
            this.searchpanel.Controls.Add(this.searchtextBox);
            this.searchpanel.Location = new System.Drawing.Point(541, 98);
            this.searchpanel.Margin = new System.Windows.Forms.Padding(4);
            this.searchpanel.Name = "searchpanel";
            this.searchpanel.Size = new System.Drawing.Size(263, 69);
            this.searchpanel.TabIndex = 45;
            this.searchpanel.Visible = false;
            // 
            // chooseTicketpanel
            // 
            this.chooseTicketpanel.Controls.Add(this.chooseticketbutton);
            this.chooseTicketpanel.Controls.Add(this.chooselabel);
            this.chooseTicketpanel.Controls.Add(this.ticketcomboBox);
            this.chooseTicketpanel.Location = new System.Drawing.Point(16, 166);
            this.chooseTicketpanel.Margin = new System.Windows.Forms.Padding(4);
            this.chooseTicketpanel.Name = "chooseTicketpanel";
            this.chooseTicketpanel.Size = new System.Drawing.Size(460, 92);
            this.chooseTicketpanel.TabIndex = 47;
            this.chooseTicketpanel.Visible = false;
            // 
            // Locationpanel
            // 
            this.Locationpanel.Controls.Add(this.locationbutton);
            this.Locationpanel.Controls.Add(this.locationlabel);
            this.Locationpanel.Controls.Add(this.locationcomboBox);
            this.Locationpanel.Location = new System.Drawing.Point(16, 266);
            this.Locationpanel.Margin = new System.Windows.Forms.Padding(4);
            this.Locationpanel.Name = "Locationpanel";
            this.Locationpanel.Size = new System.Drawing.Size(460, 84);
            this.Locationpanel.TabIndex = 48;
            this.Locationpanel.Visible = false;
            // 
            // TicketInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(878, 409);
            this.Controls.Add(this.Locationpanel);
            this.Controls.Add(this.chooseTicketpanel);
            this.Controls.Add(this.proccedbutton);
            this.Controls.Add(this.searchpanel);
            this.Controls.Add(this.ticketpanel);
            this.Controls.Add(this.menubutton);
            this.Controls.Add(this.backbutton);
            this.Controls.Add(this.menupanel);
            this.Controls.Add(this.ticketTypecomboBox);
            this.Controls.Add(this.ticketTypeLabel);
            this.Controls.Add(this.header);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "TicketInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ticket Info";
            this.Load += new System.EventHandler(this.TicketInfo_Load);
            this.Click += new System.EventHandler(this.TicketInfo_Click);
            this.menupanel.ResumeLayout(false);
            this.ticketpanel.ResumeLayout(false);
            this.ticketpanel.PerformLayout();
            this.searchpanel.ResumeLayout(false);
            this.searchpanel.PerformLayout();
            this.chooseTicketpanel.ResumeLayout(false);
            this.chooseTicketpanel.PerformLayout();
            this.Locationpanel.ResumeLayout(false);
            this.Locationpanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label header;
        private System.Windows.Forms.Label ticketTypeLabel;
        private System.Windows.Forms.Label locationlabel;
        private System.Windows.Forms.Label chooselabel;
        private System.Windows.Forms.ComboBox ticketTypecomboBox;
        private System.Windows.Forms.ComboBox ticketcomboBox;
        private System.Windows.Forms.ComboBox locationcomboBox;
        private System.Windows.Forms.Button backbutton;
        private System.Windows.Forms.Button accountbutton;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button exitbutton;
        private System.Windows.Forms.Button requestbutton;
        private System.Windows.Forms.Panel menupanel;
        private System.Windows.Forms.Button menubutton;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button searchbutton;
        private System.Windows.Forms.Panel ticketpanel;
        private System.Windows.Forms.Panel searchpanel;
        private System.Windows.Forms.TextBox searchtextBox;
        private System.Windows.Forms.Button proccedbutton;
        private System.Windows.Forms.Panel chooseTicketpanel;
        private System.Windows.Forms.Panel Locationpanel;
        private System.Windows.Forms.Label timelabel;
        private System.Windows.Forms.Button donebutton;
        private System.Windows.Forms.ComboBox quantitycomboBox;
        private System.Windows.Forms.ComboBox timecomboBox;
        private System.Windows.Forms.Label quantitylabel;
        private System.Windows.Forms.Button chooseticketbutton;
        private System.Windows.Forms.Button locationbutton;
        private System.Windows.Forms.Button searchb;
    }
}
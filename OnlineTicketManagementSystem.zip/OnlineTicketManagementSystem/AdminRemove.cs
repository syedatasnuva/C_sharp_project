﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace OnlineTicketManagementSystem
{
    public partial class AdminRemove : Form
    {
        string gmail = "", tickettype = "";

        public AdminRemove()
        {
            InitializeComponent();
        }

        private void backbutton1_Click(object sender, EventArgs e)
        {
            AdminForm admin = new AdminForm();
            this.Hide();
            admin.ShowDialog();
        }

        private void menubutton_Click(object sender, EventArgs e)
        {
            if (menupanel.Visible == false)
            {
                menupanel.Visible = true;
            }
            else if (menupanel.Visible == true)
            {
                menupanel.Visible = false;
            }
        }

        private void logoutbutton1_Click(object sender, EventArgs e)
        {
            LogIn login = new LogIn();
            this.Hide();
            login.ShowDialog();
        }

        private void exitbutton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void AdminRemove_Load(object sender, EventArgs e)
        {
            warnlabel.Visible = false;
        }

        private void procceedbutton_Click(object sender, EventArgs e)
        {
            SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");
            string query = "";


            if (ticketTypecomboBox.Text == "Movie Ticket")
            {
                query = "select * from movie";
            }
            else if (ticketTypecomboBox.Text == "Bus Ticket")
            {
                query = "select * from bus";
            }
            else if (ticketTypecomboBox.Text == "Concert Ticket")
            {
                query = "select * from concert";
            }
            else if (ticketTypecomboBox.Text == "Cricket Ticket")
            {
                query = "select * from cricket";
            }
            else if (ticketTypecomboBox.Text == "")
            {
                MessageBox.Show("First select a ticket type.");
            }
            //.....
            ticketcomboBox.Items.Clear();
            SqlCommand cmd = new SqlCommand(query, sql);
            SqlDataReader dr;
            try
            {
                sql.Open();
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    string tname = dr.GetString(0);
                    ticketcomboBox.Items.Add(tname);
                }
                chooseTicketpanel.Visible = true;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }
        }

        private void submitbutton_Click(object sender, EventArgs e)
        {
            string tickettype = ticketTypecomboBox.GetItemText(this.ticketTypecomboBox.SelectedItem);
            string ticketnames = ticketcomboBox.GetItemText(this.ticketcomboBox.SelectedItem);
            string ticketloc = locationcomboBox.GetItemText(this.locationcomboBox.SelectedItem);
            string tickettime = timecomboBox.GetItemText(this.timecomboBox.SelectedItem);

            SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");
            string query = "";
            sql.Open();
            if (tickettype.Equals("Movie Ticket"))
            {
                query = "delete from movie_ticket where movie_name='" + ticketnames + "' and movie_location='" + ticketloc + "' and movie_time='" + tickettime + "'";
            }
            else if (tickettype.Equals("Bus Ticket"))
            {
                query = "delete from bus_tickets where bus_name='" + ticketnames + "' and bus_location='" + ticketloc + "' and bus_time='" + tickettime + "'";
            }
            else if (tickettype.Equals("Concert Ticket"))
            {
                query = "delete from concert_ticket where concert_name='" + ticketnames + "' and concert_location='" + ticketloc + "' and concert_time='" + tickettime + "'";
            }
            else if (tickettype.Equals("Cricket Ticket"))
            {
                query = "delete from cricket_ticket where cricket_name='" + ticketnames + "' and cricket_location='" + ticketloc + "' and cricket_time='" + tickettime + "'";
            }
            
            try
            {
                SqlCommand cmd = new SqlCommand(query, sql);
                int value = cmd.ExecuteNonQuery();

                if (value == 1)
                {
                    MessageBox.Show("Ticket is deleted succesfully.","Done");
                }
                else
                {
                    MessageBox.Show("Ticket isn't deleted succesfully.", "Failed");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void chooseticketbutton_Click(object sender, EventArgs e)
        {
            if (ticketcomboBox.Text != "")
            {
                SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");
                string query = "";


                if (ticketTypecomboBox.Text == "Movie Ticket")
                {
                    query = "select * from movie_ticket where movie_name='" + ticketcomboBox.GetItemText(this.ticketcomboBox.SelectedItem) + "'";
                }
                else if (ticketTypecomboBox.Text == "Bus Ticket")
                {
                    query = "select * from bus_tickets where bus_name='" + ticketcomboBox.GetItemText(this.ticketcomboBox.SelectedItem) + "'";
                }
                else if (ticketTypecomboBox.Text == "Concert Ticket")
                {
                    query = "select * from concert_ticket where concert_name='" + ticketcomboBox.GetItemText(this.ticketcomboBox.SelectedItem) + "'";
                }
                else if (ticketTypecomboBox.Text == "Cricket Ticket")
                {
                    query = "select * from cricket_ticket where cricket_name='" + ticketcomboBox.GetItemText(this.ticketcomboBox.SelectedItem) + "'";
                }
                else if (ticketTypecomboBox.Text == "")
                {
                    MessageBox.Show("First select a ticket type.");
                }
                //.....

                locationcomboBox.Items.Clear();
                SqlCommand cmd = new SqlCommand(query, sql);
                SqlDataReader dr;
                try
                {
                    sql.Open();
                    dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        string tname = dr.GetString(2);
                        if (locationcomboBox.Items.Contains(tname))
                        {
                        }
                        else
                        {
                            locationcomboBox.Items.Add(tname);
                        }
                    }
                    Locationpanel.Visible = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
            else if (ticketcomboBox.Text == "")
            {
                MessageBox.Show("First select a ticket name.");
            }
        }

        private void locationbutton_Click(object sender, EventArgs e)
        {
            if (locationcomboBox.Text != "")
            {
                SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");
                string query = "";


                if (ticketTypecomboBox.Text == "Movie Ticket")
                {
                    query = "select * from movie_ticket where movie_name='" + ticketcomboBox.GetItemText(this.ticketcomboBox.SelectedItem) + "' and movie_location='" + locationcomboBox.GetItemText(this.locationcomboBox.SelectedItem) + "'";
                }
                else if (ticketTypecomboBox.Text == "Bus Ticket")
                {
                    query = "select * from bus_tickets where bus_name='" + ticketcomboBox.GetItemText(this.ticketcomboBox.SelectedItem) + "' and bus_location='" + locationcomboBox.GetItemText(this.locationcomboBox.SelectedItem) + "'";
                }
                else if (ticketTypecomboBox.Text == "Concert Ticket")
                {
                    query = "select * from concert_ticket where concert_name='" + ticketcomboBox.GetItemText(this.ticketcomboBox.SelectedItem) + "' and concert_location='" + locationcomboBox.GetItemText(this.locationcomboBox.SelectedItem) + "'";
                }
                else if (ticketTypecomboBox.Text == "Cricket Ticket")
                {
                    query = "select * from cricket_ticket where cricket_name='" + ticketcomboBox.GetItemText(this.ticketcomboBox.SelectedItem) + "' and cricket_location='" + locationcomboBox.GetItemText(this.locationcomboBox.SelectedItem) + "'";
                }
                else if (ticketTypecomboBox.Text == "")
                {
                    MessageBox.Show("First select a ticket type.");
                }
                //.....

                timecomboBox.Items.Clear();
                SqlCommand cmd = new SqlCommand(query, sql);
                SqlDataReader dr;
                try
                {
                    sql.Open();
                    dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        string tname = dr.GetString(1);
                        if (timecomboBox.Items.Contains(tname))
                        {
                        }
                        else
                        {
                            timecomboBox.Items.Add(tname);
                        }
                    }
                    ticketpanel.Visible = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
            else if (locationcomboBox.Text == "")
            {
                MessageBox.Show("First select a location.");
            }
        }
    }
}

﻿namespace OnlineTicketManagementSystem
{
    partial class Payment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Payment));
            this.logoutbutton = new System.Windows.Forms.Button();
            this.accountbutton = new System.Windows.Forms.Button();
            this.backbutton = new System.Windows.Forms.Button();
            this.header = new System.Windows.Forms.Label();
            this.paymentbutton = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.panel = new System.Windows.Forms.Panel();
            this.ticketTime = new System.Windows.Forms.Label();
            this.timelabel = new System.Windows.Forms.Label();
            this.ticketprice = new System.Windows.Forms.Label();
            this.quantity = new System.Windows.Forms.Label();
            this.totalprice = new System.Windows.Forms.Label();
            this.seatNumber = new System.Windows.Forms.Label();
            this.ticketname = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.selectedticketlabel = new System.Windows.Forms.Label();
            this.exitbutton = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.menubutton = new System.Windows.Forms.Button();
            this.menupanel = new System.Windows.Forms.Panel();
            this.panel.SuspendLayout();
            this.menupanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // logoutbutton
            // 
            this.logoutbutton.Image = ((System.Drawing.Image)(resources.GetObject("logoutbutton.Image")));
            this.logoutbutton.Location = new System.Drawing.Point(17, 71);
            this.logoutbutton.Margin = new System.Windows.Forms.Padding(4);
            this.logoutbutton.Name = "logoutbutton";
            this.logoutbutton.Size = new System.Drawing.Size(44, 39);
            this.logoutbutton.TabIndex = 25;
            this.toolTip1.SetToolTip(this.logoutbutton, "LogOut from your account.");
            this.logoutbutton.UseVisualStyleBackColor = true;
            this.logoutbutton.Click += new System.EventHandler(this.logoutbutton_Click);
            // 
            // accountbutton
            // 
            this.accountbutton.Image = ((System.Drawing.Image)(resources.GetObject("accountbutton.Image")));
            this.accountbutton.Location = new System.Drawing.Point(16, 20);
            this.accountbutton.Margin = new System.Windows.Forms.Padding(4);
            this.accountbutton.Name = "accountbutton";
            this.accountbutton.Size = new System.Drawing.Size(45, 39);
            this.accountbutton.TabIndex = 24;
            this.toolTip1.SetToolTip(this.accountbutton, "Check your account.");
            this.accountbutton.UseVisualStyleBackColor = true;
            this.accountbutton.Click += new System.EventHandler(this.accountbutton_Click);
            // 
            // backbutton
            // 
            this.backbutton.Image = ((System.Drawing.Image)(resources.GetObject("backbutton.Image")));
            this.backbutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.backbutton.Location = new System.Drawing.Point(771, 15);
            this.backbutton.Margin = new System.Windows.Forms.Padding(4);
            this.backbutton.Name = "backbutton";
            this.backbutton.Size = new System.Drawing.Size(45, 39);
            this.backbutton.TabIndex = 23;
            this.backbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.backbutton, "Go back to Ticket information page.");
            this.backbutton.UseVisualStyleBackColor = true;
            this.backbutton.Click += new System.EventHandler(this.backbutton_Click);
            // 
            // header
            // 
            this.header.AutoSize = true;
            this.header.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.header.Location = new System.Drawing.Point(111, 62);
            this.header.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.header.Name = "header";
            this.header.Size = new System.Drawing.Size(576, 39);
            this.header.TabIndex = 22;
            this.header.Text = "Online Ticket Management System";
            // 
            // paymentbutton
            // 
            this.paymentbutton.Image = ((System.Drawing.Image)(resources.GetObject("paymentbutton.Image")));
            this.paymentbutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.paymentbutton.Location = new System.Drawing.Point(345, 350);
            this.paymentbutton.Margin = new System.Windows.Forms.Padding(4);
            this.paymentbutton.Name = "paymentbutton";
            this.paymentbutton.Size = new System.Drawing.Size(120, 44);
            this.paymentbutton.TabIndex = 36;
            this.paymentbutton.Text = "Procced";
            this.paymentbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.paymentbutton, "Clear the payment to get your ticket.");
            this.paymentbutton.UseVisualStyleBackColor = true;
            this.paymentbutton.Click += new System.EventHandler(this.paymentbutton_Click);
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.Filter = "All Files|*.txt| All files|*.docx|all Files|*.jpg";
            // 
            // panel
            // 
            this.panel.Controls.Add(this.ticketTime);
            this.panel.Controls.Add(this.timelabel);
            this.panel.Controls.Add(this.ticketprice);
            this.panel.Controls.Add(this.quantity);
            this.panel.Controls.Add(this.totalprice);
            this.panel.Controls.Add(this.seatNumber);
            this.panel.Controls.Add(this.ticketname);
            this.panel.Controls.Add(this.label4);
            this.panel.Controls.Add(this.label3);
            this.panel.Controls.Add(this.label2);
            this.panel.Controls.Add(this.label1);
            this.panel.Controls.Add(this.selectedticketlabel);
            this.panel.Location = new System.Drawing.Point(119, 103);
            this.panel.Margin = new System.Windows.Forms.Padding(4);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(613, 239);
            this.panel.TabIndex = 37;
            // 
            // ticketTime
            // 
            this.ticketTime.AutoSize = true;
            this.ticketTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ticketTime.Location = new System.Drawing.Point(239, 151);
            this.ticketTime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ticketTime.Name = "ticketTime";
            this.ticketTime.Size = new System.Drawing.Size(60, 25);
            this.ticketTime.TabIndex = 47;
            this.ticketTime.Text = "Time";
            // 
            // timelabel
            // 
            this.timelabel.AutoSize = true;
            this.timelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timelabel.Location = new System.Drawing.Point(20, 151);
            this.timelabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.timelabel.Name = "timelabel";
            this.timelabel.Size = new System.Drawing.Size(173, 24);
            this.timelabel.TabIndex = 46;
            this.timelabel.Text = "Selected time     :";
            // 
            // ticketprice
            // 
            this.ticketprice.AutoSize = true;
            this.ticketprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ticketprice.Location = new System.Drawing.Point(240, 49);
            this.ticketprice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ticketprice.Name = "ticketprice";
            this.ticketprice.Size = new System.Drawing.Size(116, 25);
            this.ticketprice.TabIndex = 45;
            this.ticketprice.Text = "ticket price";
            // 
            // quantity
            // 
            this.quantity.AutoSize = true;
            this.quantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quantity.Location = new System.Drawing.Point(240, 85);
            this.quantity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.quantity.Name = "quantity";
            this.quantity.Size = new System.Drawing.Size(145, 25);
            this.quantity.TabIndex = 44;
            this.quantity.Text = "ticket quantity";
            // 
            // totalprice
            // 
            this.totalprice.AutoSize = true;
            this.totalprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalprice.Location = new System.Drawing.Point(240, 118);
            this.totalprice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.totalprice.Name = "totalprice";
            this.totalprice.Size = new System.Drawing.Size(106, 25);
            this.totalprice.TabIndex = 43;
            this.totalprice.Text = "total price";
            // 
            // seatNumber
            // 
            this.seatNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seatNumber.Location = new System.Drawing.Point(238, 186);
            this.seatNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.seatNumber.Name = "seatNumber";
            this.seatNumber.Size = new System.Drawing.Size(371, 47);
            this.seatNumber.TabIndex = 42;
            this.seatNumber.Text = "Seat Number";
            // 
            // ticketname
            // 
            this.ticketname.AutoSize = true;
            this.ticketname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ticketname.Location = new System.Drawing.Point(240, 14);
            this.ticketname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ticketname.Name = "ticketname";
            this.ticketname.Size = new System.Drawing.Size(122, 25);
            this.ticketname.TabIndex = 41;
            this.ticketname.Text = "ticket name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(20, 182);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(171, 24);
            this.label4.TabIndex = 40;
            this.label4.Text = "Seat number      :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(20, 49);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(173, 24);
            this.label3.TabIndex = 39;
            this.label3.Text = "Ticket price        :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(20, 85);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(174, 24);
            this.label2.TabIndex = 38;
            this.label2.Text = "Ticket quantity    :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 118);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(175, 24);
            this.label1.TabIndex = 37;
            this.label1.Text = "Total price          :";
            // 
            // selectedticketlabel
            // 
            this.selectedticketlabel.AutoSize = true;
            this.selectedticketlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectedticketlabel.Location = new System.Drawing.Point(20, 14);
            this.selectedticketlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.selectedticketlabel.Name = "selectedticketlabel";
            this.selectedticketlabel.Size = new System.Drawing.Size(172, 24);
            this.selectedticketlabel.TabIndex = 36;
            this.selectedticketlabel.Text = "Selected Ticket  :";
            // 
            // exitbutton
            // 
            this.exitbutton.Image = ((System.Drawing.Image)(resources.GetObject("exitbutton.Image")));
            this.exitbutton.Location = new System.Drawing.Point(17, 122);
            this.exitbutton.Margin = new System.Windows.Forms.Padding(4);
            this.exitbutton.Name = "exitbutton";
            this.exitbutton.Size = new System.Drawing.Size(44, 39);
            this.exitbutton.TabIndex = 38;
            this.toolTip1.SetToolTip(this.exitbutton, "Click here to exit.");
            this.exitbutton.UseVisualStyleBackColor = true;
            this.exitbutton.Click += new System.EventHandler(this.exitbutton_Click);
            // 
            // menubutton
            // 
            this.menubutton.Image = ((System.Drawing.Image)(resources.GetObject("menubutton.Image")));
            this.menubutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menubutton.Location = new System.Drawing.Point(824, 13);
            this.menubutton.Margin = new System.Windows.Forms.Padding(4);
            this.menubutton.Name = "menubutton";
            this.menubutton.Size = new System.Drawing.Size(45, 39);
            this.menubutton.TabIndex = 44;
            this.menubutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTip1.SetToolTip(this.menubutton, "Select menu");
            this.menubutton.UseVisualStyleBackColor = true;
            // 
            // menupanel
            // 
            this.menupanel.Controls.Add(this.accountbutton);
            this.menupanel.Controls.Add(this.logoutbutton);
            this.menupanel.Controls.Add(this.exitbutton);
            this.menupanel.Location = new System.Drawing.Point(792, 62);
            this.menupanel.Margin = new System.Windows.Forms.Padding(4);
            this.menupanel.Name = "menupanel";
            this.menupanel.Size = new System.Drawing.Size(77, 281);
            this.menupanel.TabIndex = 43;
            this.menupanel.Visible = false;
            // 
            // Payment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(878, 409);
            this.Controls.Add(this.menubutton);
            this.Controls.Add(this.menupanel);
            this.Controls.Add(this.panel);
            this.Controls.Add(this.paymentbutton);
            this.Controls.Add(this.backbutton);
            this.Controls.Add(this.header);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "Payment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Payment";
            this.Load += new System.EventHandler(this.Payment_Load);
            this.panel.ResumeLayout(false);
            this.panel.PerformLayout();
            this.menupanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button logoutbutton;
        private System.Windows.Forms.Button accountbutton;
        private System.Windows.Forms.Button backbutton;
        private System.Windows.Forms.Label header;
        private System.Windows.Forms.Button paymentbutton;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.Label ticketprice;
        private System.Windows.Forms.Label quantity;
        private System.Windows.Forms.Label totalprice;
        private System.Windows.Forms.Label seatNumber;
        private System.Windows.Forms.Label ticketname;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label selectedticketlabel;
        private System.Windows.Forms.Label ticketTime;
        private System.Windows.Forms.Label timelabel;
        private System.Windows.Forms.Button exitbutton;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button menubutton;
        private System.Windows.Forms.Panel menupanel;
    }
}
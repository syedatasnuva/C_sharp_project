﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace OnlineTicketManagementSystem
{
    public partial class AllAccountInfo : Form
    {

        SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");

        public void loadDataGrid()
        {
            
            string query = "select name,email,priority from accounts";


            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, sql);
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;


        }


        public AllAccountInfo()
        {
            InitializeComponent();
        }

        private void AllAccountInfo_Load(object sender, EventArgs e)
        {
            loadDataGrid();
        }

        private void backbutton_Click(object sender, EventArgs e)
        {
            AdminForm admin = new AdminForm();
            this.Hide();
            admin.ShowDialog();
        }

        private void menubutton_Click(object sender, EventArgs e)
        {
            if (menupanel.Visible == false)
            {
                menupanel.Visible = true;
            }
            else if (menupanel.Visible == true)
            {
                menupanel.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LogIn login = new LogIn();
            this.Hide();
            login.ShowDialog();
        }

        private void exitbutton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

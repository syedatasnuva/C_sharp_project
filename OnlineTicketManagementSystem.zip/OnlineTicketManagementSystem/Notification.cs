﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace OnlineTicketManagementSystem
{
    public partial class Notification : Form
    {
        int tno = 0, tamount = 0, tcapacity = 0;
        string gmail = "", ttype = "", tname = "", ttime = "", tloc = "";
        SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");


        public void loadDataGrid()
        {
            string query = "select * from order_info";


            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, sql);
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;


        }

        public void loadDataGrid2()
        {
            string query = "select * from requestinfo";


            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, sql);
            adapter.Fill(dt);
            dataGridView2.DataSource = dt;

        }





        public Notification()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedCells.Count > 0)
            {
                int selectedrow = dataGridView1.SelectedCells[0].RowIndex;
                tno = int.Parse(dataGridView1.Rows[selectedrow].Cells["tno"].Value.ToString());
                gmail = dataGridView1.Rows[selectedrow].Cells["gmail"].Value.ToString();
                ttype = dataGridView1.Rows[selectedrow].Cells["ticket_type"].Value.ToString();
                tname = dataGridView1.Rows[selectedrow].Cells["ticket_name"].Value.ToString();
                ttime = dataGridView1.Rows[selectedrow].Cells["ticket_time"].Value.ToString();
                tloc = dataGridView1.Rows[selectedrow].Cells["ticket_location"].Value.ToString();
                tamount = int.Parse(dataGridView1.Rows[selectedrow].Cells["ticket_amount"].Value.ToString());
                tcapacity = int.Parse(dataGridView1.Rows[selectedrow].Cells["capacity"].Value.ToString());
            }
        }

        private void Notification_Load(object sender, EventArgs e)
        {
            loadDataGrid();
            loadDataGrid2();

        }

        private void backbutton_Click(object sender, EventArgs e)
        {
            AdminForm admin = new AdminForm();
            this.Hide();
            admin.ShowDialog();
        }

        private void menubutton_Click(object sender, EventArgs e)
        {
            if (menupanel.Visible == false)
            {
                menupanel.Visible = true;
            }
            else if (menupanel.Visible == true)
            {
                menupanel.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LogIn login = new LogIn();
            this.Hide();
            login.ShowDialog();
        }

        private void exitbutton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string mail = dataGridView2.CurrentCell.Value.ToString();

            SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");
            sql.Open();


            if (sql.State == ConnectionState.Open)
            {
                try
                {
                    string query = "update accounts set priority =" + int.Parse("2") + " where Email ='" + mail + "'";
                    SqlCommand cmd = new SqlCommand(query, sql);
                    int value = cmd.ExecuteNonQuery();

                    value = 0;

                    query = "delete from requestinfo where gmail ='" + mail + "'";
                    cmd = new SqlCommand(query, sql);
                    value = cmd.ExecuteNonQuery();

                    if (value == 1)
                    {
                        MessageBox.Show("The Account is Updated to an Premium!");
                        dataGridView1.Refresh();
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Failed attempt. Because:-" + ex.Message);
                }
            }
        }

        private void requestbutton_Click(object sender, EventArgs e)
        {
            SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");
            sql.Open();
            int insertvalue=0;
            if (sql.State == ConnectionState.Open)
            {
                try{
                        if (ttype.Equals("Movie Ticket"))
                            {
                                string insertquery = "insert into movie_ticket (movie_name,movie_time,movie_location,movie_amount,capacity) values ('" + tname + "','" + ttime + "','" + tloc + "'," + tamount + ",'" + tcapacity.ToString() + "')";
                                SqlCommand cmd = new SqlCommand(insertquery, sql);
                                insertvalue = cmd.ExecuteNonQuery();
                            }
                            else if (ttype.Equals("Bus Ticket"))
                            {

                                string insertquery = "insert into bus_tickets (bus_name,bus_time,bus_location,bus_amount,capacity) values ('" + tname + "','" + ttime + "','" + tloc + "'," + tamount + ",'" + tcapacity.ToString() + "')";
                                SqlCommand cmd = new SqlCommand(insertquery, sql);
                                insertvalue = cmd.ExecuteNonQuery();
                            }
            
                            else if (ttype.Equals("Concert Ticket"))
                            {
                                string insertquery = "insert into concert_ticket (concert_name,concert_time,concert_location,concert_amount,capacity) values ('" + tname + "','" + ttime + "','" + tloc + "'," + tamount + ",'" + tcapacity.ToString() + "')";
                                SqlCommand cmd = new SqlCommand(insertquery, sql);
                                insertvalue = cmd.ExecuteNonQuery();
                            }
          
                            else if (ttype.Equals("Cricket Ticket"))
                            {
                                string insertquery = "insert into cricket_ticket (cricket_name,cricket_time,cricket_location,cricket_amount,capacity) values ('" + tname + "','" + ttime + "','" + tloc + "'," + tamount + ",'" + tcapacity.ToString() + "')";
                                SqlCommand cmd = new SqlCommand(insertquery, sql);
                                insertvalue = cmd.ExecuteNonQuery();
                            }
                            else
                            {
                            
                            }
                        insertvalue = 0;
                        string query = "delete from order_info where tno="+tno;
                        SqlCommand cmda = new SqlCommand(query, sql);
                        insertvalue = cmda.ExecuteNonQuery();

                        if (insertvalue == 1)
                        {
                            MessageBox.Show("Ticket is added");
                            dataGridView1.Refresh();
                        }
                        else
                        {
                            MessageBox.Show("Can't add the ticket.");
                        }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Can't add ticket. Because:-"+ex.Message);
            }
            }
        }
    }

}
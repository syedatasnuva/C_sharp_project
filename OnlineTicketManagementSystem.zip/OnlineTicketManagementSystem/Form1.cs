﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace OnlineTicketManagementSystem
{
    public partial class LogIn : Form
    {
        private string connectionString = "Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True";
        int priority = 0;
        string gmail = "";

        public LogIn()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            TicketInfo ticket = new TicketInfo(gmail, priority);
            this.Hide();
            ticket.ShowDialog();
        }

        private void createaccountlink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (MessageBox.Show("Want to create a new account?", "Go to SignUp", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                CreateAccount account = new CreateAccount();
                this.Hide();
                account.ShowDialog();
            }
            else {
                this.Show();
            }
        }

        private void LoginButton_Click_1(object sender, EventArgs e)
        {
            SqlConnection sql=new SqlConnection(connectionString);
            sql.Open();

            if(sql.State==ConnectionState.Open)
            {
                string selectquery="select email,passward,priority from accounts where email='"+emailTextbox.Text+"' and passward='"+passTextbox.Text+"'";
                SqlDataAdapter adapter=new SqlDataAdapter(selectquery,sql);
                DataTable dt=new DataTable();
                adapter.Fill(dt);
               
                if(dt.Rows.Count==1)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        gmail = row.Field<string>(0);
                        priority = row.Field<int>(2);
                    }
                    if (priority == 2 || priority == 3)
                    {
                        TicketInfo ticket = new TicketInfo(gmail,priority);
                        this.Hide();
                        ticket.ShowDialog();
                    }
                    else if (priority == 1)
                    {
                        AdminForm Admin = new AdminForm();
                        this.Hide();
                        Admin.ShowDialog();
                    }
                    else if (priority == 0)
                    {
                        MessageBox.Show(gmail+" is currently disable. Try again with a valid email.");
                    }
                }
                else{
                MessageBox.Show("Invalid Id or Password.","Invalid");
                }
            
            }
          }

        private void createaccountlink_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (MessageBox.Show("Want to create a new account?", "Go to SignUp", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                CreateAccount account = new CreateAccount();
                this.Hide();
                account.ShowDialog();
            }
            else
            {
                this.Show();
            }
        }

        private void exitbutton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void remembercheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (remembercheckBox.Checked)
            {
                passTextbox.UseSystemPasswordChar = false;
            }
            else
            {
                passTextbox.UseSystemPasswordChar = true;
            }
        }

        private void emailTextbox_Leave(object sender, EventArgs e)
        {
            if (emailTextbox.Text == "")
            {
                emailsequritylabel.Visible = true;
            }
            else
            {
                emailsequritylabel.Visible = false;
            }
        }

        private void passTextbox_Leave(object sender, EventArgs e)
        {
            if (passTextbox.Text == "")
            {
                passsequritylabel.Visible = true;
            }
            else
            {
                passsequritylabel.Visible = false;
            }
        }
    }
}

﻿namespace OnlineTicketManagementSystem
{
    partial class AdminRemove
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminRemove));
            this.menupanel = new System.Windows.Forms.Panel();
            this.exitbutton = new System.Windows.Forms.Button();
            this.logoutbutton1 = new System.Windows.Forms.Button();
            this.menubutton = new System.Windows.Forms.Button();
            this.backbutton1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Locationpanel = new System.Windows.Forms.Panel();
            this.locationlabel = new System.Windows.Forms.Label();
            this.locationbutton = new System.Windows.Forms.Button();
            this.locationcomboBox = new System.Windows.Forms.ComboBox();
            this.chooseTicketpanel = new System.Windows.Forms.Panel();
            this.chooselabel = new System.Windows.Forms.Label();
            this.ticketcomboBox = new System.Windows.Forms.ComboBox();
            this.chooseticketbutton = new System.Windows.Forms.Button();
            this.timecomboBox = new System.Windows.Forms.ComboBox();
            this.procceedbutton = new System.Windows.Forms.Button();
            this.warnlabel = new System.Windows.Forms.Label();
            this.ticketTypecomboBox = new System.Windows.Forms.ComboBox();
            this.ticketTypeLabel = new System.Windows.Forms.Label();
            this.timelabel = new System.Windows.Forms.Label();
            this.submitbutton = new System.Windows.Forms.Button();
            this.ticketpanel = new System.Windows.Forms.Panel();
            this.menupanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.Locationpanel.SuspendLayout();
            this.chooseTicketpanel.SuspendLayout();
            this.ticketpanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // menupanel
            // 
            this.menupanel.Controls.Add(this.exitbutton);
            this.menupanel.Controls.Add(this.logoutbutton1);
            this.menupanel.Location = new System.Drawing.Point(593, 78);
            this.menupanel.Name = "menupanel";
            this.menupanel.Size = new System.Drawing.Size(52, 231);
            this.menupanel.TabIndex = 55;
            this.menupanel.Visible = false;
            // 
            // exitbutton
            // 
            this.exitbutton.Image = ((System.Drawing.Image)(resources.GetObject("exitbutton.Image")));
            this.exitbutton.Location = new System.Drawing.Point(7, 54);
            this.exitbutton.Name = "exitbutton";
            this.exitbutton.Size = new System.Drawing.Size(33, 32);
            this.exitbutton.TabIndex = 44;
            this.exitbutton.UseVisualStyleBackColor = true;
            this.exitbutton.Click += new System.EventHandler(this.exitbutton_Click);
            // 
            // logoutbutton1
            // 
            this.logoutbutton1.Image = ((System.Drawing.Image)(resources.GetObject("logoutbutton1.Image")));
            this.logoutbutton1.Location = new System.Drawing.Point(7, 16);
            this.logoutbutton1.Name = "logoutbutton1";
            this.logoutbutton1.Size = new System.Drawing.Size(33, 32);
            this.logoutbutton1.TabIndex = 42;
            this.logoutbutton1.UseVisualStyleBackColor = true;
            this.logoutbutton1.Click += new System.EventHandler(this.logoutbutton1_Click);
            // 
            // menubutton
            // 
            this.menubutton.Image = ((System.Drawing.Image)(resources.GetObject("menubutton.Image")));
            this.menubutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menubutton.Location = new System.Drawing.Point(611, 22);
            this.menubutton.Name = "menubutton";
            this.menubutton.Size = new System.Drawing.Size(34, 32);
            this.menubutton.TabIndex = 54;
            this.menubutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.menubutton.UseVisualStyleBackColor = true;
            this.menubutton.Click += new System.EventHandler(this.menubutton_Click);
            // 
            // backbutton1
            // 
            this.backbutton1.Image = ((System.Drawing.Image)(resources.GetObject("backbutton1.Image")));
            this.backbutton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.backbutton1.Location = new System.Drawing.Point(572, 22);
            this.backbutton1.Name = "backbutton1";
            this.backbutton1.Size = new System.Drawing.Size(34, 32);
            this.backbutton1.TabIndex = 53;
            this.backbutton1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.backbutton1.UseVisualStyleBackColor = true;
            this.backbutton1.Click += new System.EventHandler(this.backbutton1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(65, 16);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(245, 31);
            this.label1.TabIndex = 56;
            this.label1.Text = "Remove A Ticket:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.ticketpanel);
            this.panel1.Controls.Add(this.Locationpanel);
            this.panel1.Controls.Add(this.chooseTicketpanel);
            this.panel1.Controls.Add(this.procceedbutton);
            this.panel1.Controls.Add(this.warnlabel);
            this.panel1.Controls.Add(this.ticketTypecomboBox);
            this.panel1.Controls.Add(this.ticketTypeLabel);
            this.panel1.Controls.Add(this.submitbutton);
            this.panel1.Location = new System.Drawing.Point(70, 60);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(468, 262);
            this.panel1.TabIndex = 59;
            // 
            // Locationpanel
            // 
            this.Locationpanel.Controls.Add(this.locationlabel);
            this.Locationpanel.Controls.Add(this.locationbutton);
            this.Locationpanel.Controls.Add(this.locationcomboBox);
            this.Locationpanel.Location = new System.Drawing.Point(5, 123);
            this.Locationpanel.Name = "Locationpanel";
            this.Locationpanel.Size = new System.Drawing.Size(369, 47);
            this.Locationpanel.TabIndex = 60;
            this.Locationpanel.Visible = false;
            // 
            // locationlabel
            // 
            this.locationlabel.AutoSize = true;
            this.locationlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.locationlabel.Image = ((System.Drawing.Image)(resources.GetObject("locationlabel.Image")));
            this.locationlabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.locationlabel.Location = new System.Drawing.Point(3, 8);
            this.locationlabel.Name = "locationlabel";
            this.locationlabel.Size = new System.Drawing.Size(191, 25);
            this.locationlabel.TabIndex = 74;
            this.locationlabel.Text = "    Choose location";
            this.locationlabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // locationbutton
            // 
            this.locationbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.locationbutton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.locationbutton.Image = ((System.Drawing.Image)(resources.GetObject("locationbutton.Image")));
            this.locationbutton.Location = new System.Drawing.Point(327, 7);
            this.locationbutton.Name = "locationbutton";
            this.locationbutton.Size = new System.Drawing.Size(32, 33);
            this.locationbutton.TabIndex = 76;
            this.locationbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.locationbutton.UseVisualStyleBackColor = true;
            this.locationbutton.Click += new System.EventHandler(this.locationbutton_Click);
            // 
            // locationcomboBox
            // 
            this.locationcomboBox.FormattingEnabled = true;
            this.locationcomboBox.Location = new System.Drawing.Point(200, 14);
            this.locationcomboBox.Name = "locationcomboBox";
            this.locationcomboBox.Size = new System.Drawing.Size(121, 21);
            this.locationcomboBox.TabIndex = 75;
            // 
            // chooseTicketpanel
            // 
            this.chooseTicketpanel.Controls.Add(this.chooselabel);
            this.chooseTicketpanel.Controls.Add(this.ticketcomboBox);
            this.chooseTicketpanel.Controls.Add(this.chooseticketbutton);
            this.chooseTicketpanel.Location = new System.Drawing.Point(3, 66);
            this.chooseTicketpanel.Name = "chooseTicketpanel";
            this.chooseTicketpanel.Size = new System.Drawing.Size(371, 51);
            this.chooseTicketpanel.TabIndex = 60;
            this.chooseTicketpanel.Visible = false;
            // 
            // chooselabel
            // 
            this.chooselabel.AutoSize = true;
            this.chooselabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chooselabel.Image = ((System.Drawing.Image)(resources.GetObject("chooselabel.Image")));
            this.chooselabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.chooselabel.Location = new System.Drawing.Point(3, 17);
            this.chooselabel.Name = "chooselabel";
            this.chooselabel.Size = new System.Drawing.Size(162, 25);
            this.chooselabel.TabIndex = 50;
            this.chooselabel.Text = "     Ticket Name";
            this.chooselabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ticketcomboBox
            // 
            this.ticketcomboBox.FormattingEnabled = true;
            this.ticketcomboBox.Location = new System.Drawing.Point(200, 17);
            this.ticketcomboBox.Name = "ticketcomboBox";
            this.ticketcomboBox.Size = new System.Drawing.Size(121, 21);
            this.ticketcomboBox.TabIndex = 71;
            // 
            // chooseticketbutton
            // 
            this.chooseticketbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chooseticketbutton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.chooseticketbutton.Image = ((System.Drawing.Image)(resources.GetObject("chooseticketbutton.Image")));
            this.chooseticketbutton.Location = new System.Drawing.Point(330, 10);
            this.chooseticketbutton.Name = "chooseticketbutton";
            this.chooseticketbutton.Size = new System.Drawing.Size(32, 33);
            this.chooseticketbutton.TabIndex = 72;
            this.chooseticketbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.chooseticketbutton.UseVisualStyleBackColor = true;
            this.chooseticketbutton.Click += new System.EventHandler(this.chooseticketbutton_Click);
            // 
            // timecomboBox
            // 
            this.timecomboBox.FormattingEnabled = true;
            this.timecomboBox.Location = new System.Drawing.Point(200, 17);
            this.timecomboBox.Name = "timecomboBox";
            this.timecomboBox.Size = new System.Drawing.Size(121, 21);
            this.timecomboBox.TabIndex = 73;
            // 
            // procceedbutton
            // 
            this.procceedbutton.Image = ((System.Drawing.Image)(resources.GetObject("procceedbutton.Image")));
            this.procceedbutton.Location = new System.Drawing.Point(333, 22);
            this.procceedbutton.Name = "procceedbutton";
            this.procceedbutton.Size = new System.Drawing.Size(32, 27);
            this.procceedbutton.TabIndex = 53;
            this.procceedbutton.UseVisualStyleBackColor = true;
            this.procceedbutton.Click += new System.EventHandler(this.procceedbutton_Click);
            // 
            // warnlabel
            // 
            this.warnlabel.AutoSize = true;
            this.warnlabel.ForeColor = System.Drawing.Color.Red;
            this.warnlabel.Location = new System.Drawing.Point(207, 50);
            this.warnlabel.Name = "warnlabel";
            this.warnlabel.Size = new System.Drawing.Size(120, 13);
            this.warnlabel.TabIndex = 70;
            this.warnlabel.Text = "Select a ticket type first.";
            // 
            // ticketTypecomboBox
            // 
            this.ticketTypecomboBox.FormattingEnabled = true;
            this.ticketTypecomboBox.Items.AddRange(new object[] {
            "Movie Ticket",
            "Bus Ticket",
            "Concert Ticket",
            "Cricket Ticket"});
            this.ticketTypecomboBox.Location = new System.Drawing.Point(206, 26);
            this.ticketTypecomboBox.Name = "ticketTypecomboBox";
            this.ticketTypecomboBox.Size = new System.Drawing.Size(121, 21);
            this.ticketTypecomboBox.TabIndex = 57;
            // 
            // ticketTypeLabel
            // 
            this.ticketTypeLabel.AutoSize = true;
            this.ticketTypeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ticketTypeLabel.Image = ((System.Drawing.Image)(resources.GetObject("ticketTypeLabel.Image")));
            this.ticketTypeLabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ticketTypeLabel.Location = new System.Drawing.Point(9, 26);
            this.ticketTypeLabel.Name = "ticketTypeLabel";
            this.ticketTypeLabel.Size = new System.Drawing.Size(147, 25);
            this.ticketTypeLabel.TabIndex = 56;
            this.ticketTypeLabel.Text = "     Ticket type";
            this.ticketTypeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // timelabel
            // 
            this.timelabel.AutoSize = true;
            this.timelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timelabel.Image = ((System.Drawing.Image)(resources.GetObject("timelabel.Image")));
            this.timelabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.timelabel.Location = new System.Drawing.Point(3, 17);
            this.timelabel.Name = "timelabel";
            this.timelabel.Size = new System.Drawing.Size(146, 25);
            this.timelabel.TabIndex = 48;
            this.timelabel.Text = "     Ticket time";
            this.timelabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // submitbutton
            // 
            this.submitbutton.Image = ((System.Drawing.Image)(resources.GetObject("submitbutton.Image")));
            this.submitbutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.submitbutton.Location = new System.Drawing.Point(390, 223);
            this.submitbutton.Name = "submitbutton";
            this.submitbutton.Size = new System.Drawing.Size(75, 37);
            this.submitbutton.TabIndex = 47;
            this.submitbutton.Text = "Submit";
            this.submitbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.submitbutton.UseVisualStyleBackColor = true;
            this.submitbutton.Click += new System.EventHandler(this.submitbutton_Click);
            // 
            // ticketpanel
            // 
            this.ticketpanel.Controls.Add(this.timelabel);
            this.ticketpanel.Controls.Add(this.timecomboBox);
            this.ticketpanel.Location = new System.Drawing.Point(5, 176);
            this.ticketpanel.Name = "ticketpanel";
            this.ticketpanel.Size = new System.Drawing.Size(369, 50);
            this.ticketpanel.TabIndex = 60;
            this.ticketpanel.Visible = false;
            // 
            // AdminRemove
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(658, 332);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menupanel);
            this.Controls.Add(this.menubutton);
            this.Controls.Add(this.backbutton1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.Name = "AdminRemove";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Remove Ticket Menu";
            this.Load += new System.EventHandler(this.AdminRemove_Load);
            this.menupanel.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.Locationpanel.ResumeLayout(false);
            this.Locationpanel.PerformLayout();
            this.chooseTicketpanel.ResumeLayout(false);
            this.chooseTicketpanel.PerformLayout();
            this.ticketpanel.ResumeLayout(false);
            this.ticketpanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel menupanel;
        private System.Windows.Forms.Button exitbutton;
        private System.Windows.Forms.Button logoutbutton1;
        private System.Windows.Forms.Button menubutton;
        private System.Windows.Forms.Button backbutton1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button procceedbutton;
        private System.Windows.Forms.Label warnlabel;
        private System.Windows.Forms.ComboBox ticketTypecomboBox;
        private System.Windows.Forms.Label ticketTypeLabel;
        private System.Windows.Forms.Label chooselabel;
        private System.Windows.Forms.Label timelabel;
        private System.Windows.Forms.Button submitbutton;
        private System.Windows.Forms.Button chooseticketbutton;
        private System.Windows.Forms.ComboBox ticketcomboBox;
        private System.Windows.Forms.ComboBox timecomboBox;
        private System.Windows.Forms.Button locationbutton;
        private System.Windows.Forms.Label locationlabel;
        private System.Windows.Forms.ComboBox locationcomboBox;
        private System.Windows.Forms.Panel chooseTicketpanel;
        private System.Windows.Forms.Panel Locationpanel;
        private System.Windows.Forms.Panel ticketpanel;
    }
}
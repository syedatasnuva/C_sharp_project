﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace OnlineTicketManagementSystem
{
    public partial class Payment : Form
    {
        private string connectionString = "Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True";
        int priority = 0;
        string gmail = "", tickettype = "", ticketnames = "", ticketloc = "", tickettime = "", ticketquantity = "", tprice="";
        List<string> randomseats = new List<string>();
        Random rnd = new Random();
        public Payment(string gmail, int priority, string tickettype, string ticketnames, string ticketloc, string tickettime, string ticketquantity, int tprice)
        {
            this.gmail = gmail;
            this.priority = priority;
            this.tickettype = tickettype;
            this.ticketnames = ticketnames;
            this.ticketloc = ticketloc;
            this.tickettime = tickettime;
            this.ticketquantity = ticketquantity;
            this.tprice = ""+tprice;
            InitializeComponent();
        }

        private void backbutton_Click(object sender, EventArgs e)
        {
            TicketInfo ticketinfo = new TicketInfo(gmail, priority);
            this.Hide();
            ticketinfo.ShowDialog();
        }

        private void accountbutton_Click(object sender, EventArgs e)
        {
            AccountInfo accountinfo = new AccountInfo(gmail, priority);
            this.Hide();
            accountinfo.ShowDialog();
        }

        private void logoutbutton_Click(object sender, EventArgs e)
        {
            LogIn login = new LogIn();
            this.Hide();
            login.ShowDialog();
        }

        private void paymentbutton_Click(object sender, EventArgs e)
        {
            SqlConnection sql = new SqlConnection(connectionString);
            sql.Open();
            int balance = 0;
            if (sql.State == ConnectionState.Open)
            {
                string selectquery = "select * from bank_info where gmail='" +gmail+ "'";
                SqlDataAdapter adapter = new SqlDataAdapter(selectquery, sql);
                DataTable dt = new DataTable();
                adapter.Fill(dt);//this method will fills datatable with adapter values which are table rows from database_table
                if (dt.Rows.Count == 1)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        balance = row.Field<int>(3);
                    }
                }
                else
                {
                    MessageBox.Show("Don't have any bank account info.");
                }

                if (int.Parse(totalprice.Text) <= balance)
                {
                    try
                    {
                        string updatequery = "update bank_info  set balance=" + (balance - int.Parse(totalprice.Text)) + "where gmail='" + gmail + "'";
                        SqlCommand cmd = new SqlCommand(updatequery, sql);
                        int updatevalue = cmd.ExecuteNonQuery();
                        if (tickettype.Equals("Movie Ticket"))
                        {
                            updatequery = "update movie_ticket set capacity= (capacity-" + int.Parse(ticketquantity) + ") where movie_name='" + ticketnames + "' and movie_location='" + ticketloc + "' and movie_time='" + tickettime + "'";
                        }
                        else if (tickettype.Equals("Bus Ticket"))
                        {
                            updatequery = "update bus_tickets set capacity= (capacity-" + int.Parse(ticketquantity) + ") where bus_name='" + ticketnames + "' and bus_location='" + ticketloc + "' and bus_time='" + tickettime + "'";
                        }
                        else if (tickettype.Equals("Concert Ticket"))
                        {
                            updatequery = "update concert_ticket set capacity= (capacity-" + int.Parse(ticketquantity) + ") where concert_name='" + ticketnames + "' and concert_location='" + ticketloc + "' and concert_time='" + tickettime + "'";
                        }
                        else if (tickettype.Equals("Cricket Ticket"))
                        {
                            updatequery = "update cricket_ticket set capacity= (capacity-" + int.Parse(ticketquantity) + ") where cricket_name='" + ticketnames + "' and cricket_location='" + ticketloc + "' and cricket_time='" + tickettime + "'";
                        }
                        updatevalue = 0;

                        cmd = new SqlCommand(updatequery, sql);
                        updatevalue = cmd.ExecuteNonQuery();

                        if (updatevalue == 1)
                        {
                            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                            {
                                System.IO.File.WriteAllText(saveFileDialog1.FileName, "Selected Ticket   :" + ticketname.Text + "\t\nTicket price       :" + ticketprice.Text + "\t\nTicket Quantity   :" + quantity.Text + "\t\nTotal price        :" + totalprice.Text + "\t\nSelected time     :" + ticketTime.Text + "\t\nSeat number     :" + seatNumber.Text);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Not enough balance in account.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            
        }

        private void exitbutton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Payment_Load(object sender, EventArgs e)
        {
            ticketname.Text = ticketnames;
            ticketprice.Text = tprice;
            quantity.Text = ticketquantity;
            int sprice=(int.Parse(ticketprice.Text)) * (int.Parse(ticketquantity));
            totalprice.Text = "" +sprice;
            ticketTime.Text = tickettime;
            seatNumber.Text = "";
            int x=int.Parse(ticketquantity);
            for (int i = 0; i < x; i++)
            {
                string chosen="";
                do
                {
                    int seatvalue=rnd.Next(1,40);
                    chosen = "OTMS-"+seatvalue;
                } while (randomseats.Contains(chosen));

                randomseats.Add(chosen);
            }
            string allseat="";
            foreach(string textseat in randomseats)
            {
                allseat+=textseat;
                allseat += " , ";
            }
            seatNumber.Text = allseat;
        }

    }
}

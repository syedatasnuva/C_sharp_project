﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace OnlineTicketManagementSystem
{
    public partial class TicketRequest : Form
    {
        int priority = 0;
        string gmail = "",tickettype="";
        public TicketRequest(string gmail,int priority)
        {
            this.gmail = gmail;
            this.priority = priority;
            InitializeComponent();
        }

        private void menubutton_Click(object sender, EventArgs e)
        {
            if (menupanel.Visible == false)
            {
                menupanel.Visible = true;
            }
            else if (menupanel.Visible == true)
            {
                menupanel.Visible = false;
            }
        }

        private void freeUpgradebutton_Click(object sender, EventArgs e)
        {
            SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");
                sql.Open();
                if (sql.State == ConnectionState.Open)
                {
                    try
                    {
                        string insertquery = "insert into requestinfo (gmail) values ('" + gmail + "')";
                        SqlCommand cmd = new SqlCommand(insertquery, sql);
                        int insertvalue = cmd.ExecuteNonQuery();
                        if (insertvalue == 1)
                        {
                            MessageBox.Show("Request has been sent. Wait for confirmation.", "Request sent");
                        }
                        else
                        {
                            MessageBox.Show("Your request is already pending.","Failed");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Your request is already pending.", "Failed");
                    }
                }
            
        }

        private void upgradebutton_Click(object sender, EventArgs e)
        {
            SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");
            sql.Open();
            int balance = 0;
            if (sql.State == ConnectionState.Open)
            {
                try{
                string selectquery = "select * from bank_info where gmail='"+gmail+"'";
                SqlDataAdapter adapter = new SqlDataAdapter(selectquery, sql);
                DataTable dt = new DataTable();
                adapter.Fill(dt);//this method will fill datatable with adapter values which are table rows from database_table
                if (dt.Rows.Count == 1)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        balance = row.Field<int>(3);
                    }
                }
                else
                {
                    MessageBox.Show("You need to have atleast or more than 5000tk in your account.");
                }

                if (balance > 5000)
                {
                        string updatequery = "update bank_info set balance=(balance-2000) where gmail='"+gmail+"'";
                        SqlCommand cmd = new SqlCommand(updatequery, sql);
                        int insertvalue = cmd.ExecuteNonQuery();

                        insertvalue = 0;

                        updatequery = "update accounts set priority=2 where email='" + gmail + "'";
                        cmd = new SqlCommand(updatequery, sql);
                        insertvalue = cmd.ExecuteNonQuery();

                        if (insertvalue == 1)
                        {
                            MessageBox.Show("Your account is upgrated. You can sell your own ticket now.", "Succeed");
                            priority = 2;
                            TicketRequest trequest = new TicketRequest(gmail, priority);
                            this.Hide();
                            trequest.ShowDialog();
                        }
                        else
                        {
                            MessageBox.Show("Your account can't be upgaded.", "Failed");
                        }
                    }
                    else
                    {
                        MessageBox.Show("You need to have atleast or more than 5000tk in your account.");
                    }


                }
                catch (Exception ex)
                {
                    MessageBox.Show("Your account can't be upgaded. Because:-" + ex.Message);
                }
            }
        }

        private void backbutton1_Click(object sender, EventArgs e)
        {
            TicketInfo login = new TicketInfo(gmail, priority);
            this.Hide();
            login.ShowDialog();
        }

        private void logoutbutton1_Click(object sender, EventArgs e)
        {
            LogIn login = new LogIn();
            this.Hide();
            login.ShowDialog();
        }

        private void exitbutton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void TicketRequest_Load(object sender, EventArgs e)
        {
            if (priority == 3)
            {
                panel1.Visible = false;
                panel2.Visible = true;
            }
            else if(priority==2)
            {
                panel1.Visible = true;
                panel2.Visible = false;
            }

            if (ticketTypecomboBox.Text == "")
            {
                am8.Visible = false;
                am10.Visible = false;
                pm12.Visible = false;
                pm4.Visible = false;
                pm6.Visible = false;
                pm8.Visible = false;
                warnlabel.Visible = true;
                ticketLocationtextBox.Visible = false;
                ticketNametextBox.Visible = false;
                quantitycomboBox.Visible = false;
                pricetextBox.Visible = false;
            }
            else 
            {
                warnlabel.Visible = false;
            }
        }

        private void procceedbutton_Click_1(object sender, EventArgs e)
        {
            if (ticketTypecomboBox.Text.Equals("Movie Ticket"))
            {
                tickettype = ticketTypecomboBox.Text;
                am8.Visible = false;
                am10.Visible = false;
                pm12.Visible = true;
                pm4.Visible = true;
                pm6.Visible = true;
                pm8.Visible = false;
                warnlabel.Visible = false;
                ticketLocationtextBox.Visible = true;
                ticketNametextBox.Visible = true;
                quantitycomboBox.Visible = true;
                pricetextBox.Visible = true;
            }
            else if (ticketTypecomboBox.Text.Equals("Bus Ticket"))
            {
                tickettype = ticketTypecomboBox.Text;
                am8.Visible = true;
                am10.Visible = true;
                pm12.Visible = true;
                pm4.Visible = true;
                pm6.Visible = true;
                pm8.Visible = true;
                warnlabel.Visible = false;
                ticketLocationtextBox.Visible = true;
                ticketNametextBox.Visible = true;
                quantitycomboBox.Visible = true;
                pricetextBox.Visible = true;
            }
            else if (ticketTypecomboBox.Text.Equals("Concert Ticket"))
            {
                tickettype = ticketTypecomboBox.Text;
                am8.Visible = false;
                am10.Visible = true;
                pm12.Visible = true;
                pm4.Visible = true;
                pm6.Visible = true;
                pm8.Visible = false;
                warnlabel.Visible = false;
                ticketLocationtextBox.Visible = true;
                ticketNametextBox.Visible = true;
                quantitycomboBox.Visible = true;
                pricetextBox.Visible = true;
            }
            else if (ticketTypecomboBox.Text.Equals("Cricket Ticket"))
            {
                tickettype = ticketTypecomboBox.Text;
                am8.Visible = true;
                am10.Visible = true;
                pm12.Visible = true;
                pm4.Visible = false;
                pm6.Visible = false;
                pm8.Visible = false;
                warnlabel.Visible = false;
                ticketLocationtextBox.Visible = true;
                ticketNametextBox.Visible = true;
                quantitycomboBox.Visible = true;
                pricetextBox.Visible = true;
            }
            else
            {
                tickettype = "";
                am8.Visible = false;
                am10.Visible = false;
                pm12.Visible = false;
                pm4.Visible = false;
                pm6.Visible = false;
                pm8.Visible = false;
                warnlabel.Visible = true;
                ticketLocationtextBox.Visible = false;
                ticketNametextBox.Visible = false;
                quantitycomboBox.Visible = false;
                pricetextBox.Visible = true;
            }
        }

        private void ticketTypecomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            am8.Visible = false;
            am10.Visible = false;
            pm12.Visible = false;
            pm4.Visible = false;
            pm6.Visible = false;
            pm8.Visible = false;
            ticketLocationtextBox.Visible = false;
            ticketNametextBox.Visible = false;
            quantitycomboBox.Visible = false;
            pricetextBox.Visible = false;

            ticketLocationtextBox.Text = "";
            ticketNametextBox.Text = ""; 
            quantitycomboBox.Text = ""; 

            if (ticketTypecomboBox.Text == "")
            {
                warnlabel.Visible = true;
            }
            else
            {
                warnlabel.Visible = false;
            }
        }

        private void submitbutton_Click_1(object sender, EventArgs e)
        {
            string ticketname = ticketNametextBox.Text;
            string ticketlocation = ticketLocationtextBox.Text;
            string quantity = quantitycomboBox.SelectedItem.ToString();
            string[] utime = new string[6];
            int price = int.Parse(pricetextBox.Text);

            int c = 0, enable=0,no=0,insertvalue=0;

            SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");
            string query = "select max(tno) from order_info";
            SqlDataAdapter adapter = new SqlDataAdapter(query, sql);
            DataTable dt = new DataTable();
            adapter.Fill(dt);

            if (dt.Rows.Count == 1)
            {
                foreach (DataRow row in dt.Rows)
                {
                    no = row.Field<int?>(0) ?? 0;
                }
            }

            if (am8.Checked==true)
            {
                utime[0] = am8.Text;
                c = 1;
            }
            if (am10.Checked == true)
            {
                utime[1] = am10.Text;
                c = 2;
            }
            if (pm12.Checked == true)
            {
                utime[2] = pm12.Text;
                c = 3;
            }
            if (pm4.Checked == true)
            {
                utime[3] = pm4.Text;
                c = 4;
            }
            if (pm6.Checked == true)
            {
                utime[4] = pm6.Text;
                c = 5;
            }
            if (pm8.Checked == true)
            {
                utime[5] = pm8.Text;
                c = 6;
            }

            if(ticketname != "" && ticketlocation != "" && c > 0 && quantity!="" && price>0 && no>=0)
            {
                enable=1;
            }
            else
            {
                enable=0;
                MessageBox.Show("One or more field may be empty. Or Order no. is less than 0.");
            }

            if (enable==1)
            {
                sql.Open();
                try
                {
                    for (int i = 0; i < c; i++)
                    {
                        if (utime[i] != null)
                        {
                            no = no + 1;
                            string insertquery = "insert into order_info (tno,gmail,ticket_type,ticket_name,ticket_time,ticket_location,ticket_amount,capacity) values (" + no + ",'" + gmail + "','" + tickettype + "','" + ticketname + "','"+utime[i]+"','" + ticketlocation + "'," + price + "," + int.Parse(quantity)+")";
                            SqlCommand cmd = new SqlCommand(insertquery, sql);
                            insertvalue = cmd.ExecuteNonQuery();
                            

                        }
                        else
                        {
                            
                        }
                    }
                    if (insertvalue == 1)
                    {
                        MessageBox.Show("Order is added.", "Succeed");
                    }
                    else
                    {
                        MessageBox.Show("Order can't be added.", "Failed");
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Failed attempt. Because:-"+ex.Message);
                }

            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void am8_CheckedChanged(object sender, EventArgs e)
        {

        }

    }
}

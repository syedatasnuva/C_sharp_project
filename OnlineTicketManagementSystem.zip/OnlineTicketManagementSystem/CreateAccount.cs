﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace OnlineTicketManagementSystem
{
    public partial class CreateAccount : Form
    {
        string currentdate = "";
        public CreateAccount()
        {
            InitializeComponent();
        }

        private void signupbutton_Click(object sender, EventArgs e)
        {
            string name = nameTextbox.Text;
            string gmail = gmailTextBox.Text;
            string pass = passtextBox.Text;
            string confirmpass = confirmtextBox.Text;
            string address = addresstextBox.Text;
            string bday = bdaydate.Value.ToString("yyyy-MM-dd");
            string gender = genderbox.Text;
            string accountno = accounttextBox.Text;
            int balance = int.Parse(balancetextBox.Text);
            int priority = 3;

            if (name != "" || gmail != "" || pass != "" || confirmpass != "" || address != "" || bday != "" || gender != "" || accountno!="" || balance>0)
            {
                SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");
                sql.Open();
                if (sql.State == ConnectionState.Open)
                {
                    try
                    {
                        string insertquery = "insert into accounts (name,email,passward,priority) values ('" + name + "','" + gmail + "','" + pass + "'," + priority + ")";
                        SqlCommand cmd = new SqlCommand(insertquery, sql);
                        int insertvalue = cmd.ExecuteNonQuery();

                        insertvalue = 0;

                        insertquery = "insert into bank_info (gmail,accountno,address,balance,bday,gender) values ('" + gmail + "','" + accountno + "','" + address + "'," + balance + ",'"+bday+"','"+gender+"')";
                        cmd = new SqlCommand(insertquery, sql);
                        insertvalue = cmd.ExecuteNonQuery();

                        if (insertvalue == 1)
                        {
                            MessageBox.Show("Welcome to Online Ticket Management System.", "Welcome");
                            TicketInfo ticket = new TicketInfo(gmail, priority);
                            this.Hide();
                            ticket.ShowDialog();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("' "+gmail+" ' this email already exists. Try again with different email.");
                    }
                }
            }
            else
            {
                MessageBox.Show("One or more field is empty. Or balance is negetive.");
            }

            
        }

        private void backbutton_Click(object sender, EventArgs e)
        {
            LogIn login = new LogIn();
            this.Hide();
            login.ShowDialog();
        }

        private void exitbutton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void nameTextbox_Leave(object sender, EventArgs e)
        {
            if (nameTextbox.Text == "")
            {
                namesequritylabel.Visible = true;
            }
            else
            {
                namesequritylabel.Visible = false;
            }
        }

        private void passtextBox_Leave(object sender, EventArgs e)
        {
            if (passtextBox.Text == "")
            {
                passsequritylabel.Visible = true;
            }
            else if (passtextBox.Text.Length<6)
            {
                passsequritylabel.Visible = false;
                passsequritylabel2.Visible = true;
            }
            else
            {
                passsequritylabel.Visible = false;
                passsequritylabel2.Visible = false;
            }
        }

        private void confirmtextBox_Leave(object sender, EventArgs e)
        {
            if (confirmtextBox.Text == "")
            {
                confirmsequritylabel1.Visible = true;
            }
            else if (passtextBox.Text != confirmtextBox.Text)
            {
                confirmsequritylabel2.Visible = true;
            }
            else
            {
                confirmsequritylabel1.Visible = false;
                confirmsequritylabel2.Visible = false;
            }
        }

        private void addresstextBox_Leave(object sender, EventArgs e)
        {
            if (addresstextBox.Text == "")
            {
                addresssequritylabel.Visible = true;
            }
            else
            {
                addresssequritylabel.Visible = false;
            }
        }

        private void bdaydate_Leave(object sender, EventArgs e)
        {
            if ( bdaydate.Text=="")
            {
                bdaysequritylabel.Visible = true;
            }
            else
            {
                bdaysequritylabel.Visible = false;
            }
        }

        private void genderbox_Leave(object sender, EventArgs e)
        {
            if (genderbox.Text == "")
            {
                gendersequritylabel.Visible = true;
            }
            else
            {
                gendersequritylabel.Visible = false;
            }
        }

        private void accounttextBox_MouseLeave(object sender, EventArgs e)
        {
            if (accounttextBox.Text == "")
            {
                accountsequritylabel.Visible = true;
            }
            else
            {
                accountsequritylabel.Visible = false;
            }
        }

        private void balancetextBox_MouseLeave(object sender, EventArgs e)
        {
            try
            {
                if (balancetextBox.Text == "")
                {
                    balancesequritylabel.Visible = true;
                }
                else if (int.Parse(balancetextBox.Text) <= 0)
                {
                    balancesequritylabel.Visible = false;
                    balancesequritylabel2.Visible = true;
                }
                else
                {
                    balancesequritylabel.Visible = false;
                    balancesequritylabel2.Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Balance must be in number formet.");
            }
        }

        private void CreateAccount_Load(object sender, EventArgs e)
        {
            currentdate = bdaydate.Value.ToString("yyyy-MM-dd");
        }

        private void bdaydate_MouseLeave(object sender, EventArgs e)
        {
            DateTime currentdates = DateTime.Parse(currentdate);
            DateTime selectdate = DateTime.Parse(bdaydate.Value.ToString("yyyy-MM-dd"));

            TimeSpan difference=currentdates-selectdate;

            if (((difference.Days) / 365) < 18)
            {
                bdaysequritylabel.Visible = true;
            }
            else
            {
                bdaysequritylabel.Visible = false;
            }
        }

        private void nameTextbox_MouseLeave(object sender, EventArgs e)
        {
            if (nameTextbox.Text == "")
            {
                namesequritylabel.Visible = true;
            }
            else
            {
                namesequritylabel.Visible = false;
            }
        }

        private void passtextBox_MouseLeave(object sender, EventArgs e)
        {
            if (passtextBox.Text == "")
            {
                passsequritylabel.Visible = true;
            }
            else if (passtextBox.Text.Length < 6)
            {
                passsequritylabel.Visible = false;
                passsequritylabel2.Visible = true;
            }
            else
            {
                passsequritylabel.Visible = false;
                passsequritylabel2.Visible = false;
            }
        }

        private void confirmtextBox_MouseLeave(object sender, EventArgs e)
        {
            if (confirmtextBox.Text == "")
            {
                confirmsequritylabel1.Visible = true;
            }
            else if (passtextBox.Text != confirmtextBox.Text)
            {
                confirmsequritylabel2.Visible = true;
            }
            else
            {
                confirmsequritylabel1.Visible = false;
                confirmsequritylabel2.Visible = false;
            }
        }

        private void addresstextBox_MouseLeave(object sender, EventArgs e)
        {
            if (addresstextBox.Text == "")
            {
                addresssequritylabel.Visible = true;
            }
            else
            {
                addresssequritylabel.Visible = false;
            }
        }

        private void genderbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (genderbox.Text == "")
            {
                gendersequritylabel.Visible = true;
            }
            else
            {
                gendersequritylabel.Visible = false;
            }
        }

        private void gmailTextBox_TextChanged(object sender, EventArgs e)
        {
            if (gmailTextBox.Text.Contains("@gmail.com") || gmailTextBox.Text.Contains("@hotmail.com") || gmailTextBox.Text.Contains("@yahoo.com") || gmailTextBox.Text.Contains("@live.com"))
            {
                emailseqlabel.Visible = false;
            }
            else
            {
                emailseqlabel.Visible = true;
            }
        }

    }
}

﻿namespace OnlineTicketManagementSystem
{
    partial class LogIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LogIn));
            this.header = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.createaccountlink = new System.Windows.Forms.LinkLabel();
            this.LoginButton = new System.Windows.Forms.Button();
            this.passTextbox = new System.Windows.Forms.TextBox();
            this.emailTextbox = new System.Windows.Forms.TextBox();
            this.passLabel = new System.Windows.Forms.Label();
            this.emailLabel = new System.Windows.Forms.Label();
            this.exitbutton = new System.Windows.Forms.Button();
            this.logintoolTip = new System.Windows.Forms.ToolTip(this.components);
            this.remembercheckBox = new System.Windows.Forms.CheckBox();
            this.emailsequritylabel = new System.Windows.Forms.Label();
            this.passsequritylabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // header
            // 
            this.header.AutoSize = true;
            this.header.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.header.ForeColor = System.Drawing.SystemColors.ControlText;
            this.header.Location = new System.Drawing.Point(103, 11);
            this.header.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.header.Name = "header";
            this.header.Size = new System.Drawing.Size(577, 39);
            this.header.TabIndex = 0;
            this.header.Text = " Onine Ticket Management System";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Location = new System.Drawing.Point(39, 65);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(345, 298);
            this.panel2.TabIndex = 8;
            // 
            // createaccountlink
            // 
            this.createaccountlink.AutoSize = true;
            this.createaccountlink.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.createaccountlink.Location = new System.Drawing.Point(592, 325);
            this.createaccountlink.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.createaccountlink.Name = "createaccountlink";
            this.createaccountlink.Size = new System.Drawing.Size(207, 24);
            this.createaccountlink.TabIndex = 18;
            this.createaccountlink.TabStop = true;
            this.createaccountlink.Text = "Don\'t have an account?";
            this.logintoolTip.SetToolTip(this.createaccountlink, "Create a new account");
            this.createaccountlink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.createaccountlink_LinkClicked_1);
            // 
            // LoginButton
            // 
            this.LoginButton.Image = ((System.Drawing.Image)(resources.GetObject("LoginButton.Image")));
            this.LoginButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.LoginButton.Location = new System.Drawing.Point(643, 266);
            this.LoginButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.LoginButton.Name = "LoginButton";
            this.LoginButton.Size = new System.Drawing.Size(95, 42);
            this.LoginButton.TabIndex = 17;
            this.LoginButton.Text = "Login";
            this.LoginButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.logintoolTip.SetToolTip(this.LoginButton, "Click here to login");
            this.LoginButton.UseVisualStyleBackColor = true;
            this.LoginButton.Click += new System.EventHandler(this.LoginButton_Click_1);
            // 
            // passTextbox
            // 
            this.passTextbox.Location = new System.Drawing.Point(596, 174);
            this.passTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.passTextbox.Name = "passTextbox";
            this.passTextbox.Size = new System.Drawing.Size(200, 22);
            this.passTextbox.TabIndex = 16;
            this.logintoolTip.SetToolTip(this.passTextbox, "Enter your password");
            this.passTextbox.UseSystemPasswordChar = true;
            this.passTextbox.Leave += new System.EventHandler(this.passTextbox_Leave);
            // 
            // emailTextbox
            // 
            this.emailTextbox.Location = new System.Drawing.Point(596, 96);
            this.emailTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.emailTextbox.Name = "emailTextbox";
            this.emailTextbox.Size = new System.Drawing.Size(200, 22);
            this.emailTextbox.TabIndex = 15;
            this.logintoolTip.SetToolTip(this.emailTextbox, "Enter your email");
            this.emailTextbox.Leave += new System.EventHandler(this.emailTextbox_Leave);
            // 
            // passLabel
            // 
            this.passLabel.AutoSize = true;
            this.passLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passLabel.Location = new System.Drawing.Point(427, 174);
            this.passLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.passLabel.Name = "passLabel";
            this.passLabel.Size = new System.Drawing.Size(134, 31);
            this.passLabel.TabIndex = 14;
            this.passLabel.Text = "Password";
            // 
            // emailLabel
            // 
            this.emailLabel.AutoSize = true;
            this.emailLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailLabel.Location = new System.Drawing.Point(427, 96);
            this.emailLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.emailLabel.Name = "emailLabel";
            this.emailLabel.Size = new System.Drawing.Size(81, 31);
            this.emailLabel.TabIndex = 13;
            this.emailLabel.Text = "Email";
            // 
            // exitbutton
            // 
            this.exitbutton.Image = ((System.Drawing.Image)(resources.GetObject("exitbutton.Image")));
            this.exitbutton.Location = new System.Drawing.Point(822, 11);
            this.exitbutton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.exitbutton.Name = "exitbutton";
            this.exitbutton.Size = new System.Drawing.Size(44, 39);
            this.exitbutton.TabIndex = 39;
            this.logintoolTip.SetToolTip(this.exitbutton, "Click here to exit");
            this.exitbutton.UseVisualStyleBackColor = true;
            this.exitbutton.Click += new System.EventHandler(this.exitbutton_Click);
            // 
            // logintoolTip
            // 
            this.logintoolTip.ToolTipTitle = "click";
            // 
            // remembercheckBox
            // 
            this.remembercheckBox.AutoSize = true;
            this.remembercheckBox.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.remembercheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.remembercheckBox.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.remembercheckBox.Location = new System.Drawing.Point(611, 230);
            this.remembercheckBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.remembercheckBox.Name = "remembercheckBox";
            this.remembercheckBox.Size = new System.Drawing.Size(166, 28);
            this.remembercheckBox.TabIndex = 40;
            this.remembercheckBox.Text = "Show password";
            this.logintoolTip.SetToolTip(this.remembercheckBox, "Click to show your password");
            this.remembercheckBox.UseVisualStyleBackColor = false;
            this.remembercheckBox.CheckedChanged += new System.EventHandler(this.remembercheckBox_CheckedChanged);
            // 
            // emailsequritylabel
            // 
            this.emailsequritylabel.AutoSize = true;
            this.emailsequritylabel.ForeColor = System.Drawing.Color.Red;
            this.emailsequritylabel.Location = new System.Drawing.Point(592, 124);
            this.emailsequritylabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.emailsequritylabel.Name = "emailsequritylabel";
            this.emailsequritylabel.Size = new System.Drawing.Size(198, 17);
            this.emailsequritylabel.TabIndex = 46;
            this.emailsequritylabel.Text = "->This field must not be empty";
            this.emailsequritylabel.Visible = false;
            // 
            // passsequritylabel
            // 
            this.passsequritylabel.AutoSize = true;
            this.passsequritylabel.ForeColor = System.Drawing.Color.Red;
            this.passsequritylabel.Location = new System.Drawing.Point(592, 199);
            this.passsequritylabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.passsequritylabel.Name = "passsequritylabel";
            this.passsequritylabel.Size = new System.Drawing.Size(198, 17);
            this.passsequritylabel.TabIndex = 47;
            this.passsequritylabel.Text = "->This field must not be empty";
            this.passsequritylabel.Visible = false;
            // 
            // LogIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(878, 409);
            this.Controls.Add(this.passsequritylabel);
            this.Controls.Add(this.emailsequritylabel);
            this.Controls.Add(this.remembercheckBox);
            this.Controls.Add(this.exitbutton);
            this.Controls.Add(this.createaccountlink);
            this.Controls.Add(this.LoginButton);
            this.Controls.Add(this.passTextbox);
            this.Controls.Add(this.emailTextbox);
            this.Controls.Add(this.passLabel);
            this.Controls.Add(this.emailLabel);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.header);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.Name = "LogIn";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "login Page";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label header;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.LinkLabel createaccountlink;
        private System.Windows.Forms.Button LoginButton;
        private System.Windows.Forms.TextBox passTextbox;
        private System.Windows.Forms.TextBox emailTextbox;
        private System.Windows.Forms.Label passLabel;
        private System.Windows.Forms.Label emailLabel;
        private System.Windows.Forms.Button exitbutton;
        private System.Windows.Forms.ToolTip logintoolTip;
        private System.Windows.Forms.CheckBox remembercheckBox;
        private System.Windows.Forms.Label emailsequritylabel;
        private System.Windows.Forms.Label passsequritylabel;
    }
}


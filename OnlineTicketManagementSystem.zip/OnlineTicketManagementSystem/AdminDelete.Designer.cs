﻿namespace OnlineTicketManagementSystem
{
    partial class AdminDelete
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminDelete));
            this.menupanel = new System.Windows.Forms.Panel();
            this.exitbutton = new System.Windows.Forms.Button();
            this.logoutbutton1 = new System.Windows.Forms.Button();
            this.menubutton = new System.Windows.Forms.Button();
            this.backbutton1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.email = new System.Windows.Forms.TextBox();
            this.namesubmitbutton = new System.Windows.Forms.Button();
            this.menupanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menupanel
            // 
            this.menupanel.Controls.Add(this.exitbutton);
            this.menupanel.Controls.Add(this.logoutbutton1);
            this.menupanel.Location = new System.Drawing.Point(587, 82);
            this.menupanel.Name = "menupanel";
            this.menupanel.Size = new System.Drawing.Size(52, 231);
            this.menupanel.TabIndex = 58;
            this.menupanel.Visible = false;
            // 
            // exitbutton
            // 
            this.exitbutton.Image = ((System.Drawing.Image)(resources.GetObject("exitbutton.Image")));
            this.exitbutton.Location = new System.Drawing.Point(7, 55);
            this.exitbutton.Name = "exitbutton";
            this.exitbutton.Size = new System.Drawing.Size(33, 32);
            this.exitbutton.TabIndex = 44;
            this.exitbutton.UseVisualStyleBackColor = true;
            this.exitbutton.Click += new System.EventHandler(this.exitbutton_Click);
            // 
            // logoutbutton1
            // 
            this.logoutbutton1.Image = ((System.Drawing.Image)(resources.GetObject("logoutbutton1.Image")));
            this.logoutbutton1.Location = new System.Drawing.Point(7, 17);
            this.logoutbutton1.Name = "logoutbutton1";
            this.logoutbutton1.Size = new System.Drawing.Size(33, 32);
            this.logoutbutton1.TabIndex = 42;
            this.logoutbutton1.UseVisualStyleBackColor = true;
            this.logoutbutton1.Click += new System.EventHandler(this.logoutbutton1_Click);
            // 
            // menubutton
            // 
            this.menubutton.Image = ((System.Drawing.Image)(resources.GetObject("menubutton.Image")));
            this.menubutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menubutton.Location = new System.Drawing.Point(605, 23);
            this.menubutton.Name = "menubutton";
            this.menubutton.Size = new System.Drawing.Size(34, 32);
            this.menubutton.TabIndex = 57;
            this.menubutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.menubutton.UseVisualStyleBackColor = true;
            this.menubutton.Click += new System.EventHandler(this.menubutton_Click);
            // 
            // backbutton1
            // 
            this.backbutton1.Image = ((System.Drawing.Image)(resources.GetObject("backbutton1.Image")));
            this.backbutton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.backbutton1.Location = new System.Drawing.Point(566, 23);
            this.backbutton1.Name = "backbutton1";
            this.backbutton1.Size = new System.Drawing.Size(34, 32);
            this.backbutton1.TabIndex = 56;
            this.backbutton1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.backbutton1.UseVisualStyleBackColor = true;
            this.backbutton1.Click += new System.EventHandler(this.backbutton1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(69, 128);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(254, 20);
            this.label2.TabIndex = 54;
            this.label2.Text = "Enter Account Holder\'s Email: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(68, 42);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(265, 31);
            this.label1.TabIndex = 53;
            this.label1.Text = "Delete An Account:";
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.Control;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.Location = new System.Drawing.Point(71, 27);
            this.button5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(178, 36);
            this.button5.TabIndex = 59;
            this.button5.Text = "Delete";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button5);
            this.panel1.Location = new System.Drawing.Point(121, 199);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(322, 95);
            this.panel1.TabIndex = 60;
            this.panel1.Visible = false;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // email
            // 
            this.email.Location = new System.Drawing.Point(345, 130);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(138, 20);
            this.email.TabIndex = 61;
            this.email.TextChanged += new System.EventHandler(this.email_TextChanged);
            // 
            // namesubmitbutton
            // 
            this.namesubmitbutton.Image = ((System.Drawing.Image)(resources.GetObject("namesubmitbutton.Image")));
            this.namesubmitbutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.namesubmitbutton.Location = new System.Drawing.Point(488, 126);
            this.namesubmitbutton.Name = "namesubmitbutton";
            this.namesubmitbutton.Size = new System.Drawing.Size(25, 26);
            this.namesubmitbutton.TabIndex = 62;
            this.namesubmitbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.namesubmitbutton.UseVisualStyleBackColor = true;
            this.namesubmitbutton.Click += new System.EventHandler(this.namesubmitbutton_Click);
            // 
            // AdminDelete
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(658, 332);
            this.Controls.Add(this.namesubmitbutton);
            this.Controls.Add(this.email);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menupanel);
            this.Controls.Add(this.menubutton);
            this.Controls.Add(this.backbutton1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MaximizeBox = false;
            this.Name = "AdminDelete";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Delete Account";
            this.menupanel.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel menupanel;
        private System.Windows.Forms.Button exitbutton;
        private System.Windows.Forms.Button logoutbutton1;
        private System.Windows.Forms.Button menubutton;
        private System.Windows.Forms.Button backbutton1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox email;
        private System.Windows.Forms.Button namesubmitbutton;
    }
}
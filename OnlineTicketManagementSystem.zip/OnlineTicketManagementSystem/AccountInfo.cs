﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace OnlineTicketManagementSystem
{
    public partial class AccountInfo : Form 
    {
        List<Panel> listpanel = new List<Panel>();
        int index = 0;
        string gmail="";
        int priority=0;
        string name = "", address = "", pass = "", account = "", bday = "", gender = "",balance="",currentdate="";

        public AccountInfo(string gmail,int priority)
        {
            this.gmail=gmail;
            this.priority=priority;
            InitializeComponent();
        }


        private void editbutton_Click(object sender, EventArgs e)
        {
            listpanel[++index].BringToFront();
        }

        private void backbutton1_Click(object sender, EventArgs e)
        {
            if (index == 0)
            {
                TicketInfo ticketinfo = new TicketInfo(gmail, priority);
                this.Hide();
                ticketinfo.ShowDialog();
            }
            else if (index == 1) {
                listpanel[--index].BringToFront();
            }

        }

        private void logoutbutton1_Click(object sender, EventArgs e)
        {
            LogIn login = new LogIn();
            this.Hide();
            login.ShowDialog();
        }

        private void AccountInfo_Load(object sender, EventArgs e)
        {
            currentdate = bdaytime.Value.ToString("yyyy-MM-dd");
            SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");
            string query = "select * from accounts where email='" + gmail + "'";
            SqlDataAdapter adapter = new SqlDataAdapter(query, sql);
            DataTable dt = new DataTable();
            adapter.Fill(dt);

            if (dt.Rows.Count == 1)
            {
                foreach (DataRow row in dt.Rows)
                {
                    name = row.Field<string>(0);
                    pass = row.Field<string>(2);
                }
            }
            dt.Clear();
            query = "select * from bank_info where gmail='" + gmail + "'";
            adapter = new SqlDataAdapter(query, sql);
            DataTable dt1 = new DataTable();
            adapter.Fill(dt1);

            if (dt1.Rows.Count == 1)
            {
                foreach (DataRow row in dt1.Rows)
                {
                    account = row.Field<string>(1);
                    address = row.Field<string>(2);
                    balance = row.Field<int>(3).ToString();
                    bday = row.Field<string>(4);
                    gender = row.Field<string>(5);
                }
            }
            nametext.Text = name;
            addresstext.Text = address;
            emailText.Text = gmail;
            passtext.Text = "********";
            AccountText.Text = account;
            balancetext.Text = balance;
            BdayText.Text = bday;
            genderText.Text = gender;

            editnametextBox.Text = name;
            editAddresstextBox.Text = address;
            editEmailtextBox.Text = gmail;
            editPasstextBox.Text = "********";

            listpanel.Add(panel1);
            listpanel.Add(panel2);
            listpanel[index].BringToFront();
        }

        private void Editbutton_Click_1(object sender, EventArgs e)
        {
            if (index == 0)
            {
                listpanel[++index].BringToFront();
            }
            else
            {
                MessageBox.Show("You are in the Account Edit pane.");
            }
        }

        private void submitbutton_Click(object sender, EventArgs e)
        {
            SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");
                sql.Open();
                if (sql.State == ConnectionState.Open)
                {
                    if (editnametextBox.Text != "")
                    {
                        namesequritylabel.Visible = false;
                        try
                        {
                            string updatequery = "update accounts set name='" + editnametextBox.Text + "' where email='" + gmail + "'";
                            SqlCommand cmd = new SqlCommand(updatequery, sql);
                            int insertvalue = cmd.ExecuteNonQuery();
                            if (insertvalue == 1)
                            {
                                MessageBox.Show("Name is updated.", "Succeed");
                            }
                            else
                            {
                                MessageBox.Show("Name can't be updated.", "Failed");
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Name Can't be updated. Because:-" + ex.Message);
                        }
                    }
                    else
                    {
                        namesequritylabel.Visible = true;
                    }
                }
        }

        private void exitbutton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void menubutton_Click(object sender, EventArgs e)
        {
            if (menupanel.Visible == false)
            {
                menupanel.Visible = true;
            }
            else if (menupanel.Visible == true)
            {
                menupanel.Visible = false;
            }
        }

        private void addresssubmitbutton_Click(object sender, EventArgs e)
        {
            SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");
            sql.Open();
            if (sql.State == ConnectionState.Open)
            {
                if (editAddresstextBox.Text != "")
                {
                    addresssequritylabel.Visible = false;
                    try
                    {
                        string updatequery = "update bank_info set address='" + editAddresstextBox.Text + "' where gmail='" + gmail + "'";
                        SqlCommand cmd = new SqlCommand(updatequery, sql);
                        int insertvalue = cmd.ExecuteNonQuery();
                        if (insertvalue == 1)
                        {
                            MessageBox.Show("Address is updated.", "Succeed");
                        }
                        else
                        {
                            MessageBox.Show("Address can't be updated.", "Failed");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Address Can't be updated. Because:-" + ex.Message);
                    }
                }
                else
                {
                    addresssequritylabel.Visible = true;
                }
            }
        }

        private void passsubmitbutton_Click(object sender, EventArgs e)
        {
            SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");
            sql.Open();
            if (sql.State == ConnectionState.Open)
            {
                if (editPasstextBox.Text.Length >= 6)
                {
                    passsequritylabel.Visible = false;
                    try
                    {
                        string updatequery = "update accounts set passward='" + editPasstextBox.Text + "' where email='" + gmail + "'";
                        SqlCommand cmd = new SqlCommand(updatequery, sql);
                        int insertvalue = cmd.ExecuteNonQuery();
                        if (insertvalue == 1)
                        {
                            MessageBox.Show("Password is updated.", "Succeed");
                        }
                        else
                        {
                            MessageBox.Show("Password can't be updated.", "Failed");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Password Can't be updated. Because:-" + ex.Message);
                    }
                }
                else
                {
                    passsequritylabel.Visible = true;
                }
            }
        }

        private void bdaysubmitbutton_Click(object sender, EventArgs e)
        {
            DateTime currentdates = DateTime.Parse(currentdate);
            DateTime selectdate = DateTime.Parse(bdaytime.Value.ToString("yyyy-MM-dd"));

            TimeSpan difference = currentdates - selectdate;

            if (((difference.Days) / 365) >= 18)
            {
                SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");
                sql.Open();
                if (sql.State == ConnectionState.Open)
                {
                    bdaysequritylabel.Visible = false;
                    try
                    {
                        string updatequery = "update bank_info set bday='" + bdaytime.Value.ToString("yyyy-MM-dd") + "' where gmail='" + gmail + "'";
                        SqlCommand cmd = new SqlCommand(updatequery, sql);
                        int insertvalue = cmd.ExecuteNonQuery();
                        if (insertvalue == 1)
                        {
                            MessageBox.Show("Birthday is updated.", "Succeed");
                        }
                        else
                        {
                            MessageBox.Show("Birthday can't be updated.", "Failed");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Birthday Can't be updated. Because:-" + ex.Message);
                    }
                }
            }
            else
            {
                bdaysequritylabel.Visible = true;
            }
        }
    }
}

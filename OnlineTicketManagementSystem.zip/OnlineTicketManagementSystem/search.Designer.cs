﻿namespace OnlineTicketManagementSystem
{
    partial class search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(search));
            this.header = new System.Windows.Forms.Label();
            this.menubutton = new System.Windows.Forms.Button();
            this.backbutton = new System.Windows.Forms.Button();
            this.menupanel = new System.Windows.Forms.Panel();
            this.exitbutton = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label = new System.Windows.Forms.Label();
            this.searchlabel = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.menupanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // header
            // 
            this.header.AutoSize = true;
            this.header.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.header.Location = new System.Drawing.Point(138, 47);
            this.header.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.header.Name = "header";
            this.header.Size = new System.Drawing.Size(576, 39);
            this.header.TabIndex = 1;
            this.header.Text = "Online Ticket Management System";
            // 
            // menubutton
            // 
            this.menubutton.Image = ((System.Drawing.Image)(resources.GetObject("menubutton.Image")));
            this.menubutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menubutton.Location = new System.Drawing.Point(820, 15);
            this.menubutton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.menubutton.Name = "menubutton";
            this.menubutton.Size = new System.Drawing.Size(45, 39);
            this.menubutton.TabIndex = 44;
            this.menubutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.menubutton.UseVisualStyleBackColor = true;
            this.menubutton.Click += new System.EventHandler(this.menubutton_Click);
            // 
            // backbutton
            // 
            this.backbutton.Image = ((System.Drawing.Image)(resources.GetObject("backbutton.Image")));
            this.backbutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.backbutton.Location = new System.Drawing.Point(763, 15);
            this.backbutton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.backbutton.Name = "backbutton";
            this.backbutton.Size = new System.Drawing.Size(49, 39);
            this.backbutton.TabIndex = 43;
            this.backbutton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.backbutton.UseVisualStyleBackColor = true;
            this.backbutton.Click += new System.EventHandler(this.backbutton_Click);
            // 
            // menupanel
            // 
            this.menupanel.Controls.Add(this.exitbutton);
            this.menupanel.Controls.Add(this.button1);
            this.menupanel.Location = new System.Drawing.Point(788, 62);
            this.menupanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.menupanel.Name = "menupanel";
            this.menupanel.Size = new System.Drawing.Size(77, 293);
            this.menupanel.TabIndex = 45;
            this.menupanel.Visible = false;
            // 
            // exitbutton
            // 
            this.exitbutton.Image = ((System.Drawing.Image)(resources.GetObject("exitbutton.Image")));
            this.exitbutton.Location = new System.Drawing.Point(17, 68);
            this.exitbutton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.exitbutton.Name = "exitbutton";
            this.exitbutton.Size = new System.Drawing.Size(44, 39);
            this.exitbutton.TabIndex = 39;
            this.exitbutton.UseVisualStyleBackColor = true;
            this.exitbutton.Click += new System.EventHandler(this.exitbutton_Click);
            // 
            // button1
            // 
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(17, 21);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(44, 39);
            this.button1.TabIndex = 21;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.Location = new System.Drawing.Point(248, 112);
            this.label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(195, 25);
            this.label.TabIndex = 46;
            this.label.Text = "You searched for : ";
            // 
            // searchlabel
            // 
            this.searchlabel.AutoSize = true;
            this.searchlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchlabel.Location = new System.Drawing.Point(440, 112);
            this.searchlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.searchlabel.Name = "searchlabel";
            this.searchlabel.Size = new System.Drawing.Size(118, 25);
            this.searchlabel.TabIndex = 47;
            this.searchlabel.Text = "search text";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(85, 156);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(664, 199);
            this.dataGridView1.TabIndex = 48;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // search
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(878, 409);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.searchlabel);
            this.Controls.Add(this.label);
            this.Controls.Add(this.menupanel);
            this.Controls.Add(this.menubutton);
            this.Controls.Add(this.backbutton);
            this.Controls.Add(this.header);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.Name = "search";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Search";
            this.Load += new System.EventHandler(this.search_Load);
            this.menupanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label header;
        private System.Windows.Forms.Button menubutton;
        private System.Windows.Forms.Button backbutton;
        private System.Windows.Forms.Panel menupanel;
        private System.Windows.Forms.Button exitbutton;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label searchlabel;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace OnlineTicketManagementSystem
{
    public partial class AddTicket : Form
    {
        string gmail = "", tickettype = "";

        public AddTicket()
        {
            InitializeComponent();
        }

        private void menubutton_Click(object sender, EventArgs e)
        {
            if (menupanel.Visible == false)
            {
                menupanel.Visible = true;
            }
            else if (menupanel.Visible == true)
            {
                menupanel.Visible = false;
            }
        }

        private void backbutton1_Click(object sender, EventArgs e)
        {
            AdminForm admin = new AdminForm();
            this.Hide();
            admin.ShowDialog();
        }

        private void logoutbutton1_Click(object sender, EventArgs e)
        {
            LogIn login = new LogIn();
            this.Hide();
            login.ShowDialog();
        }

        private void exitbutton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void AddTicket_Load(object sender, EventArgs e)
        {
            am8.Visible = false;
            am10.Visible = false;
            pm12.Visible = false;
            pm4.Visible = false;
            pm6.Visible = false;
            pm8.Visible = false;
            ticketLocationtextBox.Visible = false;
            ticketNametextBox.Visible = false;
            quantitycomboBox.Visible = false;
            pricetextBox.Visible = false;

            ticketLocationtextBox.Text = "";
            ticketNametextBox.Text = "";
            quantitycomboBox.Text = "";

            warnlabel.Visible = false;
        }

        private void procceedbutton_Click(object sender, EventArgs e)
        {
            if (ticketTypecomboBox.Text.Equals("Movie Ticket"))
            {
                tickettype = ticketTypecomboBox.Text;
                am8.Visible = false;
                am10.Visible = true;
                pm12.Visible = true;
                pm4.Visible = true;
                pm6.Visible = true;
                pm8.Visible = false;
                warnlabel.Visible = false;
                ticketLocationtextBox.Visible = true;
                ticketNametextBox.Visible = true;
                quantitycomboBox.Visible = true;
                pricetextBox.Visible = true;
            }
            else if (ticketTypecomboBox.Text.Equals("Bus Ticket"))
            {
                tickettype = ticketTypecomboBox.Text;
                am8.Visible = true;
                am10.Visible = true;
                pm12.Visible = true;
                pm4.Visible = true;
                pm6.Visible = true;
                pm8.Visible = true;
                warnlabel.Visible = false;
                ticketLocationtextBox.Visible = true;
                ticketNametextBox.Visible = true;
                quantitycomboBox.Visible = true;
                pricetextBox.Visible = true;
            }
            else if (ticketTypecomboBox.Text.Equals("Concert Ticket"))
            {
                tickettype = ticketTypecomboBox.Text;
                am8.Visible = false;
                am10.Visible = true;
                pm12.Visible = true;
                pm4.Visible = true;
                pm6.Visible = true;
                pm8.Visible = false;
                warnlabel.Visible = false;
                ticketLocationtextBox.Visible = true;
                ticketNametextBox.Visible = true;
                quantitycomboBox.Visible = true;
                pricetextBox.Visible = true;
            }
            else if (ticketTypecomboBox.Text.Equals("Cricket Ticket"))
            {
                tickettype = ticketTypecomboBox.Text;
                am8.Visible = true;
                am10.Visible = true;
                pm12.Visible = true;
                pm4.Visible = false;
                pm6.Visible = false;
                pm8.Visible = false;
                warnlabel.Visible = false;
                ticketLocationtextBox.Visible = true;
                ticketNametextBox.Visible = true;
                quantitycomboBox.Visible = true;
                pricetextBox.Visible = true;
            }
            else
            {
                tickettype = "";
                am8.Visible = false;
                am10.Visible = false;
                pm12.Visible = false;
                pm4.Visible = false;
                pm6.Visible = false;
                pm8.Visible = false;
                warnlabel.Visible = true;
                ticketLocationtextBox.Visible = false;
                ticketNametextBox.Visible = false;
                quantitycomboBox.Visible = false;
                pricetextBox.Visible = true;
            }
        }

        private void ticketTypecomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            am8.Visible = false;
            am10.Visible = false;
            pm12.Visible = false;
            pm4.Visible = false;
            pm6.Visible = false;
            pm8.Visible = false;
            ticketLocationtextBox.Visible = false;
            ticketNametextBox.Visible = false;
            quantitycomboBox.Visible = false;
            pricetextBox.Visible = false;

            ticketLocationtextBox.Text = "";
            ticketNametextBox.Text = "";
            quantitycomboBox.Text = "";

            if (ticketTypecomboBox.Text == "")
            {
                warnlabel.Visible = true;
            }
            else
            {
                warnlabel.Visible = false;
            }
        }

        private void submitbutton_Click(object sender, EventArgs e)
        {
            string ticketname = ticketNametextBox.Text;
            string ticketlocation = ticketLocationtextBox.Text;
            string quantity = quantitycomboBox.SelectedItem.ToString();
            string[] utime = new string[6];
            int price = int.Parse(pricetextBox.Text);

            int c = 0, enable = 0, insertvalue = 0;

            SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");

            if (am8.Checked == true)
            {
                utime[0] = am8.Text;
                c = 1;
            }
            if (am10.Checked == true)
            {
                utime[1] = am10.Text;
                c = 2;
            }
            if (pm12.Checked == true)
            {
                utime[2] = pm12.Text;
                c = 3;
            }
            if (pm4.Checked == true)
            {
                utime[3] = pm4.Text;
                c = 4;
            }
            if (pm6.Checked == true)
            {
                utime[4] = pm6.Text;
                c = 5;
            }
            if (pm8.Checked == true)
            {
                utime[5] = pm8.Text;
                c = 6;
            }

            if (ticketname != "" && ticketlocation != "" && c > 0 && quantity != "" && price > 0)
            {
                enable = 1;
            }
            else
            {
                enable = 0;
                MessageBox.Show("One or more field may be empty.");
            }

            if (enable == 1)
            {
                sql.Open();
                try
                {
                    try
                    {
                        if (ticketTypecomboBox.Text.Equals("Movie Ticket"))
                        {
                            string insertquery = "insert into movie (movie_name) values ('" + ticketname + "')";
                            SqlCommand cmd = new SqlCommand(insertquery, sql);
                            insertvalue = cmd.ExecuteNonQuery();
                        }
                        else if (ticketTypecomboBox.Text.Equals("Bus Ticket"))
                        {
                            string insertquery = "insert into bus (Bus_Name) values ('" + ticketname + "')";
                            SqlCommand cmd = new SqlCommand(insertquery, sql);
                            insertvalue = cmd.ExecuteNonQuery();
                        }

                        else if (ticketTypecomboBox.Text.Equals("Concert Ticket"))
                        {
                            string insertquery = "insert into concert (Concert _name) values ('" + ticketname + "')";
                            SqlCommand cmd = new SqlCommand(insertquery, sql);
                            insertvalue = cmd.ExecuteNonQuery();
                        }

                        else if (ticketTypecomboBox.Text.Equals("Cricket Ticket"))
                        {
                            string insertquery = "insert into cricket (Cricket_name) values ('" + ticketname + "')";
                            SqlCommand cmd = new SqlCommand(insertquery, sql);
                            insertvalue = cmd.ExecuteNonQuery();
                        }
                    }
                    catch (Exception ex)
                    { }


                    for (int i = 0; i < c; i++)
                    {
                        if (utime[i] != null)
                        {
                            
                            if (ticketTypecomboBox.Text.Equals("Movie Ticket"))
                            {
                                string selectquery = "select * from movie_ticket where movie_name='"+ticketname+"' and movie_time='"+utime[i]+"' and movie_location='"+ticketlocation+"'";
                                SqlDataAdapter adapter = new SqlDataAdapter(selectquery, sql);
                                DataTable dt = new DataTable();
                                adapter.Fill(dt);
                                if (dt.Rows.Count == 0)
                                {
                                    string insertquery = "insert into movie_ticket (movie_name,movie_time,movie_location,movie_amount,capacity) values ('" + ticketname + "','" + utime[i] + "','" + ticketlocation + "'," + price + "," + int.Parse(quantity) + ")";
                                    SqlCommand cmd = new SqlCommand(insertquery, sql);
                                    insertvalue = cmd.ExecuteNonQuery();

                                    if (insertvalue == 1)
                                    {
                                        insertvalue = 0;
                                        MessageBox.Show("Ticket is added.", "Succeed");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("This ticket is already added.");
                                }
                               
                            }
                            else if (ticketTypecomboBox.Text.Equals("Bus Ticket"))
                            {
                                string selectquery = "select * from bus_tickets where bus_name='" + ticketname + "' and bus_time='" + utime[i] + "' and bus_location='" + ticketlocation + "'";
                                SqlDataAdapter adapter = new SqlDataAdapter(selectquery, sql);
                                DataTable dt = new DataTable();
                                adapter.Fill(dt);
                                if (dt.Rows.Count == 0)
                                {
                                string insertquery = "insert into bus_tickets (bus_name,bus_time,bus_location,bus_amount,capacity) values ('" + ticketname + "','" + utime[i] + "','" + ticketlocation + "'," + price + "," + int.Parse(quantity) + ")";
                                SqlCommand cmd = new SqlCommand(insertquery, sql);
                                insertvalue = cmd.ExecuteNonQuery();

                                if (insertvalue == 1)
                                {
                                    insertvalue = 0;
                                    MessageBox.Show("Ticket is added.", "Succeed");
                                }
                                }
                                else
                                {
                                    MessageBox.Show("This ticket is already added.");
                                }
                            }
            
                            else if (ticketTypecomboBox.Text.Equals("Concert Ticket"))
                            {
                                string selectquery = "select * from concert_ticket where concert_name='" + ticketname + "' and concert_time='" + utime[i] + "' and concert_location='" + ticketlocation + "'";
                                SqlDataAdapter adapter = new SqlDataAdapter(selectquery, sql);
                                DataTable dt = new DataTable();
                                adapter.Fill(dt);
                                if (dt.Rows.Count == 0)
                                {
                                string insertquery = "insert into concert_ticket (concert_name,concert_time,concert_location,concert_amount,capacity) values ('" + ticketname + "','" + utime[i] + "','" + ticketlocation + "'," + price + "," + int.Parse(quantity) + ")";
                                SqlCommand cmd = new SqlCommand(insertquery, sql);
                                insertvalue = cmd.ExecuteNonQuery();

                                if (insertvalue == 1)
                                {
                                    insertvalue = 0;
                                    MessageBox.Show("Ticket is added.", "Succeed");
                                }
                                }
                                else
                                {
                                    MessageBox.Show("This ticket is already added.");
                                }
                                
                            }
          
                            else if (ticketTypecomboBox.Text.Equals("Cricket Ticket"))
                            {
                                string selectquery = "select * from cricket_ticket where cricket_name='" + ticketname + "' and cricket_time='" + utime[i] + "' and cricket_location='" + ticketlocation + "'";
                                SqlDataAdapter adapter = new SqlDataAdapter(selectquery, sql);
                                DataTable dt = new DataTable();
                                adapter.Fill(dt);
                                if (dt.Rows.Count == 0)
                                {
                                string insertquery = "insert into cricket_ticket (cricket_name,cricket_time,cricket_location,cricket_amount,capacity) values ('" + ticketname + "','" + utime[i] + "','" + ticketlocation + "'," + price + "," + int.Parse(quantity) + ")";
                                SqlCommand cmd = new SqlCommand(insertquery, sql);
                                insertvalue = cmd.ExecuteNonQuery();

                                if (insertvalue == 1)
                                {
                                    insertvalue = 0;
                                    MessageBox.Show("Ticket is added.", "Succeed");
                                }
                                }
                                else
                                {
                                    MessageBox.Show("This ticket is already added.");
                                }
                            }

                        }
                        else
                        {
                            
                        }
                    }
                    

                }
                catch (Exception ex)
                {
                    MessageBox.Show("This ticket is already added");
                }

            }
        }

        private void quantitylabel_Click(object sender, EventArgs e)
        {

        }
    }
}

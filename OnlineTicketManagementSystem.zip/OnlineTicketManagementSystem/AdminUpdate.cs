﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace OnlineTicketManagementSystem
{
    public partial class AdminUpdate : Form
    {
        public string mail;
        public string mailn;
        public int found = 0, priority = 3;

        public AdminUpdate()
        {
            InitializeComponent();
        }

        private void menubutton_Click(object sender, EventArgs e)
        {
            if (menupanel.Visible == false)
            {
                menupanel.Visible = true;
            }
            else if (menupanel.Visible == true)
            {
                menupanel.Visible = false;
            }
        }

        private void backbutton1_Click(object sender, EventArgs e)
        {
            AdminForm admin = new AdminForm();
            this.Hide();
            admin.ShowDialog();
        }

        private void logoutbutton1_Click(object sender, EventArgs e)
        {
            LogIn login = new LogIn();
            this.Hide();
            login.ShowDialog();
        }

        private void exitbutton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void email_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void namesubmitbutton_Click(object sender, EventArgs e)
        {
            string mail = email.Text;
            SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");
            sql.Open();
            if (sql.State == ConnectionState.Open)
            {
                try
                {
                    string query = "select * from accounts where Email='" + mail + "'";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, sql);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    if (dt.Rows.Count == 1)
                    {
                        foreach (DataRow row in dt.Rows)
                        {
                            mailn = row.Field<string>(0);
                            MessageBox.Show("Email Found! Belonging to : " + mailn + "");
                            found = 1;
                        }
                    }
                    else if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show("Email not Found");
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Failed attempt. Because:-" + ex.Message);
                }

            }

            if (found == 1)
            {
                panel1.Visible = true;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string combo = comboBox1.Text;
            string mail = email.Text;
            SqlConnection sql = new SqlConnection("Data Source=SAMITH\\SQLEXPRESS;Initial Catalog=eticket;Integrated Security=True");
            sql.Open();

            if (combo == "Admin")
            {
                if (sql.State == ConnectionState.Open)
                {
                    try
                    {
                        string query = "update accounts set priority =" + int.Parse("1") + " where Email ='" + mail + "'";
                        SqlCommand cmd = new SqlCommand(query, sql);
                        int value = cmd.ExecuteNonQuery();

                        if (value == 1)
                        {
                            MessageBox.Show("The Account is Updated to an Admin!");
                        }

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Failed attempt. Because:-" + ex.Message);
                    }
                }
            }
                else if (combo == "Premium")
                {
                    if (sql.State == ConnectionState.Open)
                    {
                        try
                        {
                            string query = "update accounts set priority =" + int.Parse("2") + " where Email ='" + mail + "'";
                            SqlCommand cmd = new SqlCommand(query, sql);
                            int value = cmd.ExecuteNonQuery();

                            if (value == 1)
                            {
                                MessageBox.Show("The Account is Updated to an Premium!");
                            }

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Failed attempt. Because:-" + ex.Message);
                        }
                    }
                }
                    else if (combo == "Regular")
                    {
                        if (sql.State == ConnectionState.Open)
                        {
                            try
                            {
                                string query = "update accounts set priority =" + int.Parse("3") + " where Email ='" + mail + "'";
                                SqlCommand cmd = new SqlCommand(query, sql);
                                int value = cmd.ExecuteNonQuery();

                                if (value == 1)
                                {
                                    MessageBox.Show("The Account is updated to an Regular!");
                                }

                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Failed attempt. Because:-" + ex.Message);
                            }
                        }
                    }
                        else
                        {
                            MessageBox.Show("Something is wrong!");
                        }
                    }

                }
            }
